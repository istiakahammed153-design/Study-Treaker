// Bundles the Capacitor bridge + copies vendor libs into www/
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const vendor = path.join(root, 'www', 'vendor');
fs.mkdirSync(vendor, { recursive: true });

const copy = (from, to) => fs.copyFileSync(path.join(root, 'node_modules', from), path.join(vendor, to));
copy('pdfjs-dist/build/pdf.min.js', 'pdf.min.js');
copy('pdfjs-dist/build/pdf.worker.min.js', 'pdf.worker.min.js');
copy('jszip/dist/jszip.min.js', 'jszip.min.js');

// KaTeX (maths in AI answers). Optional: the app still works (plain text maths) if this step fails.
try {
  const kd = path.join(root, 'node_modules', 'katex', 'dist');
  fs.copyFileSync(path.join(kd, 'katex.min.js'), path.join(vendor, 'katex.min.js'));
  fs.copyFileSync(path.join(kd, 'katex.min.css'), path.join(vendor, 'katex.min.css'));
  fs.cpSync(path.join(kd, 'fonts'), path.join(vendor, 'fonts'), { recursive: true });
  for (const f of fs.readdirSync(path.join(vendor, 'fonts'))) if (!f.endsWith('.woff2')) fs.rmSync(path.join(vendor, 'fonts', f), { force: true });
  let css = fs.readFileSync(path.join(vendor, 'katex.min.css'), 'utf8');
  css = css.replace(/,\s*url\(fonts\/[^)]+\.woff\)\s*format\("woff"\)/g, '').replace(/,\s*url\(fonts\/[^)]+\.ttf\)\s*format\("truetype"\)/g, '');
  fs.writeFileSync(path.join(vendor, 'katex.min.css'), css);
} catch (e) { console.warn('katex not bundled:', e.message); }

require('esbuild').buildSync({
  entryPoints: [path.join(root, 'src', 'native.js')],
  bundle: true, minify: true, format: 'iife', target: 'es2019',
  outfile: path.join(root, 'www', 'native.js'),
});
console.log('web build ok');
