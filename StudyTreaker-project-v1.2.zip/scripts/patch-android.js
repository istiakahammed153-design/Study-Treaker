// Runs after `npx cap add android`: installs the storage plugin, permissions, icons.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const android = path.join(root, 'android');
if (!fs.existsSync(android)) { console.error('android/ folder missing - run "npx cap add android" first'); process.exit(1); }

const pkgDir = path.join(android, 'app/src/main/java/com/studytreaker/app');
fs.mkdirSync(pkgDir, { recursive: true });
for (const f of ['SafStoragePlugin.java', 'MainActivity.java']) {
  fs.copyFileSync(path.join(root, 'native', f), path.join(pkgDir, f));
}

// documentfile dependency (SAF helper)
const gradlePath = path.join(android, 'app/build.gradle');
let gradle = fs.readFileSync(gradlePath, 'utf8');
if (!gradle.includes('androidx.documentfile')) {
  gradle = gradle.replace(/dependencies\s*\{/, 'dependencies {\n    implementation "androidx.documentfile:documentfile:1.0.1"');
  fs.writeFileSync(gradlePath, gradle);
}

// manifest: camera for photo capture, cleartext for local LLM servers (http://192.168.x.x)
const manPath = path.join(android, 'app/src/main/AndroidManifest.xml');
let man = fs.readFileSync(manPath, 'utf8');
if (!man.includes('usesCleartextTraffic')) {
  man = man.replace('<application', '<application\n        android:usesCleartextTraffic="true"');
}
if (!man.includes('android.permission.CAMERA')) {
  man = man.replace('</manifest>',
    '    <uses-permission android:name="android.permission.CAMERA" />\n' +
    '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n' +
    '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>');
}
fs.writeFileSync(manPath, man);

// icons (legacy launcher icons; remove adaptive xml so ours is used everywhere)
const res = path.join(android, 'app/src/main/res');
const anydpi = path.join(res, 'mipmap-anydpi-v26');
if (fs.existsSync(anydpi)) fs.rmSync(anydpi, { recursive: true, force: true });
const iconSrc = path.join(root, 'native', 'icons');
for (const d of fs.readdirSync(iconSrc)) {
  const dest = path.join(res, d);
  fs.mkdirSync(dest, { recursive: true });
  for (const f of fs.readdirSync(path.join(iconSrc, d))) {
    fs.copyFileSync(path.join(iconSrc, d, f), path.join(dest, f));
  }
}
// make sure old foreground webp/png leftovers don't clash
for (const d of fs.readdirSync(res).filter(x => x.startsWith('mipmap-'))) {
  for (const f of fs.readdirSync(path.join(res, d))) {
    if (f.startsWith('ic_launcher_foreground')) fs.rmSync(path.join(res, d, f), { force: true });
  }
}
console.log('android patch ok');
