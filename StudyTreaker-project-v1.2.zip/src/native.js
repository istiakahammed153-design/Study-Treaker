import { Capacitor, registerPlugin, CapacitorHttp } from '@capacitor/core';
import { App } from '@capacitor/app';

const SafStorage = registerPlugin('SafStorage');

window.Native = {
  isNative: Capacitor.isNativePlatform(),
  SafStorage,
  App,
  async http(url, opts) {
    // native HTTP: avoids CORS / mixed-content problems when talking to a local LLM server
    const r = await CapacitorHttp.request({
      url, method: opts.method || 'POST', headers: opts.headers || {},
      data: opts.body, readTimeout: 120000, connectTimeout: 15000,
    });
    return { status: r.status, data: r.data };
  },
};
