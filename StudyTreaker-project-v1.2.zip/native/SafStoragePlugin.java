package com.studytreaker.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.MimeTypeMap;

import androidx.activity.result.ActivityResult;
import androidx.documentfile.provider.DocumentFile;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Storage Access Framework bridge.
 * Lets the user pick ANY folder (Internal storage or SD card), then creates
 * sub-folders and writes/reads/deletes files inside it.
 */
@CapacitorPlugin(name = "SafStorage")
public class SafStoragePlugin extends Plugin {

    private static final String PREFS = "st_saf";
    private static final String KEY_ROOT = "root_uri";
    private final Map<String, OutputStream> streams = new HashMap<>();

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private Uri rootUri() {
        String s = prefs().getString(KEY_ROOT, null);
        return s == null ? null : Uri.parse(s);
    }

    private boolean hasPermission(Uri uri) {
        if (uri == null) return false;
        List<UriPermission> perms = getContext().getContentResolver().getPersistedUriPermissions();
        for (UriPermission p : perms) {
            if (p.getUri().equals(uri) && p.isReadPermission() && p.isWritePermission()) return true;
        }
        return false;
    }

    private JSObject describeRoot(Uri uri) {
        JSObject o = new JSObject();
        o.put("uri", uri.toString());
        String volume = "primary";
        String path = "";
        try {
            String id = DocumentsContract.getTreeDocumentId(uri); // e.g. primary:Documents/Study
            int i = id.indexOf(':');
            volume = i >= 0 ? id.substring(0, i) : id;
            path = i >= 0 ? id.substring(i + 1) : "";
        } catch (Exception ignored) { }
        o.put("volume", volume);
        o.put("isSdCard", !"primary".equals(volume));
        o.put("path", path);
        DocumentFile d = DocumentFile.fromTreeUri(getContext(), uri);
        o.put("name", d != null && d.getName() != null ? d.getName() : path);
        return o;
    }

    @PluginMethod
    public void getRoot(PluginCall call) {
        Uri uri = rootUri();
        JSObject ret = new JSObject();
        if (uri != null && hasPermission(uri)) {
            ret.put("root", describeRoot(uri));
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void pickRoot(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, intent, "pickRootResult");
    }

    @ActivityCallback
    private void pickRootResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("cancelled");
            return;
        }
        Uri uri = result.getData().getData();
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            call.reject("permission: " + e.getMessage());
            return;
        }
        prefs().edit().putString(KEY_ROOT, uri.toString()).apply();
        JSObject ret = new JSObject();
        ret.put("root", describeRoot(uri));
        call.resolve(ret);
    }

    /** Walk/create nested folders under the root. path like "Level-1_Term-1/Mathematics-1/Class-01" */
    private DocumentFile ensureDir(String path) throws Exception {
        Uri root = rootUri();
        if (root == null || !hasPermission(root)) throw new Exception("no_root");
        DocumentFile dir = DocumentFile.fromTreeUri(getContext(), root);
        if (dir == null) throw new Exception("bad_root");
        if (path == null) return dir;
        for (String part : path.split("/")) {
            if (part.trim().isEmpty()) continue;
            DocumentFile next = dir.findFile(part);
            if (next == null || !next.isDirectory()) {
                next = dir.createDirectory(part);
            }
            if (next == null) throw new Exception("cannot_create_dir:" + part);
            dir = next;
        }
        return dir;
    }

    private String mimeFor(String name) {
        int i = name.lastIndexOf('.');
        if (i >= 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(i + 1).toLowerCase());
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    private String uniqueName(DocumentFile dir, String name) {
        if (dir.findFile(name) == null) return name;
        String base = name, ext = "";
        int i = name.lastIndexOf('.');
        if (i > 0) { base = name.substring(0, i); ext = name.substring(i); }
        for (int n = 1; n < 1000; n++) {
            String cand = base + " (" + n + ")" + ext;
            if (dir.findFile(cand) == null) return cand;
        }
        return base + "-" + System.currentTimeMillis() + ext;
    }

    /** begin({path, name, overwrite}) -> {handle, uri, name} */
    @PluginMethod
    public void begin(PluginCall call) {
        try {
            String path = call.getString("path", "");
            String name = call.getString("name", "file");
            boolean overwrite = Boolean.TRUE.equals(call.getBoolean("overwrite", false));
            DocumentFile dir = ensureDir(path);
            if (overwrite) {
                DocumentFile old = dir.findFile(name);
                if (old != null) old.delete();
            } else {
                name = uniqueName(dir, name);
            }
            DocumentFile f = dir.createFile(mimeFor(name), name);
            if (f == null) throw new Exception("cannot_create_file");
            OutputStream os = getContext().getContentResolver().openOutputStream(f.getUri(), "wt");
            if (os == null) throw new Exception("cannot_open_stream");
            String handle = UUID.randomUUID().toString();
            synchronized (streams) { streams.put(handle, os); }
            JSObject ret = new JSObject();
            ret.put("handle", handle);
            ret.put("uri", f.getUri().toString());
            ret.put("name", f.getName() != null ? f.getName() : name);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "begin_failed");
        }
    }

    @PluginMethod
    public void chunk(PluginCall call) {
        try {
            String handle = call.getString("handle");
            String data = call.getString("data", "");
            OutputStream os;
            synchronized (streams) { os = streams.get(handle); }
            if (os == null) throw new Exception("bad_handle");
            os.write(Base64.decode(data, Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "chunk_failed");
        }
    }

    @PluginMethod
    public void end(PluginCall call) {
        try {
            String handle = call.getString("handle");
            OutputStream os;
            synchronized (streams) { os = streams.remove(handle); }
            if (os != null) { os.flush(); os.close(); }
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "end_failed");
        }
    }

    /** read({uri}) -> {data: base64} */
    @PluginMethod
    public void read(PluginCall call) {
        try {
            Uri uri = Uri.parse(call.getString("uri", ""));
            InputStream in = getContext().getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("cannot_open");
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            JSObject ret = new JSObject();
            ret.put("data", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP));
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "read_failed");
        }
    }

    /** Walk existing folders only (never creates anything). Returns null when a folder is missing. */
    private DocumentFile walkDir(String path) {
        Uri root = rootUri();
        if (root == null || !hasPermission(root)) return null;
        DocumentFile dir = DocumentFile.fromTreeUri(getContext(), root);
        if (dir == null || path == null) return dir;
        for (String part : path.split("/")) {
            if (part.trim().isEmpty()) continue;
            DocumentFile next = dir.findFile(part);
            if (next == null || !next.isDirectory()) return null;
            dir = next;
        }
        return dir;
    }

    /** find({path, name}) -> {uri} or {} ; does not create folders */
    @PluginMethod
    public void find(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            DocumentFile dir = walkDir(call.getString("path", ""));
            if (dir != null) {
                DocumentFile f = dir.findFile(call.getString("name", ""));
                if (f != null && f.isFile()) ret.put("uri", f.getUri().toString());
            }
        } catch (Exception ignored) { }
        call.resolve(ret);
    }

    @PluginMethod
    public void remove(PluginCall call) {
        try {
            Uri uri = Uri.parse(call.getString("uri", ""));
            boolean ok = DocumentsContract.deleteDocument(getContext().getContentResolver(), uri);
            JSObject ret = new JSObject();
            ret.put("deleted", ok);
            call.resolve(ret);
        } catch (Exception e) {
            // already gone is fine
            JSObject ret = new JSObject();
            ret.put("deleted", false);
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void exists(PluginCall call) {
        boolean ok = false;
        try {
            DocumentFile f = DocumentFile.fromSingleUri(getContext(), Uri.parse(call.getString("uri", "")));
            ok = f != null && f.exists();
        } catch (Exception ignored) { }
        JSObject ret = new JSObject();
        ret.put("exists", ok);
        call.resolve(ret);
    }

    /** open({uri, mime}) -> launches an external viewer app */
    @PluginMethod
    public void open(PluginCall call) {
        try {
            Uri uri = Uri.parse(call.getString("uri", ""));
            String mime = call.getString("mime", "*/*");
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            Intent chooser = Intent.createChooser(intent, null);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "open_failed");
        }
    }
}
