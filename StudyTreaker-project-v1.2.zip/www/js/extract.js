'use strict';
/* Text extraction (offline): pdf, docx, pptx, txt/md/csv/json/html. Images are stored but not text-indexed. */
const Extract = {
  canIndex(name) { return /\.(pdf|docx|pptx|txt|md|csv|json|html?)$/i.test(name); },
  async run(name, buf, onProg) {
    const ext = (name.split('.').pop() || '').toLowerCase();
    if (ext === 'pdf') return this.pdf(buf, onProg);
    if (ext === 'docx') return this.docx(buf);
    if (ext === 'pptx') return this.pptx(buf);
    if (['txt', 'md', 'csv', 'json', 'html', 'htm'].includes(ext)) {
      let t = new TextDecoder('utf-8').decode(buf);
      if (ext.startsWith('htm')) t = t.replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ');
      return [{ page: 1, text: t }];
    }
    return [];
  },
  async pdf(buf, onProg) {
    if (!window.pdfjsLib) throw new Error('pdf.js missing');
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';
    const doc = await pdfjsLib.getDocument({ data: new Uint8Array(buf) }).promise;
    const pages = [];
    const LIG = { '\uFB00': 'ff', '\uFB01': 'fi', '\uFB02': 'fl', '\uFB03': 'ffi', '\uFB04': 'ffl' };
    for (let i = 1; i <= doc.numPages; i++) {
      const pg = await doc.getPage(i);
      const tc = await pg.getTextContent();
      let s = '', last = null;
      for (const it of tc.items) {
        const tr = it.transform || [1, 0, 0, 10, 0, 0];
        const x = tr[4], y = tr[5], h = Math.abs(tr[3]) || 10;
        if (last && it.str) {
          if (Math.abs(y - last.y) > h * 0.5) { if (!s.endsWith('\n')) s += '\n'; }
          else if (x - last.x > h * 0.18 && !s.endsWith(' ') && !it.str.startsWith(' ')) s += ' ';
        }
        s += it.str;
        if (it.str) last = { x: x + (it.width || 0), y };
        if (it.hasEOL) { s += '\n'; last = null; }
      }
      s = s.replace(/[\uFB00-\uFB04]/g, c => LIG[c]).replace(/\u0000/g, '').replace(/-\n(?=[a-z])/g, '');
      pages.push({ page: i, text: s });
      onProg && onProg(i / doc.numPages);
      pg.cleanup();
    }
    try { doc.cleanup(); } catch (e) { }
    return pages;
  },
  unxml(s) { return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&'); },
  async docx(buf) {
    const z = await JSZip.loadAsync(buf);
    const xml = await z.file('word/document.xml').async('string');
    const t = xml.replace(/<\/w:p>/g, '\n').replace(/<w:tab\/>/g, ' ').replace(/<[^>]+>/g, '');
    return [{ page: 1, text: this.unxml(t) }];
  },
  async pptx(buf) {
    const z = await JSZip.loadAsync(buf);
    const names = Object.keys(z.files).filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n))
      .sort((a, b) => parseInt(a.match(/\d+/)[0]) - parseInt(b.match(/\d+/)[0]));
    const out = [];
    for (let i = 0; i < names.length; i++) {
      const xml = await z.file(names[i]).async('string');
      out.push({ page: i + 1, text: this.unxml(xml.replace(/<\/a:p>/g, '\n').replace(/<[^>]+>/g, '')) });
    }
    return out;
  },
};
