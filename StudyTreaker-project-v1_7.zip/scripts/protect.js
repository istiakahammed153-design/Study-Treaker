// © Istiak Ahammed. All rights reserved.
// Release step: merges every www/js/*.js file into ONE obfuscated file (www/app.js)
// and removes the readable sources from the build folder, so the APK does not
// contain easy-to-edit code. Run after `npm run build:web` (the GitHub workflow does this).
const fs = require('fs');
const path = require('path');
const www = path.join(__dirname, '..', 'www');
const htmlPath = path.join(www, 'index.html');
let html = fs.readFileSync(htmlPath, 'utf8');

const re = /<script src="(js\/[^"]+\.js)"><\/script>\s*/g;
const files = []; let m;
while ((m = re.exec(html))) files.push(m[1]);
if (!files.length) { console.log('protect: nothing to do (already protected?)'); process.exit(0); }

const BANNER = '/*! Study Treaker (c) Istiak Ahammed / ইসতিয়াক আহাম্মেদ. All rights reserved. Copying, modifying or redistributing this code without written permission is prohibited. */\n';
let code = files.map(f => fs.readFileSync(path.join(www, f), 'utf8')).join('\n;\n');

try {
  const JO = require('javascript-obfuscator');
  code = JO.obfuscate(code, {
    compact: true,
    identifierNamesGenerator: 'mangled-shuffled',
    renameGlobals: false,
    stringArray: true,
    stringArrayEncoding: ['base64'],
    stringArrayThreshold: 0.75,
    stringArrayRotate: true,
    stringArrayShuffle: true,
    splitStrings: false,
    controlFlowFlattening: false,
    deadCodeInjection: false,
    selfDefending: false,
    debugProtection: false,
    unicodeEscapeSequence: false,
    target: 'browser',
  }).getObfuscatedCode();
  console.log('protect: obfuscated with javascript-obfuscator');
} catch (e) {
  console.warn('protect: obfuscator unavailable (' + e.message + ') - falling back to minify');
  try { code = require('esbuild').transformSync(code, { minify: true, target: 'es2019' }).code; }
  catch (e2) { console.warn('protect: esbuild unavailable either - plain bundle'); }
}

fs.writeFileSync(path.join(www, 'app.js'), BANNER + code);
let first = true;
html = html.replace(re, () => { if (first) { first = false; return '<script src="app.js"></script>\n'; } return ''; });
fs.writeFileSync(htmlPath, html);
fs.rmSync(path.join(www, 'js'), { recursive: true, force: true });
console.log('protect: ok -> www/app.js (' + files.length + ' files merged)');
