'use strict';
/* ---------- tiny helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const dstr = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => dstr(new Date());
const fmtSize = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
const fmtMin = m => { m = Math.round(m); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };
const COLORS = [
  ['#6366f1', '#818cf8'], ['#10b981', '#34d399'], ['#f59e0b', '#fbbf24'], ['#8b5cf6', '#a78bfa'],
  ['#f43f5e', '#fb7185'], ['#0ea5e9', '#38bdf8'], ['#14b8a6', '#2dd4bf'], ['#f97316', '#fb923c'],
];

/* ---------- state ---------- */
const KEY = 'st_state_v1';
const DEF = () => ({
  v: 1,
  profile: { name: '', lang: 'en', theme: 'auto', goal: 120, lock: '', onboarded: false },
  root: null,
  llm: { enabled: false, provider: 'gemini', url: 'https://generativelanguage.googleapis.com/v1beta/openai', model: 'gemini-flash-latest, gemini-flash-lite-latest', key: '', strict: false, ctx: 14000 },
  terms: [], activeTerm: null,
  classes: {}, todos: [], exams: [], sessions: [], chat: [],
  timer: { dur: 25, brk: 5, mode: 'focus', running: false, endsAt: 0, remaining: null, course: '' },
  lastBackup: 0,
});
const PRESETS = {
  gemini: { name: 'Google Gemini (free key)', url: 'https://generativelanguage.googleapis.com/v1beta/openai', model: 'gemini-flash-latest, gemini-flash-lite-latest' },
  openai: { name: 'OpenAI', url: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
  groq: { name: 'Groq (free key)', url: 'https://api.groq.com/openai/v1', model: 'llama-3.3-70b-versatile' },
  openrouter: { name: 'OpenRouter', url: 'https://openrouter.ai/api/v1', model: 'openrouter/auto' },
  ollama: { name: 'My own PC (Ollama / LM Studio)', url: 'http://192.168.0.10:11434/v1', model: 'llama3.2' },
  custom: { name: 'Custom (OpenAI-compatible)', url: '', model: '' },
};
function detectProvider(url) { for (const [k, p] of Object.entries(PRESETS)) if (p.url && url && url.replace(/\/+$/, '') === p.url) return k; return 'custom'; }
function mergeState(o) {
  const d = DEF(); o = o || {};
  const llm = Object.assign(d.llm, o.llm);
  if (llm.model === 'gemini-flash-latest') llm.model = 'gemini-flash-latest, gemini-flash-lite-latest';
  if (!(o.llm && o.llm.provider)) llm.provider = o.llm && o.llm.url ? detectProvider(o.llm.url) : 'gemini';
  return Object.assign(d, o, {
    profile: Object.assign(d.profile, o.profile), llm, timer: Object.assign(d.timer, o.timer),
  });
}
let S = (() => { try { const raw = localStorage.getItem(KEY); if (raw) return mergeState(JSON.parse(raw)); } catch (e) { } return DEF(); })();
let _saveT;
function save() {
  clearTimeout(_saveT);
  _saveT = setTimeout(() => {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { console.warn('save failed', e); }
    if (typeof Backup !== 'undefined') Backup.schedule();
  }, 150);
}
function saveNow() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { } }
document.addEventListener('visibilitychange', () => { if (document.hidden) saveNow(); });
window.addEventListener('pagehide', saveNow);

/* ---------- IndexedDB (file blobs for browser mode + text index) ---------- */
const DB = {
  _db: null,
  open() {
    return this._db ||= new Promise((res, rej) => {
      const r = indexedDB.open('st_db', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('blobs');
        d.createObjectStore('chunks', { keyPath: 'id' }).createIndex('fileId', 'fileId');
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  },
  async tx(store, mode, fn) {
    const db = await this.open();
    return new Promise((res, rej) => {
      const t = db.transaction(store, mode);
      let out;
      try { out = fn(t.objectStore(store)); } catch (e) { rej(e); return; }
      t.oncomplete = () => res(out && typeof out === 'object' && 'onsuccess' in out ? out.result : out);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  },
  put(store, val, key) { return this.tx(store, 'readwrite', s => { key === undefined ? s.put(val) : s.put(val, key); }); },
  get(store, key) { return this.tx(store, 'readonly', s => s.get(key)); },
  del(store, key) { return this.tx(store, 'readwrite', s => { s.delete(key); }); },
  all(store) { return this.tx(store, 'readonly', s => s.getAll()); },
  putMany(store, arr) { return this.tx(store, 'readwrite', s => { arr.forEach(v => s.put(v)); }); },
  delByIndex(store, idx, val) {
    return this.tx(store, 'readwrite', s => {
      const r = s.index(idx).openKeyCursor(IDBKeyRange.only(val));
      r.onsuccess = () => { const c = r.result; if (c) { s.delete(c.primaryKey); c.continue(); } };
    });
  },
  clear(store) { return this.tx(store, 'readwrite', s => { s.clear(); }); },
};

/* ---------- domain helpers ---------- */
const curTerm = () => S.terms.find(t => t.id === S.activeTerm) || S.terms[0] || null;
const courses = () => curTerm()?.courses || [];
const findCourse = id => { for (const t of S.terms) { const c = t.courses.find(c => c.id === id); if (c) return { course: c, term: t }; } return null; };
function eachFile(cb) { for (const T of S.terms) for (const c of T.courses) for (const [n, k] of Object.entries(S.classes[c.id] || {})) for (const f of (k.files || [])) cb({ T, c, n: +n, k, f }); }
const kindOf = n => { const e = (String(n).split('.').pop() || '').toLowerCase();
  return e === 'pdf' ? 'pdf' : /^(jpe?g|png|webp|gif|bmp|heic|heif)$/.test(e) ? 'img' : /^(docx?|txt|md|rtf|odt)$/.test(e) ? 'doc' : /^pptx?$/.test(e) ? 'ppt' : 'other'; };
const getCls = (cid, n) => (S.classes[cid] && S.classes[cid][n]) || null;
const ensureCls = (cid, n) => {
  S.classes[cid] ||= {};
  return S.classes[cid][n] ||= { n, done: false, star: false, date: '', note: '', topic: '', files: [], links: [], doneAt: '' };
};
const doneCount = c => { const m = S.classes[c.id] || {}; let k = 0; for (let i = 1; i <= c.total; i++) if (m[i]?.done) k++; return k; };
const minutesOn = ds => S.sessions.filter(s => dstr(new Date(s.ts)) === ds).reduce((a, s) => a + s.min, 0);
function activeDays() {
  const set = new Set(S.sessions.map(s => dstr(new Date(s.ts))));
  for (const m of Object.values(S.classes)) for (const c of Object.values(m)) if (c.doneAt) set.add(c.doneAt);
  return set;
}
function streak() {
  const days = activeDays();
  const d = new Date();
  if (!days.has(dstr(d))) d.setDate(d.getDate() - 1);
  let n = 0;
  while (days.has(dstr(d))) { n++; d.setDate(d.getDate() - 1); }
  return n;
}
const daysUntil = ds => Math.ceil((new Date(ds + 'T00:00:00') - new Date(today() + 'T00:00:00')) / 86400000);
const safeName = s => (String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').replace(/\s+/g, ' ').trim().slice(0, 60)) || 'untitled';
