'use strict';
/* Offline "local AI": BM25 retrieval over your files + extractive answers, summaries and question generation.
   Optional: forward retrieved passages to your own LLM server (Ollama / OpenAI-compatible). */
const STOP = new Set(('a an the of to in on at for and or but is are was were be been being am do does did done have has had it its this that these those with as by from into about over than then so such not no yes can could should would will shall may might must ' +
  'what which who whom whose when where why how i me my we our you your he she they them his her their there here also very just more most some any each other another ' +
  'explain define give tell make create generate show list write quiz question questions mcq summarize summary summarise overview please topic chapter lecture class ' +
  'কি কী কেন কিভাবে কীভাবে কোন কোনটি এই এটি এটা ওই এর তার তাদের আমার আমি আমরা তুমি ও এবং বা কিন্তু হলো হল হয় হয়ে হবে থেকে করে করা করো কর দাও দাও। সম্পর্কে বিষয়ে বলতে একটি একটা সারাংশ সংক্ষেপে প্রশ্ন প্রশ্নগুলো তৈরি কুইজ ব্যাখ্যা বর্ণনা লেখো লিখ').split(/\s+/));

function stem(w) {
  if (!/^[a-z]+$/.test(w)) return w;
  if (w.length > 4 && w.endsWith('ies')) return w.slice(0, -3) + 'y';
  if (w.length > 5 && w.endsWith('sses')) return w.slice(0, -2);
  if (w.length > 5 && w.endsWith('ing')) return w.slice(0, -3);
  if (w.length > 4 && w.endsWith('ed')) return w.slice(0, -2);
  if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us') && !w.endsWith('is')) return w.slice(0, -1);
  return w;
}
function tokenize(text, keepStop) {
  const m = String(text).toLowerCase().match(/[\p{L}\p{M}\p{N}‌‍]+/gu) || [];
  const out = [];
  for (const w of m) {
    if (!keepStop && (STOP.has(w) || (w.length < 2 && !/\d/.test(w)))) continue;
    out.push(stem(w));
  }
  return out;
}
function splitSentences(text) {
  return String(text).replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').split(/(?<=[.!?।])\s+|\n+/).map(s => s.trim()).filter(s => s.length >= 25 && s.length <= 400);
}
function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

function lev1(a, b) { // true if edit distance <= 1
  if (a === b) return true; const la = a.length, lb = b.length; if (Math.abs(la - lb) > 1) return false;
  let i = 0, j = 0, e = 0;
  while (i < la && j < lb) {
    if (a[i] === b[j]) { i++; j++; continue; }
    if (++e > 1) return false;
    if (la > lb) i++; else if (lb > la) j++; else { i++; j++; }
  }
  return e + (la - i) + (lb - j) <= 1;
}
const SQZ = /[\s\u200b-\u200d\u00ad\-_.,;:()]+/g;

const AI = {
  chunks: [], byFile: new Map(), vocab: new Map(), keys: null, N: 0, total: 0, avgLen: 1, ready: false, cache: new Map(),
  async load() { this.chunks = await DB.all('chunks'); this.build(); },
  build() {
    this.vocab = new Map(); this.byFile = new Map(); this.keys = null; this.total = 0; this.cache.clear();
    this.chunks.forEach((c, i) => this._idx(c, i));
    this.N = this.chunks.length; this.avgLen = this.total / Math.max(1, this.N); this.ready = true;
  },
  _idx(c, i) {
    const toks = tokenize(c.text); c._len = toks.length || 1; this.total += c._len;
    c._seq = Number(String(c.id).split(':').pop()) || 0; let bf = this.byFile.get(c.fileId); if (!bf) this.byFile.set(c.fileId, bf = []); bf.push(i);
    c._l = c.text.toLowerCase(); c._c = c._l.replace(SQZ, '');
    const tf = new Map(); toks.forEach(w => tf.set(w, (tf.get(w) || 0) + 1));
    tf.forEach((n, w) => { let p = this.vocab.get(w); if (!p) this.vocab.set(w, p = []); p.push([i, n]); });
  },
  _add(cs) { // incremental indexing: no full rebuild
    const base = this.chunks.length; this.chunks.push(...cs); cs.forEach((c, j) => this._idx(c, base + j));
    this.N = this.chunks.length; this.avgLen = this.total / Math.max(1, this.N); this.keys = null; this.cache.clear();
  },
  _keys() { return this.keys ||= [...this.vocab.keys()].sort(); },
  _prefix(p, cap = 30) { // binary search in sorted vocab
    const k = this._keys(); let lo = 0, hi = k.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (k[m] < p) lo = m + 1; else hi = m; }
    const out = []; for (let i = lo; i < k.length && k[i].startsWith(p) && out.length < cap; i++) out.push(k[i]); return out;
  },
  idf(w) { const p = this.vocab.get(w); const df = p ? p.length : 0; return Math.log(1 + (this.N - df + 0.5) / (df + 0.5)); },
  stats() { return { chunks: this.chunks.length, files: new Set(this.chunks.map(c => c.fileId)).size }; },
  makeChunks(meta, pages) {
    const out = []; let k = 0;
    for (const pg of pages) {
      const sents = String(pg.text).replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').split(/(?<=[.!?।])\s+|\n+/).map(s => s.trim()).filter(Boolean);
      let cur = '';
      const flush = () => { if (cur.trim().length > 30) out.push({ id: meta.fileId + ':' + (k++), ...meta, page: pg.page, text: cur.trim() }); cur = ''; };
      for (const s of sents) { if ((cur + ' ' + s).length > 700) flush(); cur += (cur ? ' ' : '') + s; }
      flush();
    }
    return out;
  },
  async addFile(meta, pages) {
    const cs = this.makeChunks(meta, pages);
    if (cs.length) { await DB.putMany('chunks', cs.map(c => ({ ...c }))); this._add(cs); }
    return cs.length;
  },
  async removeFile(fileId) { await DB.delByIndex('chunks', 'fileId', fileId); this.chunks = this.chunks.filter(c => c.fileId !== fileId); this.build(); },
  async removeCourse(courseId) {
    const ids = [...new Set(this.chunks.filter(c => c.courseId === courseId).map(c => c.fileId))];
    for (const id of ids) await DB.delByIndex('chunks', 'fileId', id);
    this.chunks = this.chunks.filter(c => c.courseId !== courseId); this.build();
  },
  _ok(c, sc) { return (!sc.courseId || c.courseId === sc.courseId) && (!sc.termId || c.termId === sc.termId) && (!sc.n || c.n === sc.n) && (!sc.fileId || c.fileId === sc.fileId); },

  /* ---- retrieval: BM25 + prefix (binary search) + phrase bonus + whitespace-insensitive + typo fallbacks, cached ---- */
  search(q, { courseId, termId, n, fileId, k = 8 } = {}) {
    const sc = { courseId, termId, n, fileId };
    const key = q + '|' + (courseId || '') + '|' + (termId || '') + '|' + (n || '') + '|' + (fileId || '') + '|' + k + '|' + this.N;
    let r = this.cache.get(key); if (r) return r;
    r = this._search(q, sc, k);
    if (this.cache.size > 80) this.cache.clear(); this.cache.set(key, r); return r;
  },
  _search(q, sc, k) {
    if (!this.N) return [];
    let qt = [...new Set(tokenize(q))];
    if (!qt.length) qt = [...new Set(tokenize(q, true))].filter(w => w.length >= 2);
    if (!qt.length) return [];
    const scores = new Map(); const add = (i, s) => scores.set(i, (scores.get(i) || 0) + s);
    for (const w of qt) {
      const terms = new Map([[w, 1]]); const pre = [w];
      if (w.length >= 4) for (let L = 1; L <= 3 && w.length - L >= 3; L++) pre.push(w.slice(0, -L));
      pre.forEach((p, pi) => this._prefix(p).forEach(v => { if (!terms.has(v)) terms.set(v, pi === 0 ? 0.7 : 0.5); }));
      for (const [v, wt] of terms) {
        const post = this.vocab.get(v); if (!post) continue; const idf = this.idf(v);
        for (const [i, tf] of post) {
          const c = this.chunks[i]; if (!this._ok(c, sc)) continue;
          add(i, wt * idf * (tf * 2.4) / (tf + 1.4 * (0.25 + 0.75 * c._len / this.avgLen)));
        }
      }
    }
    if (scores.size < 3) { // text with broken spacing / partial words: substring over whitespace-less text
      const ws = [...new Set(qt.map(w => w.replace(SQZ, '')).filter(w => w.length >= 3))];
      const raw = q.toLowerCase().replace(SQZ, '');
      for (let i = 0; i < this.chunks.length; i++) {
        const c = this.chunks[i]; if (scores.has(i) || !this._ok(c, sc)) continue;
        let n = 0; for (const w of ws) if (c._c.includes(w)) n++;
        if (!n && raw.length >= 3 && c._c.includes(raw)) n = 1;
        if (n) add(i, 0.8 * n);
      }
    }
    if (!scores.size) { // typo tolerance (edit distance 1) on vocabulary
      for (const w of qt) {
        if (w.length < 4) continue;
        for (const v of this.vocab.keys()) {
          if (Math.abs(v.length - w.length) > 1 || v[0] !== w[0] || !lev1(v, w)) continue;
          const idf = this.idf(v);
          for (const [i, tf] of this.vocab.get(v)) if (this._ok(this.chunks[i], sc)) add(i, 0.5 * idf * Math.min(tf, 3));
        }
      }
    }
    if (qt.length > 1 && scores.size) { const ph = q.toLowerCase().trim(); scores.forEach((s, i) => { if (this.chunks[i]._l.includes(ph)) scores.set(i, s * 1.5); }); }
    return [...scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, k).map(([i, s]) => ({ chunk: this.chunks[i], score: s }));
  },
  /* search class topics, notes, file names and links (works even when a file has no readable text) */
  metaSearch(q, { courseId, termId, n: onlyN } = {}) {
    const qt = [...new Set(tokenize(q, true).filter(w => w.length >= 2))]; if (!qt.length) return [];
    const stemmed = qt.map(w => w.length > 5 ? w.slice(0, -1) : w);
    const out = [];
    for (const T of S.terms) {
      if (termId && T.id !== termId) continue;
      for (const c of T.courses) {
        if (courseId && c.id !== courseId) continue;
        const cn = c.name.toLowerCase();
        for (const [n, k] of Object.entries(S.classes[c.id] || {})) {
          if (onlyN && +n !== +onlyN) continue;
          const topic = (k.topic || '').toLowerCase();
          const hay = topic + ' ' + (k.note || '').toLowerCase() + ' ' + k.files.map(f => f.name.toLowerCase()).join(' ') + ' ' + k.links.map(l => ((l.title || '') + ' ' + l.url).toLowerCase()).join(' ');
          let hit = 0; stemmed.forEach(w => { if (hay.includes(w) || cn.includes(w)) hit++; });
          if (!hit) continue;
          const files = k.files.filter(f => stemmed.some(w => f.name.toLowerCase().includes(w)));
          out.push({ c, T, n: +n, k, files, score: hit / qt.length + (stemmed.some(w => topic.includes(w)) ? 0.6 : 0) + (files.length ? 0.3 : 0) });
        }
      }
    }
    return out.sort((a, b) => b.score - a.score).slice(0, 6);
  },
  topics(courseId) { const seen = new Set(); const out = []; for (const T of S.terms) for (const c of T.courses) { if (courseId && c.id !== courseId) continue; for (const k of Object.values(S.classes[c.id] || {})) { const tp = (k.topic || '').trim(); if (tp && !seen.has(tp.toLowerCase())) { seen.add(tp.toLowerCase()); out.push(tp); } } } return out.slice(0, 12); },
  snippet(text, q, len = 220) {
    const qt = tokenize(q); const low = text.toLowerCase(); let pos = -1;
    for (const w of qt) { const p = low.indexOf(w.slice(0, Math.max(3, w.length - 1))); if (p >= 0 && (pos < 0 || p < pos)) pos = p; }
    const st = Math.max(0, (pos < 0 ? 0 : pos) - 60);
    return (st > 0 ? '…' : '') + text.slice(st, st + len) + (st + len < text.length ? '…' : '');
  },
  intent(q) {
    if (/\b(quiz|mcq|questions?|test me|practice)\b|প্রশ্ন|কুইজ|পরীক্ষা নাও/i.test(q)) return 'quiz';
    if (/\b(summar(y|ize|ise)|overview|brief|key points)\b|সারাংশ|সংক্ষেপ/i.test(q)) return 'summary';
    return 'qa';
  },
  topSentences(chunks, q, n) {
    const qt = new Set(tokenize(q)); const all = [];
    chunks.forEach((c, ci) => splitSentences(c.text).forEach((s, si) => {
      const toks = tokenize(s); if (!toks.length) return;
      let sc = 0; toks.forEach(w => { if (qt.has(w)) sc += this.idf(w) * 2; });
      sc = sc / Math.sqrt(toks.length) + (1 - ci * 0.1) * 0.3 - si * 0.02;
      all.push({ s, sc, c, ci, si });
    }));
    const ranked = all.sort((a, b) => b.sc - a.sc); const best = ranked[0]?.sc || 0;
    return ranked.filter(o => o.sc >= best * 0.55).slice(0, n).sort((a, b) => a.ci - b.ci || a.si - b.si);
  },
  summarize(chunks, n = 6) {
    const freq = new Map(); const sents = [];
    chunks.forEach((c, ci) => splitSentences(c.text).forEach((s, si) => { const toks = tokenize(s); toks.forEach(w => freq.set(w, (freq.get(w) || 0) + 1)); sents.push({ s, toks, c, ci, si }); }));
    sents.forEach(o => { o.sc = o.toks.reduce((a, w) => a + (freq.get(w) || 0) * this.idf(w), 0) / Math.sqrt(o.toks.length || 1); });
    return sents.filter(o => o.toks.length > 3).sort((a, b) => b.sc - a.sc).slice(0, n).sort((a, b) => a.ci - b.ci || a.si - b.si);
  },
  src(c) { return { fileId: c.fileId, fname: c.fname, page: c.page, courseId: c.courseId, n: c.n }; },
  dedupeSources(list) { const m = new Map(); list.forEach(c => m.set(c.fileId + ':' + c.page, this.src(c))); return [...m.values()].slice(0, 5); },
  foundOf(meta) { return meta.map(m => ({ cid: m.c.id, n: m.n, course: m.c.name, topic: m.k.topic || '', files: (m.files.length ? m.files : m.k.files).slice(0, 3).map(f => ({ id: f.id, name: f.name })) })); },

  /* ---------- LLM (the real "agent"): reads the retrieved/whole text of your files and explains, solves, summarises ---------- */
  llmReady() {
    const L = S.llm; if (!L.enabled || !L.url || !L.model) return false;
    return !!L.key || /^https?:\/\/(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(L.url);
  },
  fileChunks(fileId) { return (this.byFile.get(fileId) || []).map(i => this.chunks[i]).sort((a, b) => a._seq - b._seq); },
  /* all text of a class / one file, in reading order */
  scopeChunks(sc) {
    if (sc.fileId) return this.fileChunks(sc.fileId);
    if (sc.courseId && sc.n) { const k = getCls(sc.courseId, sc.n); return k ? k.files.flatMap(f => this.fileChunks(f.id)) : []; }
    return [];
  },
  /* pick the passages to show the LLM. If the whole class/file fits in the budget, send ALL of it. */
  buildContext(q, sc = {}, budget = 14000) {
    const scoped = !!(sc.fileId || (sc.courseId && sc.n));
    const pool = scoped ? this.scopeChunks(sc) : [];
    if (pool.length && pool.reduce((a, c) => a + c.text.length, 0) <= budget) return { chunks: pool, whole: true };
    let hits = this.search(q, { ...sc, k: 14 }).map(h => h.chunk);
    if (!hits.length && pool.length) hits = pool.slice(0, Math.max(3, Math.floor(budget / 700)));
    const picked = new Map(); let used = 0;
    const add = c => { if (!c || picked.has(c.id) || used + c.text.length > budget) return; picked.set(c.id, c); used += c.text.length; };
    hits.forEach(add);
    for (const c of hits.slice(0, 4)) { const arr = this.fileChunks(c.fileId), p = arr.indexOf(c); add(arr[p + 1]); add(arr[p - 1]); }
    const order = []; hits.forEach(c => { if (!order.includes(c.fileId)) order.push(c.fileId); });
    const chunks = [...picked.values()].sort((a, b) => (order.indexOf(a.fileId) - order.indexOf(b.fileId)) || (a._seq - b._seq));
    return { chunks, whole: false };
  },
  refsOf(chunks) { return chunks.map((c, i) => ({ i: i + 1, ...this.src(c) })); },
  _cool: {},
  /* every key x model pair; when one hits its free limit the next one is used automatically */
  keyList() { return [...new Set(String(S.llm.key || '').split(/[\s,;]+/).filter(k => k.length > 8))]; },
  /* check every key on its own so the student sees which one is wrong */
  async testKeys() {
    const model = String(S.llm.model || '').split(/[,\n]+/)[0].trim(); const out = [];
    for (const k of (this.keyList().length ? this.keyList() : [''])) {
      try { await this.chat1([{ role: 'user', content: 'Reply with the single word OK.' }], { k, m: model }); out.push({ k, ok: true }); }
      catch (e) { out.push({ k, ok: false, msg: e.code === 429 ? t('limit reached (works later)') : this.friendlyErr(e), limit: e.code === 429 }); }
    }
    return out;
  },
  combos() {
    const L = S.llm; const keys = this.keyList(); const models = String(L.model || '').split(/[,\n]+/).map(x => x.trim()).filter(Boolean);
    const out = []; for (const k of (keys.length ? keys : [''])) for (const m of models) out.push({ k, m }); return out;
  },
  stripSalam(x) { return String(x || '').replace(/^\s*(?:\**\s*)?(?:আস[-\s]?সালামু?\s?(?:আলাইকুম|আলাইকুম|ওয়া\s?আলাইকুম)|আসসালামুয়ালাইকুম|assalamu?\s?(?:alaikum|alaykum)|as-?salamu?\s?alaikum)\s*(?:\**)?\s*[,.!।:\-–—]*\s*/i, ''); },
  async chat(messages) {
    let last = null, tried = 0; const all = this.combos();
    for (const pass of [0, 1]) {
      for (const c of all) {
        const id = c.k.slice(-6) + '|' + c.m; if (pass === 0 && (this._cool[id] || 0) > Date.now()) continue;
        tried++;
        try { return await this.chat1(messages, c); }
        catch (e) {
          last = e; const x = e.code;
          if (x === 429 || (typeof x === 'number' && x >= 500)) { this._cool[id] = Date.now() + 60000; continue; }
          if (x === 401 || x === 403 || x === 404) { this._cool[id] = Date.now() + 600000; continue; }
          if (x === 'net' || x === 'empty') { this._cool[id] = Date.now() + 20000; continue; }
          throw e;
        }
      }
      if (tried) break;
    }
    if (last) throw last;
    const er = new Error(t('Too many requests or the free limit is reached. Wait a minute and try again.')); er.code = 429; throw er;
  },
  async chat1(messages, c) {
    const L = S.llm; const url = L.url.replace(/\/+$/, '') + '/chat/completions';
    const headers = { 'Content-Type': 'application/json' }; if (c.k) headers.Authorization = 'Bearer ' + c.k;
    const payload = { model: c.m, temperature: 0.3, stream: false, messages };
    let status, data;
    try {
      if (FS.native) { const r = await Native.http(url, { method: 'POST', headers, body: payload }); status = r.status; data = r.data; }
      else {
        const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), 120000);
        try { const r = await fetch(url, { method: 'POST', headers, body: JSON.stringify(payload), signal: ac.signal }); status = r.status; data = await r.text(); }
        finally { clearTimeout(tm); }
      }
    } catch (e) { const er = new Error(t('Could not reach the AI server. Check your internet connection and the URL.')); er.code = 'net'; throw er; }
    if (typeof data === 'string') { try { data = JSON.parse(data); } catch (e) { } }
    if (status >= 300) {
      const m = (data && (data.error?.message || data.message || (Array.isArray(data) && data[0]?.error?.message))) || '';
      const er = new Error(status === 401 || status === 403 ? t('The API key is wrong or has no access ({s}).', { s: status }) : status === 429 ? t('Too many requests or the free limit is reached. Wait a minute and try again.') : status === 404 ? t('Model or URL not found ({s}). Check the model name in Settings.', { s: status }) : t('The AI server returned an error ({s}). {m}', { s: status, m: String(m).slice(0, 140) }));
      er.code = status; throw er;
    }
    let out = data?.choices?.[0]?.message?.content; if (Array.isArray(out)) out = out.map(x => x.text || '').join('');
    if (!out || !String(out).trim()) { const er = new Error(t('The AI returned an empty answer. Try again.')); er.code = 'empty'; throw er; }
    return String(out).trim();
  },
  /* repeated questions cost nothing: answers are remembered on the phone */
  cacheKey(q, sc, hist) { return hist.length ? null : [sc.courseId || '', sc.n || '', sc.fileId || '', this.N, q.toLowerCase().replace(/\s+/g, ' ')].join('|'); },
  cacheGet(k) { try { const x = JSON.parse(localStorage.getItem('st_aicache') || '[]').find(y => y.k === k); return x ? x.v : null; } catch (e) { return null; } },
  cacheSet(k, v) { try { let a = JSON.parse(localStorage.getItem('st_aicache') || '[]').filter(y => y.k !== k); a.push({ k, v }); localStorage.setItem('st_aicache', JSON.stringify(a.slice(-40))); } catch (e) { } },
  /* "page 12", "p.5-6", "পৃষ্ঠা ১২", "১২ নম্বর পৃষ্ঠা" -> [12] (max 4 pages) */
  parsePages(q) {
    q = q.replace(/[০-৯]/g, d => '০১২৩৪৫৬৭৮৯'.indexOf(d));
    const m = q.match(/\b(?:pages?|pg|p)\.?\s*(?:no\.?|number)?\s*(\d{1,4})(?:\s*(?:-|–|to)\s*(\d{1,4}))?/i) || q.match(/(?:পৃষ্ঠা|পৃষ্ঠার|পাতা|পাতার)\s*(?:নং|নম্বর)?\s*(\d{1,4})(?:\s*(?:-|–|থেকে)\s*(\d{1,4}))?/) || q.match(/(\d{1,4})(?:\s*(?:-|–)\s*(\d{1,4}))?\s*(?:নং|নম্বর)?\s*(?:পৃষ্ঠা|পাতা)/);
    if (!m) return null; const a = +m[1]; let b = +(m[2] || m[1]); if (b < a) b = a; if (b - a > 3) b = a + 3;
    const r = []; for (let i = a; i <= b; i++) r.push(i); return r;
  },
  /* the PDF the question is about (file scope, or the PDF of the class) */
  pdfFor(sc) {
    let files = [];
    if (sc.fileId) { eachFile(x => { if (x.f.id === sc.fileId) files.push(x); }); }
    else if (sc.courseId && sc.n) { const loc = findCourse(sc.courseId), k = getCls(sc.courseId, sc.n); if (loc && k) files = k.files.map(f => ({ T: loc.term, c: loc.course, n: +sc.n, k, f })); }
    files = files.filter(x => kindOf(x.f.name) === 'pdf'); return files.find(x => !(x.f.chunks > 0)) || files[0] || null;
  },
  SALAM: 'আসসালামু আলাইকুম',
  SYS: 'Your name is Samaha Nusrat. You are a friendly, patient AI study tutor (an AI, not a human) inside the Study Treaker app, helping a university/college student. You were created by Istiak Ahammed (ইসতিয়াক আহাম্মেদ). Whenever you introduce yourself or are asked who made/created/built you, say clearly that "ইসতিয়াক আহাম্মেদ (Istiak Ahammed) আমাকে তৈরি করেছে" (in English: "Istiak Ahammed created me"); never claim any other company or person made you. Begin EVERY reply, without exception, with the greeting "আসসালামু আলাইকুম" (in Bengali script, even if the student writes in English), then continue with the answer. If the student greets you, greet back briefly and say who you are. The student\'s own study files were read for you; relevant extracts are given as numbered notes [1], [2]… (each with file name and page).\n' +
    'Rules:\n1. Base your answer on the notes first and cite them like [1] or [2][3] right after the sentence they support.\n' +
    '2. For maths/physics/numerical questions: solve step by step, show formulas and the final answer clearly. Write all maths in LaTeX using $...$ for inline and $$...$$ for display.\n' +
    '3. To explain a topic: start with a simple explanation, then the key points/formulas, then a small example if useful.\n' +
    '4. The notes were extracted automatically from PDFs/slides and may contain broken spacing, odd symbols or garbled Bengali. Interpret them sensibly; do not quote garbage.\n' +
    '5. Reply in the same language as the student\'s question (Bengali or English; mixed is fine). Be clear and not too long.\n',
  async askLLM(q, chunks, history = [], opt = {}) {
    const ctx = chunks.map((c, i) => `[${i + 1}] (${c.fname}, p.${c.page}) ${c.text}`).join('\n\n');
    let sys = this.SYS;
    if (opt.images) sys += '6. The student\'s PDF page(s) are attached as images and are the notes. Read the text and maths carefully from the images and cite them as [1].\n';
    else if (!chunks.length) sys += opt.strict ? '6. No notes matched. Say briefly that nothing about this was found in the student\'s files, and suggest keywords to try. Do NOT answer from general knowledge.\n'
      : '6. No notes matched. Say in one short line that this was not found in the student\'s files, then answer from your general knowledge.\n';
    else if (opt.strict) sys += '6. Answer ONLY from the notes. If they do not contain the answer, say so.\n';
    else sys += '6. If the notes are not enough, say what is missing and then complete the answer from your general knowledge, clearly marking that part as "outside your files".\n';
    const msgs = [{ role: 'system', content: sys }];
    history.slice(-6).forEach(h => msgs.push({ role: h.role, content: String(h.text).slice(0, 1500) }));
    const txt = (chunks.length ? `Notes:\n${ctx}\n\n` : '') + `Question: ${q}`;
    msgs.push({ role: 'user', content: opt.images ? [{ type: 'text', text: txt }, ...opt.images.map(u => ({ type: 'image_url', image_url: { url: u } }))] : txt });
    return this.chat(msgs);
  },
  async llmQuiz(chunks, n = 6) {
    const ctx = chunks.map((c, i) => `[${i + 1}] (${c.fname}, p.${c.page}) ${c.text}`).join('\n\n');
    const out = await this.chat([{ role: 'system', content: 'You write exam practice questions from study notes. Return ONLY a JSON array, no markdown fences, no commentary.' },
      { role: 'user', content: `Notes:\n${ctx}\n\nWrite ${n} multiple-choice questions based on these notes (same language as the notes; use plain text, no LaTeX if possible). Each item: {"q": string, "options": [4 strings], "answer": index 0-3, "explain": short string, "ref": note number}.` }]);
    const m = out.match(/\[[\s\S]*\]/); if (!m) throw new Error('bad_json');
    const arr = JSON.parse(m[0]); const res = [];
    for (const x of arr) {
      if (!x || !x.q || !Array.isArray(x.options) || x.options.length < 2 || !(x.answer >= 0 && x.answer < x.options.length)) continue;
      const c = chunks[(x.ref | 0) - 1] || chunks[0];
      res.push({ type: 'mcq', q: String(x.q), options: x.options.map(String), answer: +x.answer, explain: x.explain ? String(x.explain) : '', src: this.src(c) });
    }
    if (!res.length) throw new Error('bad_json'); return res.slice(0, n);
  },
  friendlyErr(e) { return e && e.message && e.code ? e.message : t('Something went wrong. Please try again.'); },

  /* instant (synchronous) for everything except the optional LLM */
  async answer(q, scope = {}, history = []) {
    q = q.trim(); const intent = this.intent(q);
    if (q.replace(/\s/g, '').length < 2) return { kind: 'short' };
    const useLLM = this.llmReady(); let err = '';
    if (useLLM) {
      try {
        const pages = this.parsePages(q), pdf = this.pdfFor(scope);
        if (pages && !pdf) return { kind: 'text', text: t('To read a PDF page, open the class and tap the ✨ button next to the PDF first.') };
        if (pages && pdf) {
          const u = await FS.resolve(pdf); save(); if (!u) return { kind: 'text', text: t('Could not open the file. It may have been moved or deleted.') };
          const r = await Extract.pdfImages(await FS.readBuf(u), pages);
          if (!r.images.length) return { kind: 'text', text: t('This PDF has only {n} pages.', { n: r.total }) };
          const text = await this.askLLM(q, [], history, { images: r.images });
          return { kind: 'text', text, llm: true, refs: [{ i: 1, courseId: pdf.c.id, n: pdf.n, fileId: pdf.f.id, fname: pdf.f.name, page: pages.join('–') }] };
        }
        if (scope.fileId && pdf && !(pdf.f.chunks > 0)) return { kind: 'text', text: t('This PDF is scanned, so I read it page by page. Tell me the page, for example: “page 12 – explain”.') };
        const ck = this.cacheKey(q, scope, history); const hit = ck && intent !== 'quiz' ? this.cacheGet(ck) : null;
        if (hit) return { kind: 'text', text: hit.text, refs: hit.refs, sources: [], llm: true };
        const ctx = this.buildContext(q, scope, +S.llm.ctx || 14000);
        const refs = this.refsOf(ctx.chunks);
        if (intent === 'quiz') {
          const qs = await this.llmQuiz(ctx.chunks.length ? ctx.chunks : this.sampleChunks(scope.courseId, 8), Math.min(15, +(q.match(/\b(\d{1,2})\b/) || [])[1] || 6));
          return { kind: 'quiz', questions: qs, sources: this.dedupeSources(ctx.chunks), llm: true };
        }
        const text = await this.askLLM(q, ctx.chunks, history, { strict: S.llm.strict });
        if (ck) this.cacheSet(ck, { text, refs });
        return { kind: 'text', text, refs, sources: [], llm: true, whole: ctx.whole, found: ctx.chunks.length ? [] : this.foundOf(this.metaSearch(q, scope)) };
      } catch (e) { console.warn('LLM failed', e); err = this.friendlyErr(e); }
    }
    const res = this.offlineAnswer(q, scope, intent);
    if (err) res.err = err; else if (!useLLM) res.offline = true;
    return res;
  },
  offlineAnswer(q, scope, intent) {
    const hits = this.search(q, { ...scope, k: intent === 'quiz' ? 10 : 8 });
    const meta = intent === 'qa' ? this.metaSearch(q, scope) : [];
    const chunks = hits.map(h => h.chunk);
    if (!chunks.length && !meta.length) return { kind: 'none', topics: this.topics(scope.courseId), q };
    if (intent === 'quiz') {
      const m = q.match(/\b(\d{1,2})\b/); const n = m ? Math.min(20, +m[1]) : 6;
      const qs = this.makeQuestions(chunks, n);
      return qs.length ? { kind: 'quiz', questions: qs, sources: this.dedupeSources(chunks) } : { kind: 'none', topics: this.topics(scope.courseId), q };
    }
    if (intent === 'summary') {
      const sm = this.summarize(chunks, 6);
      return { kind: 'text', bullets: sm.map(o => o.s), sources: this.dedupeSources(sm.map(o => o.c)) };
    }
    const found = this.foundOf(meta);
    if (!chunks.length) return { kind: 'text', text: t('Found in your classes and files:'), found };
    const passages = hits.slice(0, 3).map(h => ({ ...this.src(h.chunk), text: this.snippet(h.chunk.text, q, 240) }));
    const top = this.topSentences(chunks.slice(0, 5), q, 3);
    return { kind: 'text', bullets: top.map(o => o.s), passages, found, sources: this.dedupeSources(top.map(o => o.c)) };
  },
  sampleChunks(courseId, n = 8) {
    const pool = this.chunks.filter(c => !courseId || c.courseId === courseId);
    return shuffle(pool).slice(0, n);
  },

  /* ---- question generation ---- */
  makeQuestions(chunks, n = 6) {
    const sents = []; const seen = new Set();
    chunks.forEach(c => splitSentences(c.text).forEach(s => { if (s.length >= 40 && s.length <= 260 && !seen.has(s)) { seen.add(s); sents.push({ s, c }); } }));
    const rawWords = s => s.split(/\s+/).map(w => w.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ''));
    const pool = new Map();
    sents.forEach(({ s }) => rawWords(s).forEach(w => {
      const tk = tokenize(w); if (w.length < 4 || !tk.length) return;
      pool.set(w.toLowerCase(), { w, idf: this.idf(tk[0]), num: /\d/.test(w), bn: /[ঀ-৿]/.test(w) });
    }));
    const poolArr = [...pool.values()].sort((a, b) => b.idf - a.idf).slice(0, 80);
    const defs = [], mcqs = [];
    for (const { s, c } of shuffle(sents)) {
      const dm = s.match(/^([A-Z][\w\s\-()]{2,50}?)\s+(?:is|are|means|refers to|is defined as)\s+(.{20,})$/) || s.match(/^(.{2,40}?)\s+(?:হলো|হল|বলতে)\s+(.{12,})$/);
      if (dm) { defs.push({ type: 'flash', q: /[ঀ-৿]/.test(dm[1]) ? `${dm[1].trim()} কী?` : `What is ${dm[1].trim()}?`, a: s, src: this.src(c) }); continue; }
      const words = rawWords(s); let best = null, bs = -1;
      words.forEach((w, i) => {
        if (i === 0 || w.length < 4) return; const tk = tokenize(w); if (!tk.length) return;
        const sc = this.idf(tk[0]) + (/^\p{Lu}/u.test(w) ? 1 : 0) + (/\d/.test(w) ? 1 : 0);
        if (sc > bs) { bs = sc; best = w; }
      });
      if (!best) continue;
      const bl = best.toLowerCase(), num = /\d/.test(best), bn = /[ঀ-৿]/.test(best);
      const dis = shuffle(poolArr.filter(p => p.w.toLowerCase() !== bl && p.num === num && p.bn === bn)).slice(0, 3).map(p => p.w);
      const text = s.replace(best, '_____');
      if (dis.length === 3) {
        const options = shuffle([best, ...dis]);
        mcqs.push({ type: 'mcq', q: text, options, answer: options.indexOf(best), src: this.src(c) });
      } else mcqs.push({ type: 'fill', q: text, a: best, src: this.src(c) });
    }
    const out = [...defs.slice(0, Math.ceil(n / 3)), ...mcqs];
    return shuffle(out.slice(0, n * 2)).slice(0, n);
  },
};
