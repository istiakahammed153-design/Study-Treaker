'use strict';
const IC = {
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', flame: '<path d="M12 3c1 3 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>', chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>', globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>', shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>', cal: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 10h18"/>',
  home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  layers: '<path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="m2 12 10 5 10-5"/><path d="m2 17 10 5 10-5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  bot: '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V5"/><circle cx="12" cy="4" r="1"/><circle cx="9" cy="14" r="1.2"/><circle cx="15" cy="14" r="1.2"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  gear: '<path d="M4 6h9M19 6h1M4 12h3M13 12h7M4 18h11M21 18h-1"/><circle cx="16" cy="6" r="2.2"/><circle cx="10" cy="12" r="2.2"/><circle cx="17.5" cy="18" r="2.2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', x: '<path d="M18 6 6 18M6 6l12 12"/>', check: '<path d="m5 12 5 5 9-10"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>', send: '<path d="m4 12 16-8-6 16-3-7z"/>',
  play: '<path d="M7 4v16l13-8z"/>', pause: '<path d="M8 4v16M16 4v16"/>', reset: '<path d="M4 12a8 8 0 1 0 3-6.2M4 4v5h5"/>',
  star: '<path d="m12 3 2.8 5.8 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.3l1.1-6.2L3 9.7l6.2-.9z"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  file: '<path d="M7 3h7l5 5v13H7z"/>', cam: '<path d="M4 8h3l2-3h6l2 3h3v12H4z"/><circle cx="12" cy="14" r="3.5"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  cap: '<path d="M12 4 2 9l10 5 10-5zM6 12v4c3 3 9 3 12 0v-4"/>', chev: '<path d="m9 6 6 6-6 6"/>', edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>', book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/>', db: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>', zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>', minus: '<path d="M5 12h14"/>', copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>', refresh: '<path d="M20 12a8 8 0 1 1-3-6.2M20 4v5h-5"/>', folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>', eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>', spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>', warn: '<path d="M12 3 2 20h20z"/><path d="M12 10v5M12 18v.5"/>', pen: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
};
const svg = (n, s = 20) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${IC[n]}</svg>`;
const aiName = () => S.profile.lang === 'bn' ? 'সামাহা নুসরাত' : 'Samaha Nusrat';
const KICON = { pdf: '📕', img: '🖼️', doc: '📝', ppt: '📊', other: '📎' };
const fileIcon = n => { const e = (n.split('.').pop() || '').toLowerCase(); return e === 'pdf' ? '📕' : /^(jpe?g|png|webp|gif|bmp|heic)$/.test(e) ? '🖼️' : /^docx?$/.test(e) ? '📝' : /^(pptx?)$/.test(e) ? '📊' : /^(xlsx?|csv)$/.test(e) ? '📈' : /^(txt|md)$/.test(e) ? '📃' : '📎'; };

const UI = { tab: 'home', course: null, filter: 'all', toolTab: 'timer', stack: [], cur: null, sheet: null, draft: null,
  search: { q: '', all: false, course: '' }, aiSc: { courseId: '', n: 0, fileId: '', label: '' }, cEdit: false, cFilter: 'all' };
const aiScope = () => { const x = UI.aiSc; const o = {}; if (x.courseId) o.courseId = x.courseId; if (x.n) o.n = +x.n; if (x.fileId) o.fileId = x.fileId; return o; };

/* ---------- toast / progress / sheets ---------- */
let _toastT;
function toast(msg, ms = 2600) { const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(_toastT); _toastT = setTimeout(() => el.classList.remove('show'), ms); }
function setProgress(text, frac) {
  const el = $('#prog'); if (text == null) { el.classList.remove('show'); return; }
  el.classList.add('show'); $('#progText').textContent = text; $('#progBar').style.width = Math.round((frac || 0) * 100) + '%';
}
function openSheet(html, { full = false, center = false, page = false, onClose } = {}) {
  const w = document.createElement('div'); w.className = 'sheet-wrap' + (center ? ' center' : '');
  w.innerHTML = `<div class="backdrop" data-act="close-top"></div><div class="sheet${full ? ' full' : ''}${page ? ' page' : ''}">${html}</div>`;
  $('#overlay').appendChild(w);
  const o = { el: w, body: w.querySelector('.sheet'), onClose,
    set(h) { const st = this.body.scrollTop; this.body.innerHTML = h; this.body.scrollTop = st; },
    close() { const i = UI.stack.indexOf(o); if (i >= 0) UI.stack.splice(i, 1); w.remove(); o.onClose && o.onClose(); } };
  UI.stack.push(o); return o;
}
const closeTop = () => { const o = UI.stack[UI.stack.length - 1]; if (!o) return false; if (o === UI.sheet && UI.cEdit) { UI.cEdit = false; refreshClassSheet(); renderTop(); return true; } o.close(); return true; };
function confirmBox(msg, ok = 'Delete', danger = true) {
  return new Promise(res => {
    const s = openSheet(`<p class="cmsg">${esc(msg)}</p><div class="row end"><button class="btn ghost" data-r="0">${t('Cancel')}</button><button class="btn ${danger ? 'danger' : ''}" data-r="1">${esc(t(ok))}</button></div>`, { center: true, onClose: () => res(false) });
    $$('[data-r]', s.el).forEach(b => b.onclick = () => { res(b.dataset.r === '1'); s.onClose = null; s.close(); });
  });
}
function formSheet(title, fields, ok = 'Save') {
  return new Promise(res => {
    const f = fields.map(x => `<label class="fl">${esc(t(x.label))}${x.type === 'select'
      ? `<select id="f_${x.id}">${x.options.map(o => `<option value="${esc(o[0])}">${esc(o[1])}</option>`).join('')}</select>`
      : `<input id="f_${x.id}" type="${x.type || 'text'}" value="${esc(x.value || '')}" placeholder="${esc(x.ph || '')}">`}</label>`).join('');
    const s = openSheet(`<h3>${esc(t(title))}</h3>${f}<div class="row end"><button class="btn ghost" data-r="0">${t('Cancel')}</button><button class="btn" data-r="1">${esc(t(ok))}</button></div>`, { onClose: () => res(null) });
    $$('[data-r]', s.el).forEach(b => b.onclick = () => {
      if (b.dataset.r === '1') { const v = {}; fields.forEach(x => v[x.id] = $('#f_' + x.id, s.el).value.trim()); res(v); }
      else res(null);
      s.onClose = null; s.close();
    });
  });
}
function pickFiles(capture) {
  return new Promise(res => {
    const i = document.createElement('input'); i.type = 'file'; i.style.display = 'none';
    if (capture) { i.accept = 'image/*'; i.setAttribute('capture', 'environment'); } else i.multiple = true;
    i.onchange = () => { res([...i.files]); i.remove(); }; i.oncancel = () => { res([]); i.remove(); };
    document.body.appendChild(i); i.click();
  });
}
async function ensureRoot() {
  if (S.root) return true;
  if (FS.native && !(await confirmBox(t('Choose a folder where your files will be saved. You can pick Internal storage or an SD card.'), 'Choose folder', false))) return false;
  try { await FS.pickRoot(); renderAll(); return true; } catch (e) { toast(t('No folder selected')); return false; }
}

/* ---------- helpers for views ---------- */
const ringSvg = (pct, size = 96) => { const r = 40, c = 2 * Math.PI * r; return `<svg class="ring" width="${size}" height="${size}" viewBox="0 0 100 100"><circle cx="50" cy="50" r="${r}" class="rb"/><circle cx="50" cy="50" r="${r}" class="rf" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - pct / 100)}" transform="rotate(-90 50 50)"/><text x="50" y="57" text-anchor="middle">${pct}%</text></svg>`; };
const grad = c => { const g = COLORS[(c.color || 0) % COLORS.length]; return `background:linear-gradient(135deg,${g[0]},${g[1]})`; };
const empty = (icon, msg, btn, act) => `<div class="empty"><div class="eico">${icon}</div><p>${esc(t(msg))}</p>${btn ? `<button class="btn" data-act="${act}">${esc(t(btn))}</button>` : ''}</div>`;
function greeting() { const h = new Date().getHours(); return h < 12 ? ['Good Morning', '☀️'] : h < 17 ? ['Good Afternoon', '🌤️'] : h < 21 ? ['Good Evening', '🌆'] : ['Good Night', '🌙']; }
function courseCard(c) {
  const d = doneCount(c), p = c.total ? Math.round(d * 100 / c.total) : 0;
  return `<div class="crow2" data-act="open-course" data-id="${c.id}"><div class="cr-main"><b>${esc(c.name)}</b><small>${d}/${c.total} ${t('Classes')}</small><div class="bar thin"><i style="width:${p}%"></i></div></div><span class="cr-pct">${p}%</span><span class="kgo">${svg('chev', 18)}</span></div>`;
}

/* ---------- header / tabs ---------- */
function renderTop() {
  $('#top').innerHTML = UI.tab === 'search' ? `<div class="hbar"><button class="ibtn rd" data-act="tab" data-tab="home" aria-label="${t('Back')}">${svg('back', 22)}</button></div>` : '';
}
function renderTabs() {
  const cur = UI.tab === 'classes' ? 'courses' : UI.tab === 'search' ? 'home' : UI.tab;
  const b = (k, ic, lb) => `<button class="${cur === k ? 'on' : ''}" data-act="tab" data-tab="${k}">${svg(ic, 22)}<span>${t(lb)}</span></button>`;
  $('#tabs').innerHTML = b('home', 'home', 'Home') + b('courses', 'book', 'Courses') + `<button class="fab ${cur === 'ai' ? 'on' : ''}" data-act="tab" data-tab="ai" aria-label="${aiName()}">${svg('spark', 26)}</button>` + b('tools', 'clock', 'Focus') + b('profile', 'user', 'Profile');
}
const ringW = (p, z = 78) => { const r = 32, c = 2 * Math.PI * r; return `<svg width="${z}" height="${z}" viewBox="0 0 80 80"><circle cx="40" cy="40" r="${r}" fill="none" stroke="rgba(255,255,255,.22)" stroke-width="8"/><circle cx="40" cy="40" r="${r}" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-dasharray="${(c * p / 100).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 40 40)"/><text x="40" y="46" text-anchor="middle" font-size="18" font-weight="800" fill="#fff">${p}%</text></svg>`; };
const scrollChat = () => setTimeout(() => window.scrollTo(0, document.body.scrollHeight), 30);
function renderAll() { applyTheme(); renderTop(); renderTabs(); renderView(); tickTimer(); }
const CREATOR = { en: 'Istiak Ahammed', bn: 'ইসতিয়াক আহাম্মেদ' };
const copyFoot = () => `<footer class="cpr">© ${new Date().getFullYear()} ${CREATOR.bn} · ${CREATOR.en}<br>${t('All rights reserved.')}</footer>`;
function renderView() { const v = $('#view'); v.innerHTML = Views[UI.tab]() + (UI.tab === 'ai' ? '' : copyFoot()); if (UI.tab === 'ai') scrollChat(); if (UI.tab === 'search') runSearch(); updateCountdowns(); }
function updateCountdowns() {
  $$('[data-cd]').forEach(el => { const ms = new Date(el.dataset.cd + 'T00:00:00') - Date.now(); let x;
    if (ms <= 0) x = t('Today'); else { const d = Math.floor(ms / 864e5), h = Math.floor(ms % 864e5 / 36e5), m = Math.floor(ms % 36e5 / 6e4), sc = Math.floor(ms % 6e4 / 1e3); x = d > 0 ? `${d}d ${pad(h)}h ${pad(m)}m` : `${pad(h)}:${pad(m)}:${pad(sc)}`; }
    if (el.textContent !== x) el.textContent = x; });
}
function applyTheme() {
  const th = S.profile.theme; const dark = th === 'dark' || (th === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.documentElement.lang = S.profile.lang;
}

/* ---------- views ---------- */
const Views = {
  home() {
    const term = curTerm();
    if (!term) return empty('🎓', 'Create your first Level/Term to begin.', 'Get started', 'open-term');
    const cs = courses(); const total = cs.reduce((a, c) => a + c.total, 0), done = cs.reduce((a, c) => a + doneCount(c), 0);
    const goal = S.profile.goal || 120, tm = minutesOn(today()), pct = Math.min(100, Math.round(tm * 100 / goal));
    const all = S.sessions.reduce((a, x) => a + x.min, 0);
    const week = []; for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); week.push({ on: minutesOn(dstr(d)) > 0, now: i === 0, l: d.toLocaleDateString(S.profile.lang === 'bn' ? 'bn-BD' : 'en', { weekday: 'narrow' }) }); }
    const row = c => {
      const d = doneCount(c); let n = 0; for (let i = 1; i <= c.total; i++) if (!getCls(c.id, i)?.done) { n = i; break; }
      const k = n ? getCls(c.id, n) : null; const col = COLORS[(c.color || 0) % 8][0]; const busy = k && (k.files.length || k.note || k.topic);
      return `<div class="srow3" data-act="open-course" data-id="${c.id}"><i class="sbar" style="background:${col}"></i><div class="sb"><small>${d}/${c.total} ${t('Classes')}</small><b>${esc(c.name)}</b>${n ? `<small class="st ${busy ? 'wip' : ''}">${busy ? t('In progress') : t('Up next')} · ${t('Class')} #${n}${k && k.topic ? ' · ' + esc(k.topic.slice(0, 22)) : ''}</small>` : `<small class="st ok">${svg('check', 12)} ${t('Completed')}</small>`}</div><span class="sico ${n ? (busy ? 'wip' : '') : 'ok'}">${n ? svg('chev', 16) : svg('check', 16)}</span></div>`;
    };
    const nm = (S.profile.name || '').trim();
    return `<section class="hero"><div class="hero-top"><div class="hav">${esc((nm || 'S').charAt(0).toUpperCase())}</div><div class="hero-txt"><h2>${t('Hello')}${nm ? ', ' + esc(nm) : ''} 👋</h2><p>${t('Keep going! You are doing great!')}</p></div><button class="ibtn rd" data-act="tab" data-tab="search" aria-label="${t('Search')}">${svg('search', 20)}</button></div><button class="tsel" data-act="open-settings" data-sec="term"><span class="ti">${svg('cap', 20)}</span><span class="tx"><small>${t('Current term')}</small><b>${esc(term.name)}</b></span><span class="tc">${svg('chev', 18)}</span></button></section>
    <div class="today"><div class="tl"><div class="tt">${svg('clock', 18)} ${t('Today Studied')}</div><div class="tbig">${fmtMin(tm)}</div><div class="tg">/ ${fmtMin(goal)} ${t('Goal')}</div></div>
      <button class="tv" data-act="goto-tools" data-tt="stats">${t('View Details')} →</button><div class="tr">${ringW(pct)}</div>
      <button class="tgo" data-act="goto-timer">${svg('play', 16)} ${t('Start focus')}</button></div>
    <div class="weekr">${week.map(w => `<div class="${w.on ? 'on' : ''} ${w.now ? 'now' : ''}"><i>${w.on ? svg('check', 12) : ''}</i><small>${w.l}</small></div>`).join('')}</div>
    <div class="kpis3"><div><span class="ki g">${svg('clock', 18)}</span><small>${t('Total Study Hours')}</small><b>${fmtMin(all)}</b></div><div><span class="ki o">${svg('flame', 18)}</span><small>${t('Day streak')}</small><b>${streak()}</b></div><div><span class="ki p">${svg('check', 18)}</span><small>${t('Completed Classes')}</small><b>${done}/${total}</b></div></div>
    <div class="sech"><h3>${t('Continue Learning')}</h3></div>
    ${cs.length ? cs.slice(0, 5).map(row).join('') : empty('📘', 'No courses yet. Add your subjects.', 'Add courses', 'open-courses')}`;
  },
  courses() {
    const term = curTerm(); if (!term) return Views.home(); const cs = courses();
    return `<div class="ptop"><h2>${t('Courses')}</h2><button class="round-add" data-act="open-courses" aria-label="${t('Add courses')}">${svg('plus', 20)}</button></div>
    ${cs.map(c => { const d = doneCount(c), p = c.total ? Math.round(d * 100 / c.total) : 0, col = COLORS[(c.color || 0) % 8][0];
      return `<div class="pcard2" style="--c:${col}"><div class="pcl" data-act="open-course" data-id="${c.id}"><span class="pic">${svg('book', 24)}</span><div class="pm"><b>${esc(c.name)}</b><small>${d} / ${c.total} ${t('Classes')} · ${p}%</small><div class="bar thin"><i style="width:${p}%"></i></div></div></div><button class="ibtn pen2" data-act="course-edit" data-id="${c.id}" aria-label="${t('Edit')}">${svg('pen', 18)}</button></div>`; }).join('') || empty('📘', 'No courses yet. Add your subjects.', 'Add courses', 'open-courses')}`;
  },
  profile() {
    const p = S.profile; const term = curTerm(); const r = (ic, lb, sub, act, extra = '') => `<button class="prow2" data-act="${act}" ${extra}><span class="pi">${svg(ic, 19)}</span><span class="pl">${t(lb)}</span><small>${sub || ''}</small>${svg('chev', 17)}</button>`;
    return `<div class="ptop"><h2>${t('Profile')}</h2></div>
    <div class="pcard"><div class="avatar">${esc((p.name || 'S').trim().charAt(0).toUpperCase())}</div><div class="pn"><b>${esc(p.name || t('Student'))}</b><small>${esc(term ? term.name : '')}</small><button class="edpill" data-act="open-settings" data-sec="profile">${t('Edit Profile')}</button></div></div>
    <div class="plist">${r('spark', 'AI engine', AI.llmReady() ? t('Connected') : '', 'open-settings', 'data-sec="ai"')}${r('folder', 'Storage & backup', '', 'open-settings', 'data-sec="storage"')}${r('shield', 'Security', p.lock ? t('On') : '', 'open-settings', 'data-sec="security"')}
      <label class="prow2"><span class="pi">${svg('moon', 19)}</span><span class="pl">${t('Dark Mode')}</span><input type="checkbox" class="swin" ${p.theme === 'dark' ? 'checked' : ''} data-change="dark-toggle"></label>
      ${r('globe', 'Language', p.lang === 'bn' ? 'বাংলা' : 'English', 'lang-toggle')}</div>
    <div class="about"><b>Study Treaker v1.7</b><small>${t('Created by')} ${CREATOR.bn} (${CREATOR.en})</small></div>`;
  },
  classes() {
    const term = curTerm(); if (!term) return Views.home();
    const c = courses().find(x => x.id === UI.course); if (!c) return Views.home();
    const d = doneCount(c); let items = '';
    for (let i = 1; i <= c.total; i++) {
      const k = getCls(c.id, i) || { n: i, files: [], links: [] };
      const meta = [k.date ? esc(k.date) : '', k.files.length ? '📎 ' + k.files.length : '', k.links.length ? '🔗 ' + k.links.length : ''].filter(Boolean).join('  ·  ');
      items += `<div class="klass ${k.done ? 'done' : ''}"><button class="num" data-act="toggle-done" data-n="${i}" aria-label="done">${k.done ? svg('check', 18) : i}</button>
        <div class="kb" data-act="open-class" data-cid="${c.id}" data-n="${i}"><b class="kt2 ${k.topic ? '' : 'ph'}">${esc(k.topic || t('Add topic'))}</b>${meta ? `<span class="km">${meta}</span>` : ''}</div><span class="kgo">${svg('chev', 18)}</span></div>`;
    }
    return `<div class="mhead row"><button class="ibtn" data-act="course-back" aria-label="${t('Back')}">${svg('back', 22)}</button><div><h2>${esc(c.name)}</h2><p class="muted">${d}/${c.total} ${t('Classes')}</p></div></div>${items}`;
  },
  search() {
    const cs = courses();
    return `<div class="sbox">${svg('search')}<input id="q" type="search" placeholder="${t('Search topics, notes, files, and text inside files…')}" value="${esc(UI.search.q)}" data-input="search" autocomplete="off"></div>
    <div class="filters"><button class="${UI.search.all ? '' : 'on'}" data-act="search-scope" data-v="0">${t('This term')}</button><button class="${UI.search.all ? 'on' : ''}" data-act="search-scope" data-v="1">${t('All terms')}</button>
    <select data-change="search-course"><option value="">${t('All courses')}</option>${cs.map(c => `<option value="${c.id}" ${UI.search.course === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div><div id="sres"></div>`;
  },
  ai() {
    const cs = courses(); const ready = AI.llmReady(); const sc = UI.aiSc; const label = sc.fileId || sc.n ? esc(sc.label) : '';
    const scanned = sc.fileId && (() => { const p = AI.pdfFor(sc); return p && !(p.f.chunks > 0); })();
    const sug = [[t('Explain this topic in simple words') + ': ', '💡'], [t('Solve step by step') + ': ', '🧮']];
    const empty0 = `<div class="aiempty"><h2>${t('Hi, I am {n}. What do you want to learn?', { n: aiName() })}</h2>${sug.map(x => `<button class="sugg" data-act="ai-prefill" data-p="${esc(x[0])}">${x[1]} ${esc(x[0].replace(/: $/, ''))}</button>`).join('')}<button class="sugg" data-act="ai-quick" data-k="quiz">🎯 ${t('Quick quiz')}</button>${ready ? '' : `<button class="sugg conn" data-act="open-settings" data-sec="ai">✨ ${t('Connect AI')}</button>`}</div>`;
    return `<div class="ptop"><h2>${aiName()}</h2>${S.chat.length ? `<button class="round-add soft" data-act="ai-clear" aria-label="${t('Clear chat')}">${svg('trash', 19)}</button>` : ''}</div><div class="aibar"><select data-change="ai-course"><option value="">${t('All my files')}</option>${cs.map(c => `<option value="${c.id}" ${sc.courseId === c.id && !sc.n && !sc.fileId ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
        ${label ? `<span class="scopechip"><span>${label}</span><button data-act="ai-scope-clear" aria-label="x">${svg('x', 14)}</button></span>` : ''}</div>
      ${scanned ? `<p class="muted sm hintl">${t('This PDF is scanned, so I read it page by page. Tell me the page, for example: “page 12 – explain”.')}</p>` : ''}
      <div id="chatLog" class="chat">${S.chat.map(chatHtml).join('') || empty0}</div>
      <div class="composer"><div id="aiLive" class="live"></div><div class="crow2b"><textarea id="aiq" rows="1" placeholder="${t('Ask {n}…', { n: aiName() })}" data-input="ai-live"></textarea><button class="btn round" data-act="ai-send" aria-label="send">${svg('send', 20)}</button></div></div>`;
  },
  tools() {
    const hd = `<div class="ptop"><h2>${t('Focus')}</h2></div>`;
    const T = [['timer', '⏱️', 'Timer'], ['todo', '✅', 'To-Do'], ['exams', '📅', 'Exams'], ['stats', '📊', 'Stats']];
    return `<div class="seg">${T.map(x => `<button class="${UI.toolTab === x[0] ? 'on' : ''}" data-act="tool-tab" data-tt="${x[0]}">${x[1]} ${t(x[2])}</button>`).join('')}</div>${Tools[UI.toolTab]()}`.replace(/^/, hd);
  },
};

/* ---------- search ---------- */
let _st;
function runSearch() {
  const box = $('#sres'); if (!box) return; const q = UI.search.q.trim();
  if (!q) { box.innerHTML = empty('🔎', 'Type a topic, note, file name, or any word inside your files.'); return; }
  const ql = q.toLowerCase(); const termId = UI.search.all ? null : curTerm()?.id; const out = { cls: [], files: [] };
  for (const T of S.terms) { if (termId && T.id !== termId) continue;
    for (const c of T.courses) { if (UI.search.course && c.id !== UI.search.course) continue;
      for (const [n, k] of Object.entries(S.classes[c.id] || {})) {
        if ((k.topic + ' ' + k.note + ' ' + k.links.map(l => l.title + l.url).join(' ')).toLowerCase().includes(ql)) out.cls.push({ c, n, k });
        k.files.forEach(f => { if (f.name.toLowerCase().includes(ql)) out.files.push({ c, n, k, f }); });
      } } }
  const hits = AI.search(q, { courseId: UI.search.course || null, termId, k: 12 });
  const hl = s => { let r = esc(s); tokenize(q).forEach(w => { try { r = r.replace(new RegExp('(' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[\\p{L}\\p{M}]*)', 'giu'), '<mark>$1</mark>'); } catch (e) { } }); return r; };
  let h = '';
  if (out.cls.length) h += `<h4 class="sec2">${t('Classes')}</h4>` + out.cls.slice(0, 20).map(x => `<div class="card res" data-act="open-class" data-cid="${x.c.id}" data-n="${x.n}"><b>${esc(x.c.name)} · #${x.n}</b><div>${hl(x.k.topic)}</div><small>${hl(x.k.note)}</small></div>`).join('');
  if (out.files.length) h += `<h4 class="sec2">${t('Files')}</h4>` + out.files.slice(0, 20).map(x => `<div class="card res" data-act="file-open" data-cid="${x.c.id}" data-n="${x.n}" data-id="${x.f.id}"><b>${fileIcon(x.f.name)} ${hl(x.f.name)}</b><small>${esc(x.c.name)} · #${x.n}</small></div>`).join('');
  if (hits.length) h += `<h4 class="sec2">${t('Inside your files')}</h4>` + hits.map(({ chunk: c }) => `<div class="card res"><b>${fileIcon(c.fname)} ${esc(c.fname)}</b><small>${esc(findCourse(c.courseId)?.course.name || '')} · #${c.n} · ${t('page')} ${c.page}</small><p>${hl(AI.snippet(c.text, q))}</p>
    <div class="row"><button class="btn ghost sm" data-act="open-class" data-cid="${c.courseId}" data-n="${c.n}">${t('Open class')}</button><button class="btn ghost sm" data-act="file-open" data-cid="${c.courseId}" data-n="${c.n}" data-id="${c.fileId}">${t('Open file')}</button></div></div>`).join('');
  box.innerHTML = h || empty('🤷', 'No results found.');
}

/* ---------- AI chat ---------- */
/* small markdown + LaTeX renderer for tutor answers (uses KaTeX when it is bundled) */
function mdHtml(src, refs) {
  const codes = [], maths = [];
  let s = String(src || '').replace(/\r/g, '');
  s = s.replace(/```[^\n`]*\n?([\s\S]*?)```/g, (m, c) => { codes.push(c.replace(/\n$/, '')); return `\u0000C${codes.length - 1}\u0000`; });
  const mk = (tex, d) => { maths.push({ tex: tex.trim(), d }); return `\u0000M${maths.length - 1}\u0000`; };
  s = s.replace(/\$\$([\s\S]+?)\$\$/g, (m, a) => mk(a, true)).replace(/\\\[([\s\S]+?)\\\]/g, (m, a) => mk(a, true))
    .replace(/\\\(([\s\S]+?)\\\)/g, (m, a) => mk(a, false)).replace(/\$(?=[^\s$])([^\n$]+?)(?<=[^\s$])\$(?!\d)/g, (m, a) => mk(a, false));
  const inline = x => {
    x = esc(x).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g, '$1<em>$2</em>');
    if (refs && refs.length) x = x.replace(/\[(\d{1,2}(?:\s*,\s*\d{1,2})*)\]/g, (m, g) => g.split(/\s*,\s*/).map(num => { const r = refs[+num - 1]; return r ? `<button class="cite" data-act="file-open" data-cid="${esc(r.courseId)}" data-n="${r.n}" data-id="${esc(r.fileId)}" title="${esc(r.fname)} · p.${r.page}">${num}</button>` : `[${num}]`; }).join(''));
    return x;
  };
  const lines = s.split('\n'); let out = '', i = 0, para = [], list = null, m;
  const flushP = () => { if (para.length) { out += `<p>${para.map(inline).join('<br>')}</p>`; para = []; } };
  const flushL = () => { if (list) { out += `<${list.t}>${list.items.map(x => `<li>${inline(x)}</li>`).join('')}</${list.t}>`; list = null; } };
  const isRow = l => /^\s*\|.*\|\s*$/.test(l);
  while (i < lines.length) {
    const ln = lines[i];
    if (/^\s*$/.test(ln)) { flushP(); flushL(); i++; continue; }
    if (/^\u0000C\d+\u0000$/.test(ln.trim())) { flushP(); flushL(); out += ln.trim(); i++; continue; }
    if ((m = ln.match(/^#{1,4}\s+(.*)$/))) { flushP(); flushL(); out += `<h5 class="mdh">${inline(m[1])}</h5>`; i++; continue; }
    if (isRow(ln) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}:?[\s:|-]*$/.test(lines[i + 1])) {
      flushP(); flushL(); const cells = l => l.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
      const head = cells(ln); i += 2; const rows = []; while (i < lines.length && isRow(lines[i])) rows.push(cells(lines[i++]));
      out += `<div class="mdt"><table><thead><tr>${head.map(c => `<th>${inline(c)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`; continue;
    }
    if ((m = ln.match(/^\s*[-*•]\s+(.*)$/))) { flushP(); if (!list || list.t !== 'ul') { flushL(); list = { t: 'ul', items: [] }; } list.items.push(m[1]); i++; continue; }
    if ((m = ln.match(/^\s*\d+[.)]\s+(.*)$/))) { flushP(); if (!list || list.t !== 'ol') { flushL(); list = { t: 'ol', items: [] }; } list.items.push(m[1]); i++; continue; }
    flushL(); para.push(ln); i++;
  }
  flushP(); flushL();
  out = out.replace(/\u0000C(\d+)\u0000/g, (x, k) => `<pre><code>${esc(codes[+k])}</code></pre>`);
  out = out.replace(/\u0000M(\d+)\u0000/g, (x, k) => {
    const o = maths[+k];
    try { if (typeof katex !== 'undefined') return katex.renderToString(o.tex, { displayMode: o.d, throwOnError: false, strict: 'ignore' }); } catch (e) { }
    return `<code class="tex">${esc(o.tex)}</code>`;
  });
  return out;
}
const msgPlain = m => m.text || (m.bullets || []).join('\n') || '';
function chatHtml(m, i) {
  if (m.role === 'user') return `<div class="bubble me"><p>${esc(m.text)}</p></div>`;
  let body = m.llm && m.text ? `<div class="md">${mdHtml(AI.stripSalam(m.text), m.refs)}</div>` : m.bullets ? '<ul>' + m.bullets.map(b => `<li>${esc(b)}</li>`).join('') + '</ul>' : m.text ? m.text.split('\n').filter(Boolean).map(p => `<p>${esc(p)}</p>`).join('') : '';
  if (m.err) body = `<div class="aerr">${svg('warn', 16)} <span>${esc(m.err)}</span></div>` + body;
  if (m.passages?.length) body += `<div class="psgs">${m.passages.map(p => `<div class="psg"><div class="ph">${fileIcon(p.fname)} <b>${esc(p.fname)}</b><span>p.${p.page}</span></div><p>${esc(p.text)}</p><div class="row"><button class="src" data-act="file-open" data-cid="${p.courseId}" data-n="${p.n}" data-id="${p.fileId}">${t('Open file')}</button><button class="src" data-act="open-class" data-cid="${p.courseId}" data-n="${p.n}">${t('Open class')}</button></div></div>`).join('')}</div>`;
  if (m.found?.length) body += `<div class="psgs">${m.found.map(f => `<div class="psg"><div class="ph">📘 <b>${esc(f.course)} · #${f.n}</b></div>${f.topic ? `<p>${esc(f.topic)}</p>` : ''}<div class="srcs">${f.files.map(x => `<button class="src" data-act="file-open" data-cid="${f.cid}" data-n="${f.n}" data-id="${x.id}">${fileIcon(x.name)} ${esc(x.name.slice(0, 28))}</button>`).join('')}<button class="src" data-act="open-class" data-cid="${f.cid}" data-n="${f.n}">${t('Open class')}</button></div></div>`).join('')}</div>`;
  if (m.questions) body += `<p>${t('I made {n} questions from your notes.', { n: m.questions.length })}</p><button class="btn sm" data-act="quiz-start" data-i="${i}">🎯 ${t('Start quiz')}</button>`;
  if (m.kind === 'none') body += `${m.topics?.length ? `<div class="srcs">${m.topics.slice(0, 6).map(x => `<button class="src" data-act="ai-ask" data-q="${esc(x)}">💡 ${esc(x)}</button>`).join('')}</div>` : ''}${AI.stats().chunks ? `<button class="btn ghost sm" data-act="reindex" style="margin-top:8px">🔄 ${t('Re-index all files')}</button>` : ''}`;
  let srcs = m.sources || [];
  if (m.llm && m.refs) { const seen = new Map(); m.refs.forEach(r => { if (!seen.has(r.fileId)) seen.set(r.fileId, { ...r, pages: [] }); const o = seen.get(r.fileId); if (!o.pages.includes(r.page)) o.pages.push(r.page); }); srcs = [...seen.values()].slice(0, 5).map(r => ({ ...r, page: r.pages.slice(0, 3).join(',') })); }
  const src = srcs.map(s => `<button class="src" data-act="file-open" data-cid="${s.courseId}" data-n="${s.n}" data-id="${s.fileId}">${fileIcon(s.fname)} ${esc(s.fname.slice(0, 24))} · p.${s.page}</button>`).join('');
  const tools = (m.llm && m.text ? `<button class="src" data-act="copy-msg" data-i="${i}">${svg('copy', 13)} ${t('Copy')}</button>` : '') + (m.err && m.q ? `<button class="src" data-act="ai-retry" data-i="${i}">${svg('refresh', 13)} ${t('Try again')}</button><button class="src" data-act="open-settings" data-sec="ai">${t('AI settings')}</button>` : '');
  const hint = m.offline && m.kind !== 'short' ? `<div class="ohint">📴 ${t('Offline mode: these are passages from your files. Connect an AI to get real explanations.')} <button class="lnk" data-act="open-settings" data-sec="ai">${t('Connect AI')}</button></div>` : '';
  const via = '';
  return `<div class="bubble ai"><div class="salam">${AI.SALAM}</div>${body}${src ? `<div class="srcs">${src}</div>` : ''}${tools ? `<div class="srcs">${tools}</div>` : ''}${hint}${via}</div>`;
}
function pushChat(m) { S.chat.push(m); if (S.chat.length > 30) S.chat.shift(); save(); const log = $('#chatLog'); if (log) { log.insertAdjacentHTML('beforeend', chatHtml(m, S.chat.length - 1)); scrollChat(); } }
async function aiAsk(q, display) {
  q = (q || '').trim(); if (!q) return;
  const history = S.chat.filter(m => m.role === 'user' || (m.role === 'ai' && m.llm && m.text)).slice(-6).map(m => ({ role: m.role === 'ai' ? 'assistant' : 'user', text: m.text }));
  pushChat({ role: 'user', text: display || q });
  const llm = AI.llmReady(); let th = null;
  if (llm) { th = document.createElement('div'); th.className = 'bubble ai typing'; th.innerHTML = `<span class="dots"><i></i><i></i><i></i></span><small class="muted">${t('Reading your files…')}</small>`; $('#chatLog')?.appendChild(th); scrollChat(); }
  let r; try { r = await AI.answer(q, aiScope(), history); } catch (e) { console.warn(e); r = { kind: 'none' }; }
  th?.remove();
  if (r.kind === 'short') pushChat({ role: 'ai', kind: 'short', text: t('Type at least 2 letters or a keyword.') });
  else if (r.kind === 'none') pushChat({ role: 'ai', kind: 'none', topics: r.topics, err: r.err, q, text: AI.stats().chunks ? t('I could not find that in your files. Try different keywords.') : t('No readable text yet. Add PDF, DOCX, PPTX or text files to a class first (photos are stored but cannot be read offline).') });
  else pushChat({ role: 'ai', q, ...r });
}
let _lt;
function aiLive(v) {
  clearTimeout(_lt); const box = $('#aiLive'); if (!box) return;
  _lt = setTimeout(() => {
    const q = v.trim(); if (q.length < 2) { box.innerHTML = ''; return; }
    const sc = aiScope();
    const meta = AI.metaSearch(q, sc).slice(0, 2); const hits = AI.search(q, { ...sc, k: 4 });
    const seen = new Set(); let h = '';
    meta.forEach(m => { h += `<button class="src" data-act="open-class" data-cid="${m.c.id}" data-n="${m.n}">📘 ${esc(m.c.name)} #${m.n}${m.k.topic ? ' · ' + esc(m.k.topic.slice(0, 18)) : ''}</button>`; });
    hits.forEach(({ chunk: c }) => { const k = c.fileId + c.page; if (seen.has(k) || seen.size >= 3) return; seen.add(k); h += `<button class="src" data-act="file-open" data-cid="${c.courseId}" data-n="${c.n}" data-id="${c.fileId}">${fileIcon(c.fname)} ${esc(c.fname.slice(0, 20))} · p.${c.page}</button>`; });
    box.innerHTML = h;
  }, 90);
}
