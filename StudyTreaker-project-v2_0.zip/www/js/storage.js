'use strict';
/* File storage: Android Storage Access Framework (Internal storage / SD card) or IndexedDB in a browser. */
const BASE = 'StudyTreaker';
const b64 = blob => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(String(r.result).split(',')[1] || '');
  r.onerror = () => rej(r.error);
  r.readAsDataURL(blob);
});
const MIMES = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif',
  txt: 'text/plain', md: 'text/markdown', csv: 'text/csv', json: 'application/json',
  doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', zip: 'application/zip' };
const guessMime = n => MIMES[(n.split('.').pop() || '').toLowerCase()] || 'application/octet-stream';

const FS = {
  native: !!(window.Native && window.Native.isNative),
  get SF() { return window.Native.SafStorage; },
  async init() {
    if (this.native) {
      try { const r = await this.SF.getRoot(); S.root = r.root || null; saveNow(); } catch (e) { console.warn(e); }
    }
  },
  async pickRoot() {
    if (this.native) { const r = await this.SF.pickRoot(); S.root = r.root; }
    else S.root = { uri: 'web://', name: 'Browser storage', volume: 'web', isSdCard: false, path: '' };
    save(); return S.root;
  },
  label() {
    const r = S.root;
    if (!r) return t('Not selected');
    if (r.volume === 'web') return t('Browser test storage');
    return (r.isSdCard ? t('SD card') : t('Internal storage')) + ' › ' + (r.path || r.name || '/');
  },
  pathPreview(parts) { return [BASE, ...parts.map(safeName)].join(' / '); },
  async write(dirParts, name, blob, { overwrite = false, onProg } = {}) {
    const path = [BASE, ...dirParts.map(safeName)].join('/');
    name = safeName(name);
    if (!this.native) {
      const uri = 'web://' + path + '/' + (overwrite ? name : uid() + '-' + name);
      await DB.put('blobs', blob, uri);
      return { uri, name, rel: path + '/' + name, size: blob.size, mime: blob.type || guessMime(name) };
    }
    const b = await this.SF.begin({ path, name, overwrite });
    try {
      const CH = 3 * 512 * 1024;
      for (let off = 0; off < blob.size; off += CH) {
        await this.SF.chunk({ handle: b.handle, data: await b64(blob.slice(off, off + CH)) });
        onProg && onProg(Math.min(1, (off + CH) / blob.size));
      }
    } finally { await this.SF.end({ handle: b.handle }); }
    return { uri: b.uri, name: b.name, rel: path + '/' + b.name, size: blob.size, mime: blob.type || guessMime(b.name) };
  },
  save(file, dirParts, onProg) { return this.write(dirParts, file.name, file, { onProg }); },
  async readBuf(uri) {
    if (!this.native) { const b = await DB.get('blobs', uri); if (!b) throw new Error('missing'); return b.arrayBuffer(); }
    const { data } = await this.SF.read({ uri });
    const bin = atob(data); const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  },
  async remove(uri) {
    try { if (this.native) await this.SF.remove({ uri }); else await DB.del('blobs', uri); } catch (e) { console.warn(e); }
  },
  async open(uri, mime, name) {
    if (this.native) return this.SF.open({ uri, mime: mime || guessMime(name || '') });
    const b = await DB.get('blobs', uri); if (!b) throw new Error('missing');
    window.open(URL.createObjectURL(b), '_blank');
  },
  async exists(uri) {
    if (!uri) return false;
    if (this.native) { try { return !!(await this.SF.exists({ uri })).exists; } catch (e) { return false; } }
    try { return !!(await DB.get('blobs', uri)); } catch (e) { return false; }
  },
  /* the path we expect a saved file to have (also for files saved by older versions) */
  expectedRel(ctx) { const { T, c, n, f } = ctx; return f.rel || [BASE, safeName(T.name), safeName(c.name), 'Class-' + pad(n), f.name].join('/'); },
  async relocate(rel) {
    const i = rel.lastIndexOf('/'); if (i < 0) return null;
    const dir = rel.slice(0, i).split('/'); if (dir[0] === BASE) dir.shift();
    try { return await this.find(dir, rel.slice(i + 1)); } catch (e) { return null; }
  },
  /* returns a working uri for a saved file (re-links it by folder path if the stored uri is dead), or null */
  async resolve(ctx) {
    const f = ctx.f;
    if (await this.exists(f.uri)) { f.missing = false; return f.uri; }
    const rel = this.expectedRel(ctx); const u = await this.relocate(rel);
    if (u) { f.uri = u; f.rel = rel; f.missing = false; return u; }
    f.missing = true; return null;
  },
  async find(dirParts, name) {
    const path = [BASE, ...dirParts].join('/');
    if (this.native) { const r = await this.SF.find({ path, name }); return r.uri || null; }
    const uri = 'web://' + path + '/' + name;
    return (await DB.get('blobs', uri)) ? uri : null;
  },
};

const Backup = {
  t: null, SLOTS: ['state-1.json', 'state-2.json'],
  schedule() { if (!S.root) return; clearTimeout(this.t); this.t = setTimeout(() => this.now().catch(e => console.warn('backup', e)), 6000); },
  /* two alternating files: if the app dies while writing one, the other is still a complete backup */
  async now() {
    if (!S.root) throw new Error('no_root');
    if (typeof Chats !== 'undefined') await Chats.flush();   // the open chat is written to its text file first
    const savedAt = Date.now(); const slot = this.SLOTS[(S.bkSlot || 0) % 2]; S.bkSlot = (S.bkSlot || 0) + 1;
    const state = { ...S, root: null, chat: [], llm: { ...S.llm, key: '' } };   // never write the API key into the backup
    const data = JSON.stringify({ app: 'study-treaker', v: 2, savedAt, state });
    const w = await FS.write(['_backup'], slot, new Blob([data], { type: 'application/json' }), { overwrite: true });
    let ok = false;   // read it back: "Backup saved" is only shown when the file really is there and complete
    try { const chk = JSON.parse(new TextDecoder().decode(await FS.readBuf(w.uri))); ok = chk && chk.savedAt === savedAt && !!chk.state; } catch (e) { }
    if (!ok) throw new Error(t('The backup could not be verified after saving. Please try again.'));
    S.lastBackup = savedAt; saveNow();
  },
  /* newest valid backup found in the chosen folder */
  async peek() {
    if (!S.root) throw new Error('no_root');
    let best = null, found = false;
    for (const n of [...this.SLOTS, 'state.json']) {
      let uri = null; try { uri = await FS.find(['_backup'], n); } catch (e) { }
      if (!uri) continue; found = true;
      try { const obj = JSON.parse(new TextDecoder().decode(await FS.readBuf(uri))); if (obj && obj.app === 'study-treaker' && obj.state && (!best || (obj.savedAt || 0) > (best.savedAt || 0))) best = obj; } catch (e) { }
    }
    if (!found) throw new Error('not_found'); if (!best) throw new Error('bad_file');
    return best;
  },
  summary(obj) {
    const st = obj.state || {}; let classes = 0, files = 0;
    for (const m of Object.values(st.classes || {})) for (const k of Object.values(m || {})) {
      files += (k.files || []).length;
      if (k.topic || k.note || k.done || (k.files || []).length || (k.links || []).length) classes++;
    }
    return { terms: (st.terms || []).length, classes, files, at: obj.savedAt || 0 };
  },
  async restore(obj) {
    try { localStorage.setItem(KEY + '_prev', JSON.stringify(S)); } catch (e) { }   // safety copy so a restore can be undone
    const key = S.llm.key, seq = S.aiSeq || 0;
    S = mergeState({ ...obj.state, root: S.root, llm: { ...(obj.state.llm || {}), key } });
    S.aiSeq = Math.max(S.aiSeq || 0, seq);   // never reuse the number of a chat file that already exists
    S.lastBackup = obj.savedAt || 0; saveNow();
  },
  hasUndo() { try { return !!localStorage.getItem(KEY + '_prev'); } catch (e) { return false; } },
  undo() { const raw = localStorage.getItem(KEY + '_prev'); if (!raw) throw new Error('none'); const root = S.root; S = mergeState({ ...JSON.parse(raw), root }); localStorage.removeItem(KEY + '_prev'); saveNow(); },
  /* check every saved file; re-link the ones whose address changed (new phone, other folder, renamed term…) */
  async verify(onProg) {
    const jobs = []; eachFile(x => jobs.push(x)); let ok = 0, relinked = 0, missing = 0, i = 0;
    for (const j of jobs) {
      onProg && onProg(++i, jobs.length); const before = j.f.uri;
      const u = await FS.resolve(j); if (!u) missing++; else { ok++; if (u !== before) relinked++; }
    }
    save(); return { total: jobs.length, ok, relinked, missing };
  },
};
