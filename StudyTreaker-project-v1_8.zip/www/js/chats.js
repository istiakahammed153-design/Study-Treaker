'use strict';
/* Study Treaker (c) Istiak Ahammed. All rights reserved. */
/* AI chat tabs. Each tab is one plain-text file: StudyTreaker/AI-Chats/Chat-<n>.txt  (readable in any app, and re-opened by this app). */
const Chats = {
  DIR: 'AI-Chats', mem: {}, _t: 0, dirty: false,
  cur() { return S.aiTabs.find(x => x.id === S.aiTab) || null; },
  openTabs() { return S.aiTabs.filter(x => x.open); },
  title(tb) { return tb.title || t('New chat'); },
  newTab() {
    S.aiSeq = (S.aiSeq || 0) + 1;
    const tb = { id: uid(), seq: S.aiSeq, title: '', ts: Date.now(), open: true, n: 0 };
    S.aiTabs.push(tb); this.mem[tb.id] = []; return tb;
  },

  /* ---------- text format ---------- */
  fmt(tb, msgs) {
    const D = ts => { const d = new Date(ts || Date.now()); return `${dstr(d)} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
    const e1 = l => /^(=== |~~~meta )/.test(l) ? ' ' + l : l;
    let o = `Study Treaker - AI chat\nTitle: ${this.title(tb).replace(/\n/g, ' ')}\nUpdated: ${D(Date.now())}\n(c) Istiak Ahammed\n\n`;
    for (const m of msgs) {
      o += `=== ${m.role === 'user' ? 'YOU' : 'AI'} | ${D(m.ts)} | t=${m.ts || 0} ===\n`;
      const body = m.text || (m.bullets || []).map(b => '- ' + b).join('\n') || '';
      o += String(body).split('\n').map(e1).join('\n') + '\n';
      if (m.role !== 'user') { const meta = { ...m }; delete meta.text; delete meta.role; delete meta.ts; meta.hasText = !!m.text; o += '~~~meta ' + JSON.stringify(meta) + '\n'; }
      o += '\n';
    }
    return o;
  },
  parse(txt) {
    const out = []; let cur = null; const H = /^=== (YOU|AI) \| .*? \| t=(\d+) ===$/;
    const flush = () => {
      if (!cur) return; let meta = null, body = cur.l;
      const mi = body.findIndex(l => l.startsWith('~~~meta '));
      if (mi >= 0) { try { meta = JSON.parse(body[mi].slice(8)); } catch (e) { } body = body.slice(0, mi); }
      const text = body.map(l => /^ (=== |~~~meta )/.test(l) ? l.slice(1) : l).join('\n').replace(/\n+$/, '');
      let m;
      if (cur.role === 'user') m = { role: 'user', text };
      else { m = { role: 'ai', ...(meta || {}) }; if (!meta || m.hasText) m.text = text; delete m.hasText; }
      m.ts = cur.ts; out.push(m); cur = null;
    };
    for (const l of String(txt || '').split('\n')) { const h = H.exec(l); if (h) { flush(); cur = { role: h[1] === 'YOU' ? 'user' : 'ai', ts: +h[2], l: [] }; } else if (cur) cur.l.push(l); }
    flush(); return out;
  },

  /* ---------- saving / loading ---------- */
  async persist(tb) {
    const msgs = this.mem[tb.id] || []; const txt = this.fmt(tb, msgs);
    try {
      const r = await FS.write([this.DIR], `Chat-${pad(tb.seq || 0)}.txt`, new Blob([txt], { type: 'text/plain' }), { overwrite: true });
      tb.uri = r.uri; tb.rel = r.rel; delete tb.text;
    } catch (e) { tb.text = txt; console.warn('chat file', e); }   // no storage folder yet: keep the text inside the app until there is one
    tb.n = msgs.length; save();
  },
  touch() {
    const tb = this.cur(); if (!tb) return;
    tb.ts = Date.now(); tb.n = S.chat.length; this.mem[tb.id] = S.chat;
    if (!tb.title) { const u = S.chat.find(x => x.role === 'user'); if (u) tb.title = String(u.text).replace(/\s+/g, ' ').slice(0, 26); }
    this.dirty = true; clearTimeout(this._t); this._t = setTimeout(() => this.flush(), 700); save();
  },
  async flush() { clearTimeout(this._t); if (!this.dirty) return; this.dirty = false; const tb = this.cur(); if (tb) await this.persist(tb); },
  flushSync() { if (!this.dirty) return; const tb = this.cur(); if (tb) tb.text = this.fmt(tb, S.chat); },   // app is closing: keep unsaved text in the app state
  async load(tb) {
    if (this.mem[tb.id]) return this.mem[tb.id];
    let txt = tb.text || '';
    if (!txt && tb.uri) { try { txt = new TextDecoder().decode(await FS.readBuf(tb.uri)); } catch (e) { console.warn('chat read', e); } }
    return (this.mem[tb.id] = this.parse(txt));
  },
  init() {
    if (!Array.isArray(S.aiTabs)) S.aiTabs = [];
    S.aiSeq = Math.max(S.aiSeq || 0, ...S.aiTabs.map(x => x.seq || 0));
    if (!S.aiTabs.length) {
      const tb = this.newTab(); S.aiTab = tb.id;
      if (S.chat && S.chat.length) {   // the single chat of older versions becomes the first tab
        this.mem[tb.id] = S.chat.map(m => ({ ts: Date.now(), ...m })); tb.n = S.chat.length;
        const u = S.chat.find(m => m.role === 'user'); tb.title = u ? String(u.text).slice(0, 26) : ''; this.dirty = true;
      }
    }
    let tb = this.cur(); if (!tb || !tb.open) { tb = this.openTabs()[0] || this.newTab(); S.aiTab = tb.id; tb.open = true; }
    S.chat = this.mem[tb.id] || [];
    this.load(tb).then(m => { if (S.aiTab === tb.id) { if (!S.chat.length) S.chat = m; this.mem[tb.id] = S.chat; if (UI.tab === 'ai') renderView(); } if (tb.text || this.dirty) this.dirty ? this.flush() : this.persist(tb); });
    S.aiTabs.filter(x => x.text && x !== tb).forEach(x => this.load(x).then(() => this.persist(x)));
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.flush(); });
  },

  /* ---------- tab actions ---------- */
  async select(id) {
    const tb = S.aiTabs.find(x => x.id === id); if (!tb) return;
    if (id === S.aiTab && tb.open) { renderView(); return; }
    await this.flush(); tb.open = true; S.aiTab = id; S.chat = await this.load(tb); save(); renderView();
  },
  async add() {
    if (this.openTabs().length >= 8) return toast(t('Up to 8 open chats. Close one first.'));
    await this.flush(); const tb = this.newTab(); S.aiTab = tb.id; S.chat = this.mem[tb.id]; save(); renderView();
    setTimeout(() => { const i = $('#aiq'); if (i) i.focus(); }, 60);
  },
  async _fallback() {
    const open = this.openTabs();
    if (!open.length) { const nt = this.newTab(); S.aiTab = nt.id; S.chat = this.mem[nt.id]; }
    else { const nt = open[open.length - 1]; S.aiTab = nt.id; S.chat = await this.load(nt); }
  },
  async close(id) {
    const tb = S.aiTabs.find(x => x.id === id); if (!tb) return; await this.flush();
    if (!(this.mem[id] || []).length && !tb.uri && !tb.text) { S.aiTabs = S.aiTabs.filter(x => x !== tb); delete this.mem[id]; } else tb.open = false;
    if (S.aiTab === id) await this._fallback();
    save(); renderView();
  },
  async remove(id) {
    const tb = S.aiTabs.find(x => x.id === id); if (!tb) return; await this.flush();
    if (tb.uri) await FS.remove(tb.uri);
    S.aiTabs = S.aiTabs.filter(x => x !== tb); delete this.mem[id];
    if (S.aiTab === id) await this._fallback();
    save(); renderView();
  },
};
