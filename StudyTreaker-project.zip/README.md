# Study Treaker — APK বানানোর নিয়ম (GitHub দিয়ে)

1. GitHub-এ একটা নতুন repository খোলো (Public/Private দুটোই চলবে)।
2. এই zip-এর **ভেতরের সব ফাইল** (`.github` ফোল্ডারসহ) repository-র রুটে আপলোড করো।
   - ওয়েবে আপলোডে `.github` লুকানো ফোল্ডার ড্র্যাগ না হলে: Add file → Create new file → নাম দাও
     `.github/workflows/build-apk.yml` এবং ফাইলের লেখা পেস্ট করো।
3. Branch `main` বা `master` হতে হবে। Push হলেই বিল্ড শুরু হয়। (Actions ট্যাবে → "Build APK" → Run workflow দিয়েও চালানো যায়)
4. ৫–১০ মিনিট পর Actions → শেষ রান → নিচে **Artifacts → StudyTreaker-APK** ডাউনলোড করো।
5. zip খুলে `app-debug.apk` ফোনে ইনস্টল করো (Unknown sources অনুমতি লাগবে)।

## অ্যাপ ব্যবহার
- প্রথমবার: নাম, ভাষা, লেভেল/টার্ম দাও, "Choose storage folder" চাপো।
  Android 11+ এ Download/রুট ফোল্ডার নেওয়া যায় না — Internal storage বা SD card-এ একটা নতুন ফোল্ডার (যেমন `Study`) বানিয়ে সেটা সিলেক্ট করো।
  অ্যাপ তার ভেতরে `StudyTreaker/<Term>/<Course>/Class-01/` ফোল্ডার বানিয়ে ফাইল রাখবে।
- Classes → কোর্স → ক্লাস চাপো → টপিক/নোট লেখো, Add files (PDF/ছবি/DOCX/PPTX/যেকোনো ফাইল), Photo, Link।
- Search: টপিক, নোট, ফাইলের নাম এবং ফাইলের ভেতরের লেখা (PDF/DOCX/PPTX/TXT) খোঁজে।
- AI Guide: অফলাইনে নোট থেকে উত্তর, সারাংশ ও কুইজ বানায় (উত্তরের সোর্স ফাইল ও পৃষ্ঠা দেখায়)।
  চাইলে Settings → Local AI → নিজের Ollama/OpenAI-compatible সার্ভার যুক্ত করা যায়।
- Tools: Focus timer, To-Do, Exam countdown, সাপ্তাহিক পরিসংখ্যান। Settings: ব্যাকআপ, PIN লক, ডার্ক মোড, বাংলা/ইংরেজি।

## সীমাবদ্ধতা
- স্ক্যান করা PDF ও ছবির লেখা (OCR) পড়া যায় না — সেভ হয়, কিন্তু সার্চ/এআই-তে আসে না।
- পুরনো legacy-ফন্টের বাংলা PDF থেকে লেখা ভাঙা আসতে পারে।
- এটি debug APK (Play Store-এর জন্য নয়)।
