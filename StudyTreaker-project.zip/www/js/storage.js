'use strict';
/* File storage: Android Storage Access Framework (Internal storage / SD card) or IndexedDB in a browser. */
const BASE = 'StudyTreaker';
const b64 = blob => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(String(r.result).split(',')[1] || '');
  r.onerror = () => rej(r.error);
  r.readAsDataURL(blob);
});
const MIMES = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif',
  txt: 'text/plain', md: 'text/markdown', csv: 'text/csv', json: 'application/json',
  doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', zip: 'application/zip' };
const guessMime = n => MIMES[(n.split('.').pop() || '').toLowerCase()] || 'application/octet-stream';

const FS = {
  native: !!(window.Native && window.Native.isNative),
  get SF() { return window.Native.SafStorage; },
  async init() {
    if (this.native) {
      try { const r = await this.SF.getRoot(); S.root = r.root || null; saveNow(); } catch (e) { console.warn(e); }
    }
  },
  async pickRoot() {
    if (this.native) { const r = await this.SF.pickRoot(); S.root = r.root; }
    else S.root = { uri: 'web://', name: 'Browser storage', volume: 'web', isSdCard: false, path: '' };
    save(); return S.root;
  },
  label() {
    const r = S.root;
    if (!r) return t('Not selected');
    if (r.volume === 'web') return t('Browser test storage');
    return (r.isSdCard ? t('SD card') : t('Internal storage')) + ' › ' + (r.path || r.name || '/');
  },
  pathPreview(parts) { return [BASE, ...parts.map(safeName)].join(' / '); },
  async write(dirParts, name, blob, { overwrite = false, onProg } = {}) {
    const path = [BASE, ...dirParts.map(safeName)].join('/');
    name = safeName(name);
    if (!this.native) {
      const uri = 'web://' + path + '/' + (overwrite ? name : uid() + '-' + name);
      await DB.put('blobs', blob, uri);
      return { uri, name, size: blob.size, mime: blob.type || guessMime(name) };
    }
    const b = await this.SF.begin({ path, name, overwrite });
    try {
      const CH = 3 * 512 * 1024;
      for (let off = 0; off < blob.size; off += CH) {
        await this.SF.chunk({ handle: b.handle, data: await b64(blob.slice(off, off + CH)) });
        onProg && onProg(Math.min(1, (off + CH) / blob.size));
      }
    } finally { await this.SF.end({ handle: b.handle }); }
    return { uri: b.uri, name: b.name, size: blob.size, mime: blob.type || guessMime(b.name) };
  },
  save(file, dirParts, onProg) { return this.write(dirParts, file.name, file, { onProg }); },
  async readBuf(uri) {
    if (!this.native) { const b = await DB.get('blobs', uri); if (!b) throw new Error('missing'); return b.arrayBuffer(); }
    const { data } = await this.SF.read({ uri });
    const bin = atob(data); const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  },
  async remove(uri) {
    try { if (this.native) await this.SF.remove({ uri }); else await DB.del('blobs', uri); } catch (e) { console.warn(e); }
  },
  async open(uri, mime, name) {
    if (this.native) return this.SF.open({ uri, mime: mime || guessMime(name || '') });
    const b = await DB.get('blobs', uri); if (!b) throw new Error('missing');
    window.open(URL.createObjectURL(b), '_blank');
  },
  async find(dirParts, name) {
    const path = [BASE, ...dirParts].join('/');
    if (this.native) { const r = await this.SF.find({ path, name }); return r.uri || null; }
    const uri = 'web://' + path + '/' + name;
    return (await DB.get('blobs', uri)) ? uri : null;
  },
};

const Backup = {
  t: null,
  schedule() { if (!S.root) return; clearTimeout(this.t); this.t = setTimeout(() => this.now().catch(e => console.warn('backup', e)), 6000); },
  async now() {
    if (!S.root) throw new Error('no_root');
    const data = JSON.stringify({ app: 'study-treaker', savedAt: Date.now(), state: { ...S, root: null } });
    await FS.write(['_backup'], 'state.json', new Blob([data], { type: 'application/json' }), { overwrite: true });
    S.lastBackup = Date.now(); saveNow();
  },
  async restore() {
    const uri = await FS.find(['_backup'], 'state.json');
    if (!uri) throw new Error('not_found');
    const obj = JSON.parse(new TextDecoder().decode(await FS.readBuf(uri)));
    if (obj.app !== 'study-treaker') throw new Error('bad_file');
    S = mergeState({ ...obj.state, root: S.root });
    saveNow();
  },
};
