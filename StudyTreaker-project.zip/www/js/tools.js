'use strict';
/* Timer, To-Do, Exams, Stats */
function beep() {
  try { const a = new (window.AudioContext || window.webkitAudioContext)(); [0, 0.35, 0.7].forEach(d => { const o = a.createOscillator(), g = a.createGain(); o.connect(g); g.connect(a.destination); o.frequency.value = 880; g.gain.value = 0.2; o.start(a.currentTime + d); o.stop(a.currentTime + d + 0.2); }); } catch (e) { }
  try { navigator.vibrate && navigator.vibrate([300, 150, 300]); } catch (e) { }
}
const Timer = {
  full() { const T = S.timer; return (T.mode === 'focus' ? T.dur : T.brk) * 60000; },
  left() { const T = S.timer; return T.running ? Math.max(0, T.endsAt - Date.now()) : (T.remaining ?? this.full()); },
  start() { const T = S.timer; T.endsAt = Date.now() + this.left(); T.running = true; save(); },
  pause() { const T = S.timer; T.remaining = this.left(); T.running = false; save(); },
  log(min, course) { if (min >= 1) { S.sessions.push({ ts: Date.now(), min: Math.round(min), course: course || '' }); save(); } },
  reset() {
    const T = S.timer; const el = (this.full() - this.left()) / 60000;
    if (T.mode === 'focus' && el >= 1) { this.log(el, T.course); toast(t('Logged {n} min', { n: Math.round(el) })); }
    T.running = false; T.remaining = null; save();
  },
  finish() {
    const T = S.timer; T.running = false;
    if (T.mode === 'focus') { this.log(T.dur, T.course); toast('🎉 ' + t('Focus session complete!'), 5000); T.mode = 'break'; }
    else { toast(t('Break over – back to work!'), 5000); T.mode = 'focus'; }
    T.remaining = null; save(); beep();
  },
};
const mmss = ms => { const s = Math.ceil(ms / 1000); return pad(Math.floor(s / 60)) + ':' + pad(s % 60); };
function tickTimer() {
  const T = S.timer; const l = Timer.left();
  if (T.running && l <= 0) { Timer.finish(); renderAll(); return; }
  const d = $('#tmDisp'); if (d) d.textContent = mmss(l);
  const h = $('#hTimer'); if (h) { h.style.display = T.running ? '' : 'none'; h.textContent = '⏱ ' + mmss(l); }
}
setInterval(tickTimer, 500);

const Tools = {
  timer() {
    const T = S.timer; const cs = courses(); const tm = minutesOn(today());
    return `<div class="card tcard"><h3>⏱️ ${t('Focus Timer')}</h3>
      <div class="modes"><button class="${T.mode === 'focus' ? 'on' : ''}" data-act="tm-mode" data-m="focus">${t('Focus')}</button><button class="${T.mode === 'break' ? 'on' : ''}" data-act="tm-mode" data-m="break">${t('Break')}</button></div>
      <div class="big" id="tmDisp">${mmss(Timer.left())}</div>
      <div class="row center">${T.running ? `<button class="btn ghost" data-act="tm-pause">${svg('pause', 18)} ${t('Pause')}</button>` : `<button class="btn" data-act="tm-start">${svg('play', 18)} ${t('Start')}</button>`}<button class="btn danger" data-act="tm-reset">${svg('reset', 18)} ${t('Reset')}</button></div>
      <div class="row wrap center">${[15, 25, 45, 60].map(m => `<button class="pill ${T.dur === m ? 'on' : ''}" data-act="tm-dur" data-m="${m}">${m}</button>`).join('')}
        <input id="tmCustom" class="num-in" type="number" min="1" max="240" value="${T.dur}" data-change="tm-custom"><span class="muted">${t('min')}</span></div>
      <label class="fl">${t('Studying')}<select data-change="tm-course"><option value="">${t('General')}</option>${cs.map(c => `<option value="${c.id}" ${T.course === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
      <p class="muted center">${t('Today Studied')}: <b>${fmtMin(tm)}</b> · <a href="#" data-act="tm-log">${t('Add time manually')}</a></p></div>`;
  },
  todo() {
    const list = [...S.todos].sort((a, b) => a.done - b.done || (a.due || '9').localeCompare(b.due || '9') || b.prio - a.prio);
    const P = ['🟢', '🟡', '🔴'];
    return `<div class="card tcard"><h3>📋 ${t('To-Do List')}</h3>
      <textarea id="tdText" rows="2" placeholder="${t('Write a new task…')}"></textarea>
      <div class="row"><input id="tdDue" type="date"><select id="tdPrio"><option value="0">${t('Low')}</option><option value="1" selected>${t('Medium')}</option><option value="2">${t('High')}</option></select><button class="btn" data-act="td-add">${t('Add')}</button></div></div>
      ${list.map(x => { const o = x.due && !x.done && daysUntil(x.due) < 0; return `<div class="card task ${x.done ? 'done' : ''}"><button class="cb ${x.done ? 'on' : ''}" data-act="td-toggle" data-id="${x.id}">${x.done ? svg('check', 16) : ''}</button><div class="tb"><span>${P[x.prio]} ${esc(x.text)}</span>${x.due ? `<small class="${o ? 'late' : ''}">📅 ${esc(x.due)}${o ? ' · ' + t('overdue') : ''}</small>` : ''}</div><button class="ibtn" data-act="td-del" data-id="${x.id}">${svg('x', 18)}</button></div>`; }).join('') || empty('✅', 'No tasks yet.')}
      ${S.todos.some(x => x.done) ? `<button class="btn ghost sm" data-act="td-clear">${t('Clear completed')}</button>` : ''}`;
  },
  exams() {
    const list = [...S.exams].sort((a, b) => a.date.localeCompare(b.date));
    return `<button class="btn full" data-act="ex-add">${svg('plus', 18)} ${t('Add exam / deadline')}</button>` + (list.map(e => {
      const d = daysUntil(e.date); const cls = d < 0 ? 'past' : d <= 3 ? 'hot' : d <= 7 ? 'warm' : '';
      const c = findCourse(e.course)?.course;
      return `<div class="card exam ${cls}"><div class="dd"><b>${d < 0 ? '✓' : d}</b><small>${d < 0 ? t('past') : t('days')}</small></div><div class="tb"><b>${esc(e.title)}</b><small>📅 ${esc(e.date)}${c ? ' · ' + esc(c.name) : ''}</small></div><button class="ibtn" data-act="ex-del" data-id="${e.id}">${svg('trash', 18)}</button></div>`;
    }).join('') || empty('📅', 'No exams or deadlines yet.'));
  },
  stats() {
    const days = []; for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push([dstr(d), d.toLocaleDateString(S.profile.lang === 'bn' ? 'bn-BD' : 'en', { weekday: 'short' })]); }
    const vals = days.map(d => minutesOn(d[0])); const mx = Math.max(S.profile.goal || 60, ...vals, 1);
    const bars = days.map((d, i) => { const h = Math.round(vals[i] / mx * 100); return `<div class="col"><small>${vals[i] ? fmtMin(vals[i]) : ''}</small><div class="colbar"><i style="height:${h}%"></i></div><small>${d[1]}</small></div>`; }).join('');
    const week = vals.reduce((a, b) => a + b, 0), all = S.sessions.reduce((a, s) => a + s.min, 0);
    const by = {}; S.sessions.forEach(s => by[s.course || ''] = (by[s.course || ''] || 0) + s.min);
    const rows = Object.entries(by).sort((a, b) => b[1] - a[1]).map(([cid, m]) => `<div class="prow"><span>${esc(findCourse(cid)?.course.name || t('General'))}</span><b>${fmtMin(m)}</b></div>`).join('');
    const prog = courses().map(c => { const p = c.total ? Math.round(doneCount(c) * 100 / c.total) : 0; return `<div class="prow"><span>${esc(c.name)}</span><b>${p}%</b></div><div class="bar sm"><i style="width:${p}%"></i></div>`; }).join('');
    return `<div class="card tcard"><h3>📊 ${t('This week')}</h3><div class="chart">${bars}</div>
      <div class="kpis"><div><b>${fmtMin(week)}</b><small>${t('This week')}</small></div><div><b>${fmtMin(all)}</b><small>${t('All time')}</small></div><div><b>🔥 ${streak()}</b><small>${t('Day streak')}</small></div></div></div>
      <div class="card tcard"><h3>${t('Time by course')}</h3>${rows || `<p class="muted">${t('No study sessions yet.')}</p>`}</div>
      <div class="card tcard"><h3>${t('Course progress')}</h3>${prog || `<p class="muted">—</p>`}</div>`;
  },
};
