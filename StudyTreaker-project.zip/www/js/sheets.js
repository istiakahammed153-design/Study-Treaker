'use strict';
/* Class sheet, Settings panel, Quiz, Onboarding, Lock */
const sha = async s => { try { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('st:' + s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); } catch (e) { return 'p:' + s; } };

/* ---------- class page ---------- */
function classSheetHtml(cid, n) {
  const f = findCourse(cid); const k = getCls(cid, n) || { n, done: false, star: false, date: '', note: '', topic: '', files: [], links: [] };
  const files = k.files.map(x => `<div class="res-i"><div class="rn" data-act="file-open" data-cid="${cid}" data-n="${n}" data-id="${x.id}"><span class="fi">${fileIcon(x.name)}</span><div class="rt"><b>${esc(x.name)}</b><small>${fmtSize(x.size || 0)}${x.chunks ? ' · 🔎 ' + t('searchable') : ''}</small></div></div><button class="ibtn" data-act="file-del" data-id="${x.id}" aria-label="delete">${svg('trash', 18)}</button></div>`).join('');
  const links = k.links.map(x => `<div class="res-i"><div class="rn" data-act="link-open" data-id="${x.id}"><span class="fi">🔗</span><div class="rt"><b>${esc(x.title || x.url)}</b><small>${esc(x.url)}</small></div></div><button class="ibtn" data-act="link-del" data-id="${x.id}" aria-label="delete">${svg('trash', 18)}</button></div>`).join('');
  const none = !files && !links;
  return `<div class="phead"><button class="ibtn" data-act="close-top" aria-label="back">${svg('back', 22)}</button><div class="pt"><small>${esc(f?.term.name || '')} › ${esc(f?.course.name || '')}</small><b>${t('Class')} #${n}</b></div>
      <button class="ibtn ${k.star ? 'act-star' : ''}" data-act="cs-star" aria-label="star">${svg('star', 22)}</button></div>
    <input class="ttl" id="csTopic" value="${esc(k.topic)}" placeholder="${t('Add topic title')}" data-input="cs-field" data-f="topic" enterkeyhint="done">
    <div class="meta"><label class="datechip">📅 <input type="date" value="${esc(k.date)}" data-change="cs-field" data-f="date"></label>
      <button class="stat ${k.done ? 'ok' : ''}" data-act="cs-done">${svg('check', 16)} ${k.done ? t('Completed') : t('Mark done')}</button></div>
    <textarea class="note-in" rows="2" placeholder="${t('Write notes: teacher, key points…')}" data-input="cs-field" data-f="note">${esc(k.note)}</textarea>
    <div class="sh2"><h4>${t('Files')} <span class="cnt">${k.files.length + k.links.length}</span></h4></div>
    ${files}${links}
    ${none ? `<div class="dropz" data-act="cs-addfiles">${svg('file', 26)}<b>${t('Add files')}</b><small>${t('PDF, photos, slides, documents')}</small></div>` : ''}
    <div class="addbar"><button class="btn" data-act="cs-addfiles">${svg('plus', 18)} ${t('Add files')}</button><button class="btn ghost" data-act="cs-camera">${svg('cam', 18)} ${t('Photo')}</button><button class="btn ghost" data-act="cs-addlink">${svg('link', 18)} ${t('Link')}</button></div>
    <p class="muted sm pathp">📁 ${esc(FS.pathPreview([f?.term.name || '', f?.course.name || '', 'Class-' + pad(n)]))}</p>
    <button class="btn ghost danger-t" data-act="cs-clear">${svg('trash', 16)} ${t('Clear this class')}</button>`;
}
function openClassSheet(cid, n) {
  UI.cur = { cid, n: +n };
  if (UI.sheet && UI.stack.includes(UI.sheet)) UI.sheet.close();
  UI.sheet = openSheet(classSheetHtml(cid, +n), { full: true, page: true, onClose: () => { UI.sheet = null; UI.cur = null; renderView(); } });
}
const refreshClassSheet = () => {
  if (!(UI.sheet && UI.cur)) return;
  const k = ensureCls(UI.cur.cid, UI.cur.n); const tp = $('#csTopic', UI.sheet.el)?.value, nt = $('.note-in', UI.sheet.el)?.value;
  UI.sheet.set(classSheetHtml(UI.cur.cid, UI.cur.n));
};

async function importFiles(files) {
  const { cid, n } = UI.cur || {}; if (!cid || !files.length) return;
  if (!(await ensureRoot())) return;
  const f = findCourse(cid); const dir = [f.term.name, f.course.name, 'Class-' + pad(n)]; let ok = 0;
  for (let i = 0; i < files.length; i++) {
    const file = files[i]; const tag = `${i + 1}/${files.length} · ${file.name.slice(0, 28)}`;
    setProgress(t('Saving') + ' ' + tag, 0);
    let meta; try { meta = await FS.save(file, dir, p => setProgress(t('Saving') + ' ' + tag, p * 0.8)); } catch (e) { console.warn(e); toast(t('Could not save') + ': ' + file.name); continue; }
    const fm = { id: uid(), name: meta.name, uri: meta.uri, mime: meta.mime, size: meta.size, added: Date.now(), chunks: 0 };
    ensureCls(cid, n).files.push(fm); save(); ok++; refreshClassSheet();
    if (Extract.canIndex(file.name)) {
      setProgress(t('Reading text…') + ' ' + tag, 0.85);
      try { const pages = await Extract.run(file.name, await file.arrayBuffer(), p => setProgress(t('Reading text…') + ' ' + tag, 0.8 + p * 0.2));
        fm.chunks = await AI.addFile({ fileId: fm.id, fname: fm.name, termId: f.term.id, courseId: cid, n }, pages); save(); } catch (e) { console.warn('extract', e); }
    }
    refreshClassSheet();
  }
  setProgress(null); if (ok) toast(t('{n} file(s) added', { n: ok }));
}

/* ---------- quiz ---------- */
function startQuiz(questions) {
  const st = { i: 0, score: 0, wrong: [], questions, shown: false };
  const sh = openSheet('', { full: true });
  const draw = () => {
    const q = st.questions[st.i];
    if (!q) { sh.set(`<div class="shead"><h3>🎯 ${t('Quiz result')}</h3><button class="ibtn" data-act="close-top">${svg('x')}</button></div><div class="big center">${st.score}/${st.questions.length}</div><p class="center muted">${st.score === st.questions.length ? t('Perfect! 🎉') : t('Review the ones you missed.')}</p><div class="row center">${st.wrong.length ? `<button class="btn" id="qRetry">${t('Retry missed')}</button>` : ''}<button class="btn ghost" data-act="close-top">${t('Done')}</button></div>`);
      const b = $('#qRetry', sh.el); if (b) b.onclick = () => { sh.close(); startQuiz(st.wrong); }; return; }
    const head = `<div class="shead"><h3>${t('Question')} ${st.i + 1}/${st.questions.length}</h3><button class="ibtn" data-act="close-top">${svg('x')}</button></div><div class="bar sm"><i style="width:${st.i * 100 / st.questions.length}%"></i></div>`;
    const src = `<small class="muted">${fileIcon(q.src.fname)} ${esc(q.src.fname)} · p.${q.src.page}</small>`;
    if (q.type === 'mcq') {
      sh.set(`${head}<p class="qtext">${esc(q.q)}</p><div class="opts">${q.options.map((o, i) => `<button class="opt" data-i="${i}">${esc(o)}</button>`).join('')}</div>${src}<div id="qfb"></div>`);
      $$('.opt', sh.el).forEach(b => b.onclick = () => {
        if (st.shown) return; st.shown = true; const i = +b.dataset.i; const ok = i === q.answer;
        $$('.opt', sh.el).forEach((x, j) => x.classList.add(j === q.answer ? 'ok' : j === i ? 'bad' : 'dim'));
        if (ok) st.score++; else st.wrong.push(q);
        $('#qfb', sh.el).innerHTML = `<button class="btn" id="qNext">${t('Next')}</button>`; $('#qNext', sh.el).onclick = () => { st.i++; st.shown = false; draw(); };
      });
    } else {
      sh.set(`${head}<p class="qtext">${esc(q.type === 'fill' ? q.q : q.q)}</p>${src}<div id="qfb"><button class="btn" id="qShow">${t('Show answer')}</button></div>`);
      $('#qShow', sh.el).onclick = () => {
        $('#qfb', sh.el).innerHTML = `<div class="ans">${esc(q.a)}</div><div class="row"><button class="btn ghost" id="qNo">😕 ${t('Missed')}</button><button class="btn" id="qYes">😎 ${t('Got it')}</button></div>`;
        $('#qYes', sh.el).onclick = () => { st.score++; st.i++; draw(); }; $('#qNo', sh.el).onclick = () => { st.wrong.push(q); st.i++; draw(); };
      };
    }
  };
  draw();
}

/* ---------- settings (grouped pages) ---------- */
const setRow = (ic, title, sub, page) => `<button class="srow" data-act="set-go" data-p="${page}"><span class="sic">${svg(ic, 20)}</span><span class="stx"><b>${t(title)}</b><small>${sub}</small></span>${svg('chev', 18)}</button>`;
const segHtml = (f, cur, opts) => `<div class="segc">${opts.map(o => `<button class="${cur === o[0] ? 'on' : ''}" data-act="pf-seg" data-f="${f}" data-v="${o[0]}">${o[1]}</button>`).join('')}</div>`;
function settingsHtml() {
  const p = S.profile, term = curTerm(), page = UI.setPage || 'main', ai = AI.stats();
  const head = (title, back) => `<div class="phead">${back ? `<button class="ibtn" data-act="set-back" aria-label="back">${svg('back', 22)}</button>` : ''}<div class="pt"><b>${t(title)}</b></div><button class="ibtn" data-act="close-top" aria-label="close">${svg('x', 22)}</button></div>`;
  if (page === 'main') return `${head('Settings', false)}
    <div class="pcard"><div class="av">${esc((p.name || '?').trim().charAt(0).toUpperCase())}</div><div><b>${esc(p.name || t('Your name'))}</b><small>${esc(term?.name || t('Create Level/Term'))}</small></div></div>
    <div class="sgroup">${setRow('user', 'Profile & preferences', `${p.lang === 'bn' ? 'বাংলা' : 'English'} · ${t(p.theme === 'auto' ? 'Auto' : p.theme === 'dark' ? 'Dark' : 'Light')} · ${fmtMin(p.goal)}`, 'profile')}
      ${setRow('cap', 'Level/Term & courses', `${esc(term?.name || '—')} · ${courses().length} ${t('courses')}`, 'terms')}</div>
    <div class="sgroup">${setRow('db', 'Storage & backup', esc(FS.label()), 'storage')}
      ${setRow('zap', 'AI engine', `${ai.files} ${t('files')} · ${ai.chunks} ${t('passages')}`, 'ai')}
      ${setRow('lock', 'Security', p.lock ? t('PIN enabled') : t('No PIN'), 'security')}</div>
    <p class="muted center sm">Study Treaker v1.1</p>`;
  if (page === 'profile') return `${head('Profile & preferences', true)}
    <div class="sgroup pad"><label class="fl">${t('Your name')}<input value="${esc(p.name)}" data-change="pf" data-f="name"></label>
      <div class="fl">${t('Language')}${segHtml('lang', p.lang, [['en', 'English'], ['bn', 'বাংলা']])}</div>
      <div class="fl">${t('Theme')}${segHtml('theme', p.theme, [['auto', t('Auto')], ['light', t('Light')], ['dark', t('Dark')]])}</div>
      <div class="fl">${t('Daily goal (minutes)')}<div class="stepper"><button data-act="goal-step" data-d="-15" aria-label="-">${svg('minus', 18)}</button><b>${fmtMin(p.goal)}</b><button data-act="goal-step" data-d="15" aria-label="+">${svg('plus', 18)}</button></div></div></div>`;
  if (page === 'terms') return `${head('Level/Term & courses', true)}
    <h4 class="sec2">${t('Level/Term')}</h4>
    <div class="sgroup">${S.terms.map(x => `<button class="srow ${x.id === term?.id ? 'sel' : ''}" data-act="term-pick" data-id="${x.id}"><span class="radio ${x.id === term?.id ? 'on' : ''}"></span><span class="stx"><b>${esc(x.name)}</b><small>${x.courses.length} ${t('courses')}</small></span>${x.id === term?.id ? `<span class="badge">${t('Active')}</span>` : ''}</button>`).join('') || `<p class="muted pad">—</p>`}
      <button class="srow add" data-act="term-new"><span class="sic">${svg('plus', 20)}</span><span class="stx"><b>${t('New Level/Term')}</b></span></button></div>
    ${term ? `<h4 class="sec2">${t('Courses')} · ${esc(term.name)}</h4>
    <div class="sgroup">${term.courses.map(c => `<button class="srow" data-act="course-edit" data-id="${c.id}"><span class="cdot" style="background:${COLORS[(c.color || 0) % 8][0]}"></span><span class="stx"><b>${esc(c.name)}</b><small>${c.total} ${t('classes')} · ${doneCount(c)} ${t('Done')}</small></span>${svg('chev', 18)}</button>`).join('')}
      <button class="srow add" data-act="course-new"><span class="sic">${svg('plus', 20)}</span><span class="stx"><b>${t('Add New Course')}</b></span></button></div>
    <button class="btn ghost danger-t full" data-act="term-delete">${svg('trash', 16)} ${t('Delete Term')}</button>` : ''}`;
  if (page === 'course') { const c = UI.ce; return `${head(c.id ? 'Edit course' : 'Add New Course', true)}
    <div class="sgroup pad"><label class="fl">${t('Course name')}<input value="${esc(c.name)}" placeholder="${t('Course name')}" data-input="ce" data-f="name"></label>
      <div class="fl">${t('Number of classes')}<div class="stepper"><button data-act="ce-step" data-d="-1" aria-label="-">${svg('minus', 18)}</button><b>${c.total}</b><button data-act="ce-step" data-d="1" aria-label="+">${svg('plus', 18)}</button></div></div>
      <div class="fl">${t('Color')}<div class="swatches">${COLORS.map((x, j) => `<button class="sw ${(c.color || 0) === j ? 'on' : ''}" style="background:linear-gradient(135deg,${x[0]},${x[1]})" data-act="ce-color" data-c="${j}" aria-label="color ${j + 1}"></button>`).join('')}</div></div></div>
    <button class="btn full" data-act="course-save">💾 ${t('Save')}</button>
    ${c.id ? `<button class="btn ghost danger-t full" data-act="course-del">${svg('trash', 16)} ${t('Remove course')}</button>` : ''}`; }
  if (page === 'storage') return `${head('Storage & backup', true)}
    <div class="sgroup pad"><div class="info">${esc(FS.label())}</div>
      <p class="muted sm">${t('Files are saved as')}: <code>StudyTreaker / ${t('Term')} / ${t('Course')} / Class-01</code></p>
      <button class="btn full" data-act="pick-root">${S.root ? t('Change folder') : t('Choose folder')}</button></div>
    <div class="sgroup pad"><div class="row wrap"><button class="btn ghost" data-act="backup-now">${t('Backup now')}</button><button class="btn ghost" data-act="backup-restore">${t('Restore backup')}</button></div>
      ${S.lastBackup ? `<p class="muted sm">${t('Last backup')}: ${new Date(S.lastBackup).toLocaleString()}</p>` : ''}</div>`;
  if (page === 'ai') return `${head('AI engine', true)}
    <div class="sgroup pad"><p><b>${svg('zap', 16)} ${t('Offline engine active')}</b></p><p class="muted sm">${ai.files} ${t('files')} · ${ai.chunks} ${t('passages')}</p>
      <p class="muted sm">${t('If the AI cannot find text that is in your PDF, re-index once.')}</p>
      <button class="btn full" data-act="reindex">🔄 ${t('Re-index all files')}</button></div>
    <div class="sgroup pad"><details><summary>${t('Advanced: connect your own LLM (optional)')}</summary>
      <p class="muted sm">${t('Works with Ollama or any OpenAI-compatible server on your Wi-Fi. Your notes are sent only to this server.')}</p>
      <label class="chk"><input type="checkbox" ${S.llm.enabled ? 'checked' : ''} data-change="llm" data-f="enabled"> ${t('Enable')}</label>
      <label class="fl">URL<input value="${esc(S.llm.url)}" data-change="llm" data-f="url"></label>
      <label class="fl">${t('Model')}<input value="${esc(S.llm.model)}" data-change="llm" data-f="model"></label>
      <label class="fl">API key (${t('optional')})<input type="password" value="${esc(S.llm.key)}" data-change="llm" data-f="key"></label>
      <button class="btn ghost" data-act="llm-test">${t('Test connection')}</button></details></div>`;
  return `${head('Security', true)}<div class="sgroup pad"><div class="row wrap"><button class="btn ghost" data-act="pin-set">${p.lock ? t('Change PIN') : t('Set PIN lock')}</button>${p.lock ? `<button class="btn ghost danger-t" data-act="pin-off">${t('Remove PIN')}</button>` : ''}</div></div>`;
}
function openSettings(sec) {
  UI.setPage = sec === 'term' || sec === 'courses' ? 'terms' : 'main';
  UI.set = openSheet(settingsHtml(), { full: true, onClose: () => { UI.set = null; UI.setPage = 'main'; renderAll(); } });
}
const refreshSettings = () => UI.set && UI.set.set(settingsHtml());

async function reindexAll() {
  if (!(await confirmBox(t('Re-read all saved files and rebuild the search index? This may take a while.'), 'Start', false))) return;
  await DB.clear('chunks'); AI.chunks = []; AI.build(); let done = 0, total = 0;
  const jobs = []; for (const T of S.terms) for (const c of T.courses) for (const [n, k] of Object.entries(S.classes[c.id] || {})) for (const f of k.files) if (Extract.canIndex(f.name)) { jobs.push({ T, c, n: +n, f }); total++; }
  for (const j of jobs) {
    setProgress(`${t('Indexing')} ${++done}/${total} · ${j.f.name.slice(0, 26)}`, done / total);
    try { const pages = await Extract.run(j.f.name, await FS.readBuf(j.f.uri)); j.f.chunks = await AI.addFile({ fileId: j.f.id, fname: j.f.name, termId: j.T.id, courseId: j.c.id, n: j.n }, pages); } catch (e) { console.warn('reindex', j.f.name, e); }
  }
  save(); setProgress(null); toast(t('Index rebuilt')); refreshSettings();
}

/* ---------- onboarding & lock ---------- */
function showOnboarding() {
  let lang = S.profile.lang;
  const sh = openSheet('', { full: true, onClose: () => { if (!S.profile.onboarded) showOnboarding(); } });
  const draw = () => sh.set(`<div class="onb"><div class="logo big">${svg('cap', 40)}</div><h2>Study Treaker</h2><p class="muted">${t('Your notes, classes and AI study guide — all offline.')}</p>
    <label class="fl">${t('Your name')}<input id="obName" value="${esc(S.profile.name)}"></label>
    <label class="fl">${t('Language')}<select id="obLang"><option value="en" ${lang === 'en' ? 'selected' : ''}>English</option><option value="bn" ${lang === 'bn' ? 'selected' : ''}>বাংলা</option></select></label>
    <label class="fl">${t('Level/Term')}<input id="obTerm" value="Level-1, Term-1"></label>
    <label class="chk"><input type="checkbox" id="obSample" checked> ${t('Add sample courses')}</label>
    <div class="info">📁 ${esc(FS.label())}</div>
    <button class="btn ghost full" id="obPick">${t('Choose storage folder (Internal / SD card)')}</button>
    <button class="btn full" id="obGo">${t('Get started')}</button></div>`);
  draw();
  sh.el.addEventListener('change', e => { if (e.target.id === 'obLang') { S.profile.lang = e.target.value; lang = e.target.value; S.profile.name = $('#obName', sh.el).value; draw(); } });
  sh.el.addEventListener('click', async e => {
    if (e.target.closest('#obPick')) { S.profile.name = $('#obName', sh.el).value; try { await FS.pickRoot(); } catch (x) { toast(t('No folder selected')); } const tm = $('#obTerm', sh.el).value; draw(); $('#obTerm', sh.el).value = tm; }
    if (e.target.closest('#obGo')) {
      S.profile.name = $('#obName', sh.el).value.trim(); const name = $('#obTerm', sh.el).value.trim() || 'Level-1, Term-1';
      const T = { id: uid(), name, courses: [] };
      if ($('#obSample', sh.el).checked) ['Mathematics-1', 'Physics-1', 'English-1'].forEach((n, i) => T.courses.push({ id: uid(), name: n, total: 20, color: i }));
      S.terms.push(T); S.activeTerm = T.id; S.profile.onboarded = true; save(); sh.onClose = null; sh.close(); renderAll();
    }
  });
}
async function showLock() {
  if (!S.profile.lock || $('#lock')) return;
  const d = document.createElement('div'); d.id = 'lock';
  d.innerHTML = `<div class="onb"><div class="logo big">${svg('lock', 36)}</div><h2>${t('Enter PIN')}</h2><input id="lockIn" type="password" inputmode="numeric" maxlength="8" autocomplete="off"><p id="lockErr" class="muted"></p><button class="btn full" id="lockGo">${t('Unlock')}</button></div>`;
  document.body.appendChild(d);
  const go = async () => { if (await sha($('#lockIn').value) === S.profile.lock) d.remove(); else { $('#lockErr').textContent = t('Wrong PIN'); $('#lockIn').value = ''; } };
  $('#lockGo').onclick = go; $('#lockIn').onkeydown = e => { if (e.key === 'Enter') go(); };
}
