'use strict';
/* Offline "local AI": BM25 retrieval over your files + extractive answers, summaries and question generation.
   Optional: forward retrieved passages to your own LLM server (Ollama / OpenAI-compatible). */
const STOP = new Set(('a an the of to in on at for and or but is are was were be been being am do does did done have has had it its this that these those with as by from into about over than then so such not no yes can could should would will shall may might must ' +
  'what which who whom whose when where why how i me my we our you your he she they them his her their there here also very just more most some any each other another ' +
  'explain define give tell make create generate show list write quiz question questions mcq summarize summary summarise overview please topic chapter lecture class ' +
  'কি কী কেন কিভাবে কীভাবে কোন কোনটি এই এটি এটা ওই এর তার তাদের আমার আমি আমরা তুমি ও এবং বা কিন্তু হলো হল হয় হয়ে হবে থেকে করে করা করো কর দাও দাও। সম্পর্কে বিষয়ে বলতে একটি একটা সারাংশ সংক্ষেপে প্রশ্ন প্রশ্নগুলো তৈরি কুইজ ব্যাখ্যা বর্ণনা লেখো লিখ').split(/\s+/));

function stem(w) {
  if (!/^[a-z]+$/.test(w)) return w;
  if (w.length > 4 && w.endsWith('ies')) return w.slice(0, -3) + 'y';
  if (w.length > 5 && w.endsWith('sses')) return w.slice(0, -2);
  if (w.length > 5 && w.endsWith('ing')) return w.slice(0, -3);
  if (w.length > 4 && w.endsWith('ed')) return w.slice(0, -2);
  if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us') && !w.endsWith('is')) return w.slice(0, -1);
  return w;
}
function tokenize(text, keepStop) {
  const m = String(text).toLowerCase().match(/[\p{L}\p{M}\p{N}‌‍]+/gu) || [];
  const out = [];
  for (const w of m) {
    if (!keepStop && (STOP.has(w) || (w.length < 2 && !/\d/.test(w)))) continue;
    out.push(stem(w));
  }
  return out;
}
function splitSentences(text) {
  return String(text).replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').split(/(?<=[.!?।])\s+|\n+/).map(s => s.trim()).filter(s => s.length >= 25 && s.length <= 400);
}
function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

const AI = {
  chunks: [], vocab: new Map(), N: 0, avgLen: 1, ready: false,
  async load() { this.chunks = await DB.all('chunks'); this.build(); },
  build() {
    this.vocab = new Map(); let total = 0;
    this.chunks.forEach((c, i) => {
      const toks = tokenize(c.text); c._len = toks.length || 1; total += c._len;
      const tf = new Map(); toks.forEach(w => tf.set(w, (tf.get(w) || 0) + 1));
      tf.forEach((n, w) => { let p = this.vocab.get(w); if (!p) this.vocab.set(w, p = []); p.push([i, n]); });
    });
    this.N = this.chunks.length; this.avgLen = total / Math.max(1, this.N); this.ready = true;
  },
  idf(w) { const p = this.vocab.get(w); const df = p ? p.length : 0; return Math.log(1 + (this.N - df + 0.5) / (df + 0.5)); },
  stats() { return { chunks: this.chunks.length, files: new Set(this.chunks.map(c => c.fileId)).size }; },
  makeChunks(meta, pages) {
    const out = []; let k = 0;
    for (const pg of pages) {
      const sents = String(pg.text).replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').split(/(?<=[.!?।])\s+|\n+/).map(s => s.trim()).filter(Boolean);
      let cur = '';
      const flush = () => { if (cur.trim().length > 30) out.push({ id: meta.fileId + ':' + (k++), ...meta, page: pg.page, text: cur.trim() }); cur = ''; };
      for (const s of sents) { if ((cur + ' ' + s).length > 900) flush(); cur += (cur ? ' ' : '') + s; }
      flush();
    }
    return out;
  },
  async addFile(meta, pages) {
    const cs = this.makeChunks(meta, pages);
    if (cs.length) { await DB.putMany('chunks', cs.map(({ _len, ...r }) => r)); this.chunks.push(...cs); this.build(); }
    return cs.length;
  },
  async removeFile(fileId) {
    await DB.delByIndex('chunks', 'fileId', fileId);
    this.chunks = this.chunks.filter(c => c.fileId !== fileId); this.build();
  },
  async removeCourse(courseId) {
    const ids = [...new Set(this.chunks.filter(c => c.courseId === courseId).map(c => c.fileId))];
    for (const id of ids) await DB.delByIndex('chunks', 'fileId', id);
    this.chunks = this.chunks.filter(c => c.courseId !== courseId); this.build();
  },
  /* BM25 with prefix expansion (helps Bangla suffixes: ম্যাট্রিক্স / ম্যাট্রিক্সের) */
  search(q, { courseId, termId, k = 8 } = {}) {
    const qt = [...new Set(tokenize(q))];
    if (!qt.length || !this.N) return [];
    const scores = new Map();
    for (const w of qt) {
      const terms = [[w, 1]];
      if (w.length >= 3) for (const v of this.vocab.keys()) {
        if (v === w) continue;
        if (v.length >= w.length && v.startsWith(w)) terms.push([v, 0.7]);
        else if (v.length >= 3 && w.length > v.length && w.startsWith(v)) terms.push([v, 0.5]);
      }
      for (const [v, wt] of terms) {
        const idf = this.idf(v);
        for (const [i, tf] of this.vocab.get(v) || []) {
          const c = this.chunks[i];
          if (courseId && c.courseId !== courseId) continue;
          if (termId && c.termId !== termId) continue;
          const s = wt * idf * (tf * 2.4) / (tf + 1.4 * (0.25 + 0.75 * c._len / this.avgLen));
          scores.set(i, (scores.get(i) || 0) + s);
        }
      }
    }
    return [...scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, k).map(([i, s]) => ({ chunk: this.chunks[i], score: s }));
  },
  snippet(text, q, len = 220) {
    const qt = tokenize(q); const low = text.toLowerCase(); let pos = -1;
    for (const w of qt) { const p = low.indexOf(w.slice(0, Math.max(3, w.length - 1))); if (p >= 0 && (pos < 0 || p < pos)) pos = p; }
    const st = Math.max(0, (pos < 0 ? 0 : pos) - 60);
    return (st > 0 ? '…' : '') + text.slice(st, st + len) + (st + len < text.length ? '…' : '');
  },
  intent(q) {
    if (/\b(quiz|mcq|questions?|test me|practice)\b|প্রশ্ন|কুইজ|পরীক্ষা নাও/i.test(q)) return 'quiz';
    if (/\b(summar(y|ize|ise)|overview|brief|key points)\b|সারাংশ|সংক্ষেপ/i.test(q)) return 'summary';
    return 'qa';
  },
  topSentences(chunks, q, n) {
    const qt = new Set(tokenize(q)); const all = [];
    chunks.forEach((c, ci) => splitSentences(c.text).forEach((s, si) => {
      const toks = tokenize(s); if (!toks.length) return;
      let sc = 0; toks.forEach(w => { if (qt.has(w)) sc += this.idf(w) * 2; });
      sc = sc / Math.sqrt(toks.length) + (1 - ci * 0.1) * 0.3 - si * 0.02;
      all.push({ s, sc, c, ci, si });
    }));
    const ranked = all.sort((a, b) => b.sc - a.sc); const best = ranked[0]?.sc || 0;
    return ranked.filter(o => o.sc >= best * 0.55).slice(0, n).sort((a, b) => a.ci - b.ci || a.si - b.si);
  },
  summarize(chunks, n = 6) {
    const freq = new Map(); const sents = [];
    chunks.forEach((c, ci) => splitSentences(c.text).forEach((s, si) => { const toks = tokenize(s); toks.forEach(w => freq.set(w, (freq.get(w) || 0) + 1)); sents.push({ s, toks, c, ci, si }); }));
    sents.forEach(o => { o.sc = o.toks.reduce((a, w) => a + (freq.get(w) || 0) * this.idf(w), 0) / Math.sqrt(o.toks.length || 1); });
    return sents.filter(o => o.toks.length > 3).sort((a, b) => b.sc - a.sc).slice(0, n).sort((a, b) => a.ci - b.ci || a.si - b.si);
  },
  src(c) { return { fileId: c.fileId, fname: c.fname, page: c.page, courseId: c.courseId, n: c.n }; },
  dedupeSources(list) { const m = new Map(); list.forEach(c => m.set(c.fileId + ':' + c.page, this.src(c))); return [...m.values()].slice(0, 5); },

  async answer(q, scope = {}) {
    const intent = this.intent(q);
    const hits = this.search(q, { ...scope, k: intent === 'quiz' ? 10 : 6 });
    if (!hits.length) return { kind: 'none' };
    const chunks = hits.map(h => h.chunk);
    if (intent === 'quiz') {
      const m = q.match(/\b(\d{1,2})\b/); const n = m ? Math.min(20, +m[1]) : 6;
      const qs = this.makeQuestions(chunks, n);
      return qs.length ? { kind: 'quiz', questions: qs, sources: this.dedupeSources(chunks) } : { kind: 'none' };
    }
    if (intent === 'summary') {
      const sm = this.summarize(chunks, 6);
      return { kind: 'text', bullets: sm.map(o => o.s), sources: this.dedupeSources(sm.map(o => o.c)) };
    }
    if (S.llm.enabled) {
      try { const text = await this.askLLM(q, chunks.slice(0, 5)); return { kind: 'text', text, sources: this.dedupeSources(chunks.slice(0, 5)), llm: true }; }
      catch (e) { console.warn('LLM failed', e); }
    }
    const top = this.topSentences(chunks.slice(0, 5), q, 4);
    return { kind: 'text', bullets: top.map(o => o.s), sources: this.dedupeSources(top.map(o => o.c)) };
  },
  sampleChunks(courseId, n = 8) {
    const pool = this.chunks.filter(c => !courseId || c.courseId === courseId);
    return shuffle(pool).slice(0, n);
  },
  async askLLM(q, chunks) {
    const ctx = chunks.map((c, i) => `[${i + 1}] (${c.fname}, p.${c.page}) ${c.text}`).join('\n\n');
    const body = JSON.stringify({
      model: S.llm.model, temperature: 0.3, stream: false,
      messages: [
        { role: 'system', content: 'You are a study guide. Answer ONLY from the provided notes. Reply in the same language as the question. Be concise and cite sources like [1].' },
        { role: 'user', content: `Notes:\n${ctx}\n\nQuestion: ${q}` }],
    });
    const url = S.llm.url.replace(/\/+$/, '') + '/chat/completions';
    const headers = { 'Content-Type': 'application/json' };
    if (S.llm.key) headers.Authorization = 'Bearer ' + S.llm.key;
    let data;
    if (FS.native) { const r = await Native.http(url, { method: 'POST', headers, body: JSON.parse(body) }); if (r.status >= 300) throw new Error('HTTP ' + r.status); data = r.data; }
    else { const r = await fetch(url, { method: 'POST', headers, body }); if (!r.ok) throw new Error('HTTP ' + r.status); data = await r.json(); }
    if (typeof data === 'string') data = JSON.parse(data);
    return data.choices[0].message.content.trim();
  },

  /* ---- question generation ---- */
  makeQuestions(chunks, n = 6) {
    const sents = []; const seen = new Set();
    chunks.forEach(c => splitSentences(c.text).forEach(s => { if (s.length >= 40 && s.length <= 260 && !seen.has(s)) { seen.add(s); sents.push({ s, c }); } }));
    const rawWords = s => s.split(/\s+/).map(w => w.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ''));
    const pool = new Map();
    sents.forEach(({ s }) => rawWords(s).forEach(w => {
      const tk = tokenize(w); if (w.length < 4 || !tk.length) return;
      pool.set(w.toLowerCase(), { w, idf: this.idf(tk[0]), num: /\d/.test(w), bn: /[ঀ-৿]/.test(w) });
    }));
    const poolArr = [...pool.values()].sort((a, b) => b.idf - a.idf).slice(0, 80);
    const defs = [], mcqs = [];
    for (const { s, c } of shuffle(sents)) {
      const dm = s.match(/^([A-Z][\w\s\-()]{2,50}?)\s+(?:is|are|means|refers to|is defined as)\s+(.{20,})$/) || s.match(/^(.{2,40}?)\s+(?:হলো|হল|বলতে)\s+(.{12,})$/);
      if (dm) { defs.push({ type: 'flash', q: /[ঀ-৿]/.test(dm[1]) ? `${dm[1].trim()} কী?` : `What is ${dm[1].trim()}?`, a: s, src: this.src(c) }); continue; }
      const words = rawWords(s); let best = null, bs = -1;
      words.forEach((w, i) => {
        if (i === 0 || w.length < 4) return; const tk = tokenize(w); if (!tk.length) return;
        const sc = this.idf(tk[0]) + (/^\p{Lu}/u.test(w) ? 1 : 0) + (/\d/.test(w) ? 1 : 0);
        if (sc > bs) { bs = sc; best = w; }
      });
      if (!best) continue;
      const bl = best.toLowerCase(), num = /\d/.test(best), bn = /[ঀ-৿]/.test(best);
      const dis = shuffle(poolArr.filter(p => p.w.toLowerCase() !== bl && p.num === num && p.bn === bn)).slice(0, 3).map(p => p.w);
      const text = s.replace(best, '_____');
      if (dis.length === 3) {
        const options = shuffle([best, ...dis]);
        mcqs.push({ type: 'mcq', q: text, options, answer: options.indexOf(best), src: this.src(c) });
      } else mcqs.push({ type: 'fill', q: text, a: best, src: this.src(c) });
    }
    const out = [...defs.slice(0, Math.ceil(n / 3)), ...mcqs];
    return shuffle(out.slice(0, n * 2)).slice(0, n);
  },
};
