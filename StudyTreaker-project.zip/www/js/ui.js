'use strict';
const IC = {
  home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  layers: '<path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="m2 12 10 5 10-5"/><path d="m2 17 10 5 10-5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  bot: '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V5"/><circle cx="12" cy="4" r="1"/><circle cx="9" cy="14" r="1.2"/><circle cx="15" cy="14" r="1.2"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  gear: '<path d="M4 6h9M19 6h1M4 12h3M13 12h7M4 18h11M21 18h-1"/><circle cx="16" cy="6" r="2.2"/><circle cx="10" cy="12" r="2.2"/><circle cx="17.5" cy="18" r="2.2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', x: '<path d="M18 6 6 18M6 6l12 12"/>', check: '<path d="m5 12 5 5 9-10"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>', send: '<path d="m4 12 16-8-6 16-3-7z"/>',
  play: '<path d="M7 4v16l13-8z"/>', pause: '<path d="M8 4v16M16 4v16"/>', reset: '<path d="M4 12a8 8 0 1 0 3-6.2M4 4v5h5"/>',
  star: '<path d="m12 3 2.8 5.8 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.3l1.1-6.2L3 9.7l6.2-.9z"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  file: '<path d="M7 3h7l5 5v13H7z"/>', cam: '<path d="M4 8h3l2-3h6l2 3h3v12H4z"/><circle cx="12" cy="14" r="3.5"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  cap: '<path d="M12 4 2 9l10 5 10-5zM6 12v4c3 3 9 3 12 0v-4"/>', ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
};
const svg = (n, s = 20) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${IC[n]}</svg>`;
const fileIcon = n => { const e = (n.split('.').pop() || '').toLowerCase(); return e === 'pdf' ? '📕' : /^(jpe?g|png|webp|gif|bmp|heic)$/.test(e) ? '🖼️' : /^docx?$/.test(e) ? '📝' : /^(pptx?)$/.test(e) ? '📊' : /^(xlsx?|csv)$/.test(e) ? '📈' : /^(txt|md)$/.test(e) ? '📃' : '📎'; };

const UI = { tab: 'home', course: null, filter: 'all', toolTab: 'timer', stack: [], cur: null, sheet: null, draft: null,
  search: { q: '', all: false, course: '' }, aiCourse: '' };

/* ---------- toast / progress / sheets ---------- */
let _toastT;
function toast(msg, ms = 2600) { const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(_toastT); _toastT = setTimeout(() => el.classList.remove('show'), ms); }
function setProgress(text, frac) {
  const el = $('#prog'); if (text == null) { el.classList.remove('show'); return; }
  el.classList.add('show'); $('#progText').textContent = text; $('#progBar').style.width = Math.round((frac || 0) * 100) + '%';
}
function openSheet(html, { full = false, center = false, onClose } = {}) {
  const w = document.createElement('div'); w.className = 'sheet-wrap' + (center ? ' center' : '');
  w.innerHTML = `<div class="backdrop" data-act="close-top"></div><div class="sheet${full ? ' full' : ''}">${html}</div>`;
  $('#overlay').appendChild(w);
  const o = { el: w, body: w.querySelector('.sheet'), onClose,
    set(h) { const st = this.body.scrollTop; this.body.innerHTML = h; this.body.scrollTop = st; },
    close() { const i = UI.stack.indexOf(o); if (i >= 0) UI.stack.splice(i, 1); w.remove(); o.onClose && o.onClose(); } };
  UI.stack.push(o); return o;
}
const closeTop = () => { const o = UI.stack[UI.stack.length - 1]; if (o) { o.close(); return true; } return false; };
function confirmBox(msg, ok = 'Delete', danger = true) {
  return new Promise(res => {
    const s = openSheet(`<p class="cmsg">${esc(msg)}</p><div class="row end"><button class="btn ghost" data-r="0">${t('Cancel')}</button><button class="btn ${danger ? 'danger' : ''}" data-r="1">${esc(t(ok))}</button></div>`, { center: true, onClose: () => res(false) });
    $$('[data-r]', s.el).forEach(b => b.onclick = () => { res(b.dataset.r === '1'); s.onClose = null; s.close(); });
  });
}
function formSheet(title, fields, ok = 'Save') {
  return new Promise(res => {
    const f = fields.map(x => `<label class="fl">${esc(t(x.label))}${x.type === 'select'
      ? `<select id="f_${x.id}">${x.options.map(o => `<option value="${esc(o[0])}">${esc(o[1])}</option>`).join('')}</select>`
      : `<input id="f_${x.id}" type="${x.type || 'text'}" value="${esc(x.value || '')}" placeholder="${esc(x.ph || '')}">`}</label>`).join('');
    const s = openSheet(`<h3>${esc(t(title))}</h3>${f}<div class="row end"><button class="btn ghost" data-r="0">${t('Cancel')}</button><button class="btn" data-r="1">${esc(t(ok))}</button></div>`, { onClose: () => res(null) });
    $$('[data-r]', s.el).forEach(b => b.onclick = () => {
      if (b.dataset.r === '1') { const v = {}; fields.forEach(x => v[x.id] = $('#f_' + x.id, s.el).value.trim()); res(v); }
      else res(null);
      s.onClose = null; s.close();
    });
  });
}
function pickFiles(capture) {
  return new Promise(res => {
    const i = document.createElement('input'); i.type = 'file'; i.style.display = 'none';
    if (capture) { i.accept = 'image/*'; i.setAttribute('capture', 'environment'); } else i.multiple = true;
    i.onchange = () => { res([...i.files]); i.remove(); }; i.oncancel = () => { res([]); i.remove(); };
    document.body.appendChild(i); i.click();
  });
}
async function ensureRoot() {
  if (S.root) return true;
  if (FS.native && !(await confirmBox(t('Choose a folder where your files will be saved. You can pick Internal storage or an SD card.'), 'Choose folder', false))) return false;
  try { await FS.pickRoot(); renderAll(); return true; } catch (e) { toast(t('No folder selected')); return false; }
}

/* ---------- helpers for views ---------- */
const ringSvg = (pct, size = 96) => { const r = 40, c = 2 * Math.PI * r; return `<svg class="ring" width="${size}" height="${size}" viewBox="0 0 100 100"><circle cx="50" cy="50" r="${r}" class="rb"/><circle cx="50" cy="50" r="${r}" class="rf" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - pct / 100)}" transform="rotate(-90 50 50)"/><text x="50" y="57" text-anchor="middle">${pct}%</text></svg>`; };
const grad = c => { const g = COLORS[(c.color || 0) % COLORS.length]; return `background:linear-gradient(135deg,${g[0]},${g[1]})`; };
const empty = (icon, msg, btn, act) => `<div class="empty"><div class="eico">${icon}</div><p>${esc(t(msg))}</p>${btn ? `<button class="btn" data-act="${act}">${esc(t(btn))}</button>` : ''}</div>`;
function greeting() { const h = new Date().getHours(); return h < 12 ? ['Good Morning', '☀️'] : h < 17 ? ['Good Afternoon', '🌤️'] : h < 21 ? ['Good Evening', '🌆'] : ['Good Night', '🌙']; }
function courseCard(c) {
  const d = doneCount(c), p = c.total ? Math.round(d * 100 / c.total) : 0;
  return `<div class="ccard" style="${grad(c)}" data-act="open-course" data-id="${c.id}"><span class="cp">${p}%</span><div class="cico">📘</div><h4>${esc(c.name)}</h4><div class="crow"><span>${d}/${c.total} ${t('Classes')}</span></div><div class="bar"><i style="width:${p}%"></i></div></div>`;
}

/* ---------- header / tabs ---------- */
function renderTop() {
  const term = curTerm();
  $('#top').innerHTML = `<div class="hbar"><div class="logo">${svg('cap', 22)}</div>
    <button class="chip" data-act="open-settings" data-sec="term">${esc(term ? term.name : t('Create Level/Term'))} ▾</button>
    <span id="hTimer" class="chip tmr" data-act="goto-timer" style="display:none"></span>
    ${S.profile.lock ? `<button class="ibtn" data-act="lock-now" title="Lock">${svg('lock')}</button>` : ''}
    <button class="ibtn" data-act="open-settings" title="${t('Settings')}">${svg('gear')}</button></div>`;
}
function renderTabs() {
  const T = [['home', 'home', 'Home'], ['classes', 'layers', 'Classes'], ['search', 'search', 'Search'], ['ai', 'bot', 'AI Guide'], ['tools', 'grid', 'Tools']];
  $('#tabs').innerHTML = T.map(x => `<button class="${UI.tab === x[0] ? 'on' : ''}" data-act="tab" data-tab="${x[0]}">${svg(x[1], 22)}<span>${t(x[2])}</span></button>`).join('');
}
const scrollChat = () => setTimeout(() => window.scrollTo(0, document.body.scrollHeight), 30);
function renderAll() { applyTheme(); renderTop(); renderTabs(); renderView(); tickTimer(); }
function renderView() { const v = $('#view'); v.innerHTML = Views[UI.tab](); if (UI.tab === 'ai') scrollChat(); if (UI.tab === 'search') runSearch(); }
function applyTheme() {
  const th = S.profile.theme; const dark = th === 'dark' || (th === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.documentElement.lang = S.profile.lang;
}

/* ---------- views ---------- */
const Views = {
  home() {
    const term = curTerm();
    if (!term) return empty('🎓', 'Create your first Level/Term to begin.', 'Get started', 'open-settings');
    const cs = courses(); const total = cs.reduce((a, c) => a + c.total, 0), done = cs.reduce((a, c) => a + doneCount(c), 0);
    const pct = total ? Math.round(done * 100 / total) : 0; const [g, em] = greeting();
    const tm = minutesOn(today()), goal = S.profile.goal || 120, st = streak();
    // continue where you left off
    let cont = ''; let latest = null;
    for (const c of cs) { const m = S.classes[c.id] || {}; for (let i = 1; i <= c.total; i++) { if (!m[i]?.done) { const last = Math.max(0, ...Object.values(m).map(x => x.doneAt ? +x.doneAt.replace(/-/g, '') : 0)); if (!latest || last > latest.last) latest = { c, n: i, last }; break; } } }
    if (latest) { const k = getCls(latest.c.id, latest.n); cont = `<div class="card cont" data-act="open-class" data-cid="${latest.c.id}" data-n="${latest.n}"><small>${t('Up next')}</small><b>${esc(latest.c.name)} · #${latest.n}</b><span>${esc(k?.topic || t('No topic yet'))}</span>${svg('back', 18)}</div>`; }
    const ex = S.exams.filter(e => daysUntil(e.date) >= 0).sort((a, b) => a.date.localeCompare(b.date))[0];
    const todo = S.todos.filter(x => !x.done).length;
    return `<div class="hero"><h2>${t(g)}${S.profile.name ? ', ' + esc(S.profile.name) : ''} ${em}</h2><p>${t("Let's make today productive.")}</p></div>
    <div class="card stats"><div class="ringw">${ringSvg(pct)}</div><div class="sinfo"><h3>${pct}% ${t('Completed')}</h3>
      <p>${t('Total Classes')}: <b>${total}</b> · ${t('Done')}: <b>${done}</b></p><p>${t('Today Studied')}: <b>${fmtMin(tm)}</b> / ${fmtMin(goal)}</p>
      <div class="bar sm"><i style="width:${Math.min(100, tm * 100 / goal)}%"></i></div>
      <div class="streak">🔥 ${st ? t('{n}-day streak', { n: st }) : t('Keep the streak alive!')}</div></div></div>
    ${cont}
    <div class="mini2"><div class="card mini" data-act="goto-tools" data-tt="todo"><b>${todo}</b><span>${t('Pending tasks')}</span></div>
      <div class="card mini" data-act="goto-tools" data-tt="exams"><b>${ex ? daysUntil(ex.date) + 'd' : '—'}</b><span>${ex ? esc(ex.title) : t('No upcoming exam')}</span></div></div>
    <h3 class="sec">📚 ${t('Your Courses')}</h3>
    ${cs.length ? `<div class="cgrid">${cs.map(courseCard).join('')}</div>` : empty('📘', 'No courses yet. Add your subjects.', 'Add courses', 'open-courses')}`;
  },
  classes() {
    const term = curTerm(); if (!term) return Views.home();
    const c = courses().find(x => x.id === UI.course);
    if (!c) return `<h3 class="sec">${t('Choose a course')}</h3>` + (courses().length ? `<div class="cgrid">${courses().map(courseCard).join('')}</div>` : empty('📘', 'No courses yet. Add your subjects.', 'Add courses', 'open-courses'));
    const d = doneCount(c); let items = '';
    for (let i = 1; i <= c.total; i++) {
      const k = getCls(c.id, i) || { n: i, files: [], links: [] };
      if (UI.filter === 'done' && !k.done) continue; if (UI.filter === 'todo' && k.done) continue; if (UI.filter === 'star' && !k.star) continue;
      items += `<div class="klass ${k.done ? 'done' : ''}"><button class="num" data-act="toggle-done" data-n="${i}" aria-label="done">${k.done ? svg('check', 20) : '#' + i}</button>
        <div class="kb" data-act="open-class" data-cid="${c.id}" data-n="${i}"><b>${esc(k.topic || t('No topic yet'))}${k.star ? ' ⭐' : ''}</b>
        <span class="kn">${esc(k.note || '')}</span><span class="km">${k.date ? '📅 ' + esc(k.date) : ''} ${k.files.length ? '📎 ' + k.files.length : ''} ${k.links.length ? '🔗 ' + k.links.length : ''}</span></div></div>`;
    }
    const F = [['all', 'All'], ['todo', 'Pending'], ['done', 'Done'], ['star', '⭐']];
    return `<div class="card chead"><button class="btn ghost sm" data-act="course-back">${svg('back', 18)} ${t('Back')}</button><b class="ct">📘 ${esc(c.name)}</b><span class="muted">${d}/${c.total}</span></div>
      <div class="filters">${F.map(f => `<button class="${UI.filter === f[0] ? 'on' : ''}" data-act="filter" data-f="${f[0]}">${f[1].length > 1 && f[1] !== '⭐' ? t(f[1]) : f[1]}</button>`).join('')}</div>
      ${items || empty('🗂️', 'Nothing here.')}`;
  },
  search() {
    const cs = courses();
    return `<div class="sbox">${svg('search')}<input id="q" type="search" placeholder="${t('Search topics, notes, files, and text inside files…')}" value="${esc(UI.search.q)}" data-input="search" autocomplete="off"></div>
    <div class="filters"><button class="${UI.search.all ? '' : 'on'}" data-act="search-scope" data-v="0">${t('This term')}</button><button class="${UI.search.all ? 'on' : ''}" data-act="search-scope" data-v="1">${t('All terms')}</button>
    <select data-change="search-course"><option value="">${t('All courses')}</option>${cs.map(c => `<option value="${c.id}" ${UI.search.course === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div><div id="sres"></div>`;
  },
  ai() {
    const cs = courses(); const st = AI.stats();
    const msgs = S.chat.map(chatHtml).join('') || `<div class="bubble ai"><p>${t('Hi! I am your offline study guide. Ask me anything about your uploaded notes, or ask for a summary or practice questions.')}</p><p class="muted">${t('Try')}: “${t('summarize matrix')}”, “${t('make 5 questions on vectors')}”</p></div>`;
    return `<div class="aibar"><select data-change="ai-course"><option value="">${t('All my files')}</option>${cs.map(c => `<option value="${c.id}" ${UI.aiCourse === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
      <span class="muted">${st.files} ${t('files')} · ${st.chunks} ${t('passages')}</span></div>
    <div class="filters"><button data-act="ai-quick" data-k="quiz">🎯 ${t('Quick quiz')}</button><button data-act="ai-quick" data-k="sum">📚 ${t('Summarize course')}</button><button data-act="ai-clear">🧹 ${t('Clear chat')}</button></div>
    <div id="chatLog" class="chat">${msgs}</div>
    <div class="composer"><textarea id="aiq" rows="1" placeholder="${t('Ask about your notes…')}"></textarea><button class="btn round" data-act="ai-send">${svg('send', 20)}</button></div>`;
  },
  tools() {
    const T = [['timer', '⏱️', 'Timer'], ['todo', '✅', 'To-Do'], ['exams', '📅', 'Exams'], ['stats', '📊', 'Stats']];
    return `<div class="seg">${T.map(x => `<button class="${UI.toolTab === x[0] ? 'on' : ''}" data-act="tool-tab" data-tt="${x[0]}">${x[1]} ${t(x[2])}</button>`).join('')}</div>${Tools[UI.toolTab]()}`;
  },
};

/* ---------- search ---------- */
let _st;
function runSearch() {
  const box = $('#sres'); if (!box) return; const q = UI.search.q.trim();
  if (!q) { box.innerHTML = empty('🔎', 'Type a topic, note, file name, or any word inside your files.'); return; }
  const ql = q.toLowerCase(); const termId = UI.search.all ? null : curTerm()?.id; const out = { cls: [], files: [] };
  for (const T of S.terms) { if (termId && T.id !== termId) continue;
    for (const c of T.courses) { if (UI.search.course && c.id !== UI.search.course) continue;
      for (const [n, k] of Object.entries(S.classes[c.id] || {})) {
        if ((k.topic + ' ' + k.note + ' ' + k.links.map(l => l.title + l.url).join(' ')).toLowerCase().includes(ql)) out.cls.push({ c, n, k });
        k.files.forEach(f => { if (f.name.toLowerCase().includes(ql)) out.files.push({ c, n, k, f }); });
      } } }
  const hits = AI.search(q, { courseId: UI.search.course || null, termId, k: 12 });
  const hl = s => { let r = esc(s); tokenize(q).forEach(w => { try { r = r.replace(new RegExp('(' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[\\p{L}\\p{M}]*)', 'giu'), '<mark>$1</mark>'); } catch (e) { } }); return r; };
  let h = '';
  if (out.cls.length) h += `<h4 class="sec2">${t('Classes')}</h4>` + out.cls.slice(0, 20).map(x => `<div class="card res" data-act="open-class" data-cid="${x.c.id}" data-n="${x.n}"><b>${esc(x.c.name)} · #${x.n}</b><div>${hl(x.k.topic)}</div><small>${hl(x.k.note)}</small></div>`).join('');
  if (out.files.length) h += `<h4 class="sec2">${t('Files')}</h4>` + out.files.slice(0, 20).map(x => `<div class="card res" data-act="file-open" data-cid="${x.c.id}" data-n="${x.n}" data-id="${x.f.id}"><b>${fileIcon(x.f.name)} ${hl(x.f.name)}</b><small>${esc(x.c.name)} · #${x.n}</small></div>`).join('');
  if (hits.length) h += `<h4 class="sec2">${t('Inside your files')}</h4>` + hits.map(({ chunk: c }) => `<div class="card res"><b>${fileIcon(c.fname)} ${esc(c.fname)}</b><small>${esc(findCourse(c.courseId)?.course.name || '')} · #${c.n} · ${t('page')} ${c.page}</small><p>${hl(AI.snippet(c.text, q))}</p>
    <div class="row"><button class="btn ghost sm" data-act="open-class" data-cid="${c.courseId}" data-n="${c.n}">${t('Open class')}</button><button class="btn ghost sm" data-act="file-open" data-cid="${c.courseId}" data-n="${c.n}" data-id="${c.fileId}">${t('Open file')}</button></div></div>`).join('');
  box.innerHTML = h || empty('🤷', 'No results found.');
}

/* ---------- AI chat ---------- */
function srcChips(src) { return (src || []).map(s => `<button class="src" data-act="open-class" data-cid="${s.courseId}" data-n="${s.n}">${fileIcon(s.fname)} ${esc(s.fname.slice(0, 24))} · p.${s.page}</button>`).join(''); }
function chatHtml(m, i) {
  if (m.role === 'user') return `<div class="bubble me"><p>${esc(m.text)}</p></div>`;
  let body = m.bullets ? '<ul>' + m.bullets.map(b => `<li>${esc(b)}</li>`).join('') + '</ul>' : m.text ? m.text.split('\n').filter(Boolean).map(p => `<p>${esc(p)}</p>`).join('') : '';
  if (m.questions) body += `<p>${t('I made {n} questions from your notes.', { n: m.questions.length })}</p><button class="btn sm" data-act="quiz-start" data-i="${i}">🎯 ${t('Start quiz')}</button>`;
  return `<div class="bubble ai">${body}${m.sources?.length ? `<div class="srcs">${srcChips(m.sources)}</div>` : ''}${m.llm ? `<small class="muted">via your LLM</small>` : ''}</div>`;
}
function pushChat(m) { S.chat.push(m); if (S.chat.length > 30) S.chat.shift(); save(); const log = $('#chatLog'); if (log) { log.insertAdjacentHTML('beforeend', chatHtml(m, S.chat.length - 1)); scrollChat(); } }
async function aiAsk(q) {
  if (!q) return; pushChat({ role: 'user', text: q });
  const log = $('#chatLog'); const th = document.createElement('div'); th.className = 'bubble ai'; th.innerHTML = '<p class="muted">…</p>'; log?.appendChild(th); scrollChat();
  let r; try { r = await AI.answer(q, { courseId: UI.aiCourse || null }); } catch (e) { console.warn(e); r = { kind: 'none' }; }
  th.remove();
  if (r.kind === 'none') pushChat({ role: 'ai', text: AI.stats().chunks ? t('I could not find that in your files. Try different keywords.') : t('No readable text yet. Add PDF, DOCX, PPTX or text files to a class first (photos are stored but cannot be read offline).') });
  else pushChat({ role: 'ai', ...r });
}
