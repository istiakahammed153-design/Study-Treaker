'use strict';
const Act = {
  'close-top': () => closeTop(),
  tab(el) { UI.tab = el.dataset.tab; if (UI.tab === 'classes' && !UI.course) UI.course = null; window.scrollTo(0, 0); renderAll(); },
  'goto-timer'() { UI.tab = 'tools'; UI.toolTab = 'timer'; renderAll(); },
  'goto-tools'(el) { UI.tab = 'tools'; UI.toolTab = el.dataset.tt; renderAll(); },
  'open-course'(el) { UI.course = el.dataset.id; UI.tab = 'classes'; UI.filter = 'all'; window.scrollTo(0, 0); renderAll(); },
  'course-back'() { UI.course = null; renderView(); },
  filter(el) { UI.filter = el.dataset.f; renderView(); },
  'open-class'(el) { UI.stack.filter(s => s.el.classList.contains('center')).forEach(s => s.close()); openClassSheet(el.dataset.cid, el.dataset.n); },
  'toggle-done'(el) {
    const n = +el.dataset.n, k = ensureCls(UI.course, n); k.done = !k.done; k.doneAt = k.done ? today() : ''; save(); renderView(); renderTop();
    if (k.done) toast('✅ ' + t('Class {n} completed', { n }));
  },
  'open-settings'(el) { if (UI.set) return; openSettings(el.dataset.sec); },
  'open-courses'() { openSettings('courses'); },
  'lock-now'() { showLock(); },
  /* class sheet */
  'cs-done'() { const k = ensureCls(UI.cur.cid, UI.cur.n); k.done = !k.done; k.doneAt = k.done ? today() : ''; save(); refreshClassSheet(); },
  'cs-star'() { const k = ensureCls(UI.cur.cid, UI.cur.n); k.star = !k.star; save(); refreshClassSheet(); },
  async 'cs-addfiles'() { if (!(await ensureRoot())) return; importFiles(await pickFiles(false)); },
  async 'cs-camera'() { if (!(await ensureRoot())) return; importFiles(await pickFiles(true)); },
  async 'cs-addlink'() {
    const v = await formSheet('Add link', [{ id: 'url', label: 'URL', ph: 'https://…' }, { id: 'title', label: 'Title (optional)' }]); if (!v || !v.url) return;
    const url = /^https?:\/\//i.test(v.url) ? v.url : 'https://' + v.url;
    ensureCls(UI.cur.cid, UI.cur.n).links.push({ id: uid(), url, title: v.title }); save(); refreshClassSheet();
  },
  'link-open'(el) { const l = getCls(UI.cur.cid, UI.cur.n).links.find(x => x.id === el.dataset.id); if (l) window.open(l.url, '_blank'); },
  'link-del'(el) { const k = getCls(UI.cur.cid, UI.cur.n); k.links = k.links.filter(x => x.id !== el.dataset.id); save(); refreshClassSheet(); },
  async 'file-open'(el) {
    const cid = el.dataset.cid || UI.cur?.cid, n = el.dataset.n || UI.cur?.n; const f = getCls(cid, +n)?.files.find(x => x.id === el.dataset.id); if (!f) return;
    try { await FS.open(f.uri, f.mime, f.name); } catch (e) { toast(t('Could not open the file. It may have been moved or deleted.')); }
  },
  async 'file-del'(el) {
    if (!(await confirmBox(t('Delete this file from your storage too?')))) return;
    const k = getCls(UI.cur.cid, UI.cur.n); const f = k.files.find(x => x.id === el.dataset.id); if (!f) return;
    await FS.remove(f.uri); await AI.removeFile(f.id); k.files = k.files.filter(x => x.id !== f.id); save(); refreshClassSheet();
  },
  async 'cs-clear'() {
    if (!(await confirmBox(t('Clear this class? Its notes and files will be deleted.')))) return;
    const k = getCls(UI.cur.cid, UI.cur.n); if (k) { for (const f of k.files) { await FS.remove(f.uri); await AI.removeFile(f.id); } delete S.classes[UI.cur.cid][UI.cur.n]; save(); }
    UI.sheet.close();
  },
  /* search / ai */
  'search-scope'(el) { UI.search.all = el.dataset.v === '1'; renderView(); },
  'ai-send'() { const i = $('#aiq'); const q = i.value.trim(); i.value = ''; const lv = $('#aiLive'); if (lv) lv.innerHTML = ''; aiAsk(q); },
  'ai-ask'(el) { aiAsk(el.dataset.q); },
  'ai-clear'() { S.chat = []; save(); renderView(); },
  'ai-quick'(el) {
    if (!AI.stats().chunks) return aiAsk('x');
    if (el.dataset.k === 'quiz') { const qs = AI.makeQuestions(AI.sampleChunks(UI.aiCourse || null, 8), 8); if (!qs.length) return toast(t('Not enough text to make questions.')); pushChat({ role: 'ai', questions: qs, sources: AI.dedupeSources(AI.sampleChunks(UI.aiCourse || null, 3)) }); }
    else { const pool = AI.chunks.filter(c => !UI.aiCourse || c.courseId === UI.aiCourse); const sm = AI.summarize(pool.slice(0, 60), 7); pushChat({ role: 'ai', bullets: sm.map(o => o.s), sources: AI.dedupeSources(sm.map(o => o.c)) }); }
  },
  'quiz-start'(el) { const m = S.chat[+el.dataset.i]; if (m?.questions) startQuiz(m.questions); },
  /* tools */
  'tool-tab'(el) { UI.toolTab = el.dataset.tt; renderView(); },
  'tm-start'() { Timer.start(); renderView(); tickTimer(); },
  'tm-pause'() { Timer.pause(); renderView(); },
  'tm-reset'() { Timer.reset(); renderView(); tickTimer(); },
  'tm-mode'(el) { Timer.pause(); S.timer.mode = el.dataset.m; S.timer.remaining = null; save(); renderView(); },
  'tm-dur'(el) { setDur(+el.dataset.m); },
  async 'tm-log'(el, e) { e.preventDefault(); const v = await formSheet('Add study time', [{ id: 'm', label: 'Minutes', type: 'number', value: '30' }]); if (v && +v.m > 0) { Timer.log(+v.m, S.timer.course); toast(t('Logged {n} min', { n: +v.m })); renderAll(); } },
  'td-add'() { const x = $('#tdText').value.trim(); if (!x) return; S.todos.push({ id: uid(), text: x, done: false, due: $('#tdDue').value, prio: +$('#tdPrio').value }); save(); renderView(); },
  'td-toggle'(el) { const x = S.todos.find(y => y.id === el.dataset.id); x.done = !x.done; save(); renderView(); },
  'td-del'(el) { S.todos = S.todos.filter(y => y.id !== el.dataset.id); save(); renderView(); },
  'td-clear'() { S.todos = S.todos.filter(y => !y.done); save(); renderView(); },
  async 'ex-add'() {
    const v = await formSheet('Add exam / deadline', [{ id: 'title', label: 'Title', ph: 'Mid-term: Mathematics' }, { id: 'date', label: 'Date', type: 'date' }, { id: 'course', label: 'Course', type: 'select', options: [['', t('General')], ...courses().map(c => [c.id, c.name])] }]);
    if (!v || !v.title || !v.date) return; S.exams.push({ id: uid(), ...v }); save(); renderView();
  },
  'ex-del'(el) { S.exams = S.exams.filter(y => y.id !== el.dataset.id); save(); renderView(); },
  /* settings */
  'set-go'(el) { UI.setPage = el.dataset.p; refreshSettings(); },
  'set-back'() { closeTop(); },
  'pf-seg'(el) { S.profile[el.dataset.f] = el.dataset.v; save(); refreshSettings(); renderAll(); },
  'goal-step'(el) { S.profile.goal = Math.max(15, Math.min(900, (S.profile.goal || 120) + +el.dataset.d)); save(); refreshSettings(); },
  'term-pick'(el) { S.activeTerm = el.dataset.id; UI.course = null; save(); refreshSettings(); renderTop(); },
  async 'term-new'() {
    const v = await formSheet('New Level/Term', [{ id: 'name', label: 'Name', ph: 'E.g. Level-1, Term-2' }], 'Create'); if (!v || !v.name) return;
    const T = { id: uid(), name: v.name, courses: [] }; S.terms.push(T); S.activeTerm = T.id; UI.course = null; save(); refreshSettings(); renderTop(); toast(t('Created') + ': ' + v.name);
  },
  async 'term-delete'() {
    const T = curTerm(); if (!T || !(await confirmBox(t('Delete "{x}" and all its notes? Files already saved in your storage folder are NOT deleted.', { x: T.name })))) return;
    for (const c of T.courses) { delete S.classes[c.id]; await AI.removeCourse(c.id); }
    S.terms = S.terms.filter(x => x.id !== T.id); S.activeTerm = S.terms[0]?.id || null; UI.course = null; save(); refreshSettings(); renderTop();
  },
  'course-new'() { UI.ce = { id: null, name: '', total: 20, color: courses().length % 8 }; UI.setPage = 'course'; refreshSettings(); },
  'course-edit'(el) { const c = courses().find(x => x.id === el.dataset.id); if (!c) return; UI.ce = { ...c }; UI.setPage = 'course'; refreshSettings(); },
  'ce-step'(el) { UI.ce.total = Math.max(1, Math.min(200, UI.ce.total + +el.dataset.d)); refreshSettings(); },
  'ce-color'(el) { UI.ce.color = +el.dataset.c; refreshSettings(); },
  'course-save'() {
    const c = UI.ce, T = curTerm(); if (!c.name.trim()) return toast(t('Course name cannot be empty'));
    if (c.id) { const x = T.courses.find(y => y.id === c.id); if (x) Object.assign(x, { name: c.name.trim(), total: c.total, color: c.color }); }
    else T.courses.push({ id: uid(), name: c.name.trim(), total: c.total, color: c.color });
    save(); UI.setPage = 'terms'; refreshSettings(); toast('💾 ' + t('Saved'));
  },
  async 'course-del'() {
    const c = UI.ce; if (!(await confirmBox(t('Remove "{x}" from this term? Its notes will be deleted (saved files stay in storage).', { x: c.name })))) return;
    const T = curTerm(); T.courses = T.courses.filter(x => x.id !== c.id); delete S.classes[c.id]; await AI.removeCourse(c.id);
    if (UI.course === c.id) UI.course = null; save(); UI.setPage = 'terms'; refreshSettings();
  },
  async 'pick-root'() { try { await FS.pickRoot(); refreshSettings(); toast(t('Storage folder set')); } catch (e) { toast(t('No folder selected')); } },
  async 'backup-now'() { try { if (!S.root) return toast(t('Choose a storage folder first')); await Backup.now(); refreshSettings(); toast(t('Backup saved')); } catch (e) { toast(t('Backup failed')); } },
  async 'backup-restore'() {
    if (!S.root) return toast(t('Choose a storage folder first'));
    if (!(await confirmBox(t('Replace current data with the backup found in your storage folder?'), 'Restore', false))) return;
    try { await Backup.restore(); await AI.load(); UI.set?.close(); renderAll(); toast(t('Backup restored. Use "Re-index all files" to rebuild search.')); } catch (e) { toast(t('No backup found in this folder')); }
  },
  reindex() { reindexAll(); },
  async 'llm-test'() { try { const r = await AI.askLLM('Say OK', [{ fname: 'test', page: 1, text: 'Test.' }]); toast('✅ ' + r.slice(0, 40)); } catch (e) { toast('❌ ' + (e.message || e)); } },
  async 'pin-set'() {
    const v = await formSheet('Set PIN lock', [{ id: 'p', label: 'New PIN (4-8 digits)', type: 'password' }]); if (!v) return;
    if (!/^\d{4,8}$/.test(v.p)) return toast(t('PIN must be 4-8 digits')); S.profile.lock = await sha(v.p); save(); refreshSettings(); toast(t('PIN set'));
  },
  'pin-off'() { S.profile.lock = ''; save(); refreshSettings(); },
};
function setDur(m) { m = Math.max(1, Math.min(240, m || 25)); const T = S.timer; if (T.running) Timer.pause(); T.dur = m; if (T.mode === 'focus') T.remaining = null; save(); renderView(); }
const Chg = {
  'search-course'(el) { UI.search.course = el.value; runSearch(); },
  'ai-course'(el) { UI.aiCourse = el.value; renderView(); },
  'tm-course'(el) { S.timer.course = el.value; save(); },
  'tm-custom'(el) { setDur(+el.value); },
  'cs-field'(el) { const k = ensureCls(UI.cur.cid, UI.cur.n); k[el.dataset.f] = el.value; save(); },
  pf(el) { const f = el.dataset.f; S.profile[f] = f === 'goal' ? Math.max(10, +el.value || 120) : el.value; save(); if (f === 'lang' || f === 'theme') { refreshSettings(); renderAll(); } },
  llm(el) { S.llm[el.dataset.f] = el.type === 'checkbox' ? el.checked : el.value.trim(); save(); },
};
const Inp = {
  search(el) { UI.search.q = el.value; clearTimeout(_st); _st = setTimeout(runSearch, 220); },
  'cs-field': Chg['cs-field'],
  ce: el => { UI.ce[el.dataset.f] = el.value; },
  'ai-live': el => aiLive(el.value),
};
document.addEventListener('click', e => { const el = e.target.closest('[data-act]'); if (el && Act[el.dataset.act]) Act[el.dataset.act](el, e); });
document.addEventListener('change', e => { const el = e.target.closest('[data-change]'); if (el && Chg[el.dataset.change]) Chg[el.dataset.change](el, e); });
document.addEventListener('input', e => { const el = e.target.closest('[data-input]'); if (el && Inp[el.dataset.input]) Inp[el.dataset.input](el, e); });
document.addEventListener('keydown', e => { if (e.target.id === 'aiq' && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); Act['ai-send'](); } });

/* ---------- boot ---------- */
(async function boot() {
  await FS.init(); try { await AI.load(); } catch (e) { console.warn(e); }
  if (S.timer.running && Timer.left() <= 0) Timer.finish();
  renderAll();
  if (!S.profile.onboarded && !S.terms.length) showOnboarding();
  if (S.profile.lock) showLock();
  if (window.Native && Native.isNative) {
    Native.App.addListener('backButton', () => {
      if (closeTop()) return;
      if (UI.tab === 'classes' && UI.course) { UI.course = null; return renderView(); }
      if (UI.tab !== 'home') { UI.tab = 'home'; return renderAll(); }
      Native.App.exitApp();
    });
    Native.App.addListener('appStateChange', s => { if (s.isActive) tickTimer(); });
  }
  if ('serviceWorker' in navigator) { /* no SW: everything is bundled in the APK */ }
})();
