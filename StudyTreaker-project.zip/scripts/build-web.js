// Bundles the Capacitor bridge + copies vendor libs into www/
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const vendor = path.join(root, 'www', 'vendor');
fs.mkdirSync(vendor, { recursive: true });

const copy = (from, to) => fs.copyFileSync(path.join(root, 'node_modules', from), path.join(vendor, to));
copy('pdfjs-dist/build/pdf.min.js', 'pdf.min.js');
copy('pdfjs-dist/build/pdf.worker.min.js', 'pdf.worker.min.js');
copy('jszip/dist/jszip.min.js', 'jszip.min.js');

require('esbuild').buildSync({
  entryPoints: [path.join(root, 'src', 'native.js')],
  bundle: true, minify: true, format: 'iife', target: 'es2019',
  outfile: path.join(root, 'www', 'native.js'),
});
console.log('web build ok');
