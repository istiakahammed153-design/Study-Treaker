'use strict';
/* Class sheet, Settings panel, Quiz, Onboarding, Lock */
const sha = async s => { try { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('st:' + s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); } catch (e) { return 'p:' + s; } };

/* ---------- class page: nice read-only "files page" + an Edit mode ---------- */
const KLABEL = { pdf: 'PDF', img: 'Photos', doc: 'Docs', ppt: 'Slides', other: 'Other' };
const fmtDate = ms => ms ? new Date(ms).toLocaleDateString(S.profile.lang === 'bn' ? 'bn-BD' : 'en', { day: 'numeric', month: 'short', year: 'numeric' }) : '';
const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } };
const BLANK = (n) => ({ n, done: false, star: false, date: '', note: '', topic: '', files: [], links: [] });
function aiBadge(f) {
  if (f.missing) return `<span class="fbadge bad">${svg('warn', 12)} ${t('File missing')}</span>`;
  if (f.chunks > 0) return `<span class="fbadge ok">${svg('spark', 12)} ${t('AI can read')}</span>`;
  if (Extract.canIndex(f.name)) return `<span class="fbadge warn">${t('No readable text')}</span>`;
  return '';
}
function classViewHtml(cid, n) {
  const f = findCourse(cid); const k = getCls(cid, n) || BLANK(n);
  const photos = k.files.filter(x => kindOf(x.name) === 'img'), docs = k.files.filter(x => kindOf(x.name) !== 'img');
  const row = x => { const ask = x.chunks > 0 || kindOf(x.name) === 'pdf';
    return `<div class="frow ${x.missing ? 'miss' : ''}"><button class="fmain" data-act="file-open" data-cid="${cid}" data-n="${n}" data-id="${x.id}"><span class="fi">${fileIcon(x.name)}</span><span class="finfo"><b>${esc(x.name)}</b><small>${fmtSize(x.size || 0)}${x.missing ? ' · ' + t('File missing') : ''}</small></span></button>${ask ? `<button class="ibtn fai" data-act="ai-file" data-id="${x.id}" aria-label="AI">${svg('spark', 19)}</button>` : ''}</div>`; };
  const links = k.links.map(x => `<button class="frow lk" data-act="link-open" data-id="${x.id}"><span class="fi">🔗</span><span class="finfo"><b>${esc(x.title || hostOf(x.url))}</b><small>${esc(hostOf(x.url))}</small></span></button>`).join('');
  const sec = (title, html) => html ? `<h4 class="sh3">${title}</h4>${html}` : '';
  const hasAI = k.files.some(x => x.chunks > 0 || kindOf(x.name) === 'pdf');
  return `<div class="phead"><button class="ibtn" data-act="close-top" aria-label="back">${svg('back', 22)}</button><div class="pt"><small>${esc(f?.course.name || '')}</small><b>${t('Class')} #${n}</b></div><button class="btn ghost sm" data-act="cs-edit">${svg('edit', 15)} ${t('Edit')}</button></div>
    <h1 class="ctitle ${k.topic ? '' : 'ph'}">${esc(k.topic || t('Untitled topic'))}</h1>
    <div class="cline">${k.date ? `<span>${esc(k.date)}</span>` : ''}<button class="dchip ${k.done ? 'ok' : ''}" data-act="cs-done">${svg('check', 14)} ${k.done ? t('Completed') : t('Mark done')}</button></div>
    ${k.note ? `<p class="cnote">${esc(k.note)}</p>` : ''}
    ${hasAI ? `<button class="btn full" data-act="ai-class">${svg('spark', 18)} ${t('Ask AI about this class')}</button>` : ''}
    ${sec(t('Files'), docs.map(row).join(''))}
    ${photos.length ? `<h4 class="sh3">${t('Photos')}</h4><div class="pgrid">${photos.map(x => `<button class="photo" data-act="file-open" data-cid="${cid}" data-n="${n}" data-id="${x.id}" data-thumb="${x.id}" aria-label="${esc(x.name)}"><span>${svg('cam', 22)}</span></button>`).join('')}</div>` : ''}
    ${sec(t('Links'), links)}
    ${!k.files.length && !k.links.length ? `<div class="dropz" data-act="cs-edit"><b>${t('Nothing added yet')}</b><small>${t('Tap Edit to add files, photos or links')}</small></div>` : ''}`;
}
function classEditHtml(cid, n) {
  const f = findCourse(cid); const k = getCls(cid, n) || BLANK(n);
  const files = k.files.map(x => `<div class="frow"><div class="fmain" data-act="file-open" data-cid="${cid}" data-n="${n}" data-id="${x.id}"><span class="fi">${fileIcon(x.name)}</span><span class="finfo"><b>${esc(x.name)}</b><small>${fmtSize(x.size || 0)}</small></span></div><button class="ibtn red" data-act="file-del" data-id="${x.id}" aria-label="delete">${svg('trash', 18)}</button></div>`).join('');
  const links = k.links.map(x => `<div class="frow"><div class="fmain" data-act="link-open" data-id="${x.id}"><span class="fi">🔗</span><span class="finfo"><b>${esc(x.title || x.url)}</b><small>${esc(x.url)}</small></span></div><button class="ibtn" data-act="link-edit" data-id="${x.id}" aria-label="edit">${svg('pen', 17)}</button><button class="ibtn red" data-act="link-del" data-id="${x.id}" aria-label="delete">${svg('trash', 18)}</button></div>`).join('');
  return `<div class="phead"><button class="ibtn" data-act="cs-edit-done" aria-label="back">${svg('back', 22)}</button><div class="pt"><small>${esc(f?.course.name || '')}</small><b>${t('Edit class')} #${n}</b></div><button class="btn sm" data-act="cs-edit-done">${t('Done')}</button></div>
    <label class="fl">${t('Topic')}<input class="ttl" id="csTopic" value="${esc(k.topic)}" placeholder="${t('Add topic title')}" data-input="cs-field" data-f="topic" enterkeyhint="done"></label>
    <div class="grid2"><label class="fl">${t('Date')}<input type="date" value="${esc(k.date)}" data-change="cs-field" data-f="date"></label>
      <div class="fl">${t('Status')}<div class="segc"><button class="${!k.done ? 'on' : ''}" data-act="cs-status" data-v="0">${t('Pending')}</button><button class="${k.done ? 'on' : ''}" data-act="cs-status" data-v="1">${t('Completed')}</button></div></div></div>
    <label class="fl">${t('Notes')}<textarea class="note-in" rows="4" placeholder="${t('Write notes: teacher, key points…')}" data-input="cs-field" data-f="note">${esc(k.note)}</textarea></label>
    <h4 class="sh3">${t('Files')}</h4>${files}
    <div class="addbar"><button class="btn ghost" data-act="cs-addfiles">${svg('plus', 17)} ${t('Add files')}</button><button class="btn ghost" data-act="cs-camera">${svg('cam', 17)} ${t('Photo')}</button><button class="btn ghost" data-act="cs-addlink">${svg('link', 17)} ${t('Link')}</button></div>
    ${links ? `<h4 class="sh3">${t('Links')}</h4>${links}` : ''}
    <button class="btn ghost danger-t full" data-act="cs-clear">${t('Clear this class')}</button>`;
}
const classSheetHtml = (cid, n) => UI.cEdit ? classEditHtml(cid, n) : classViewHtml(cid, n);
/* image thumbnails for the photo grid (read from storage on demand) */
const Thumbs = {
  cache: new Map(), run: 0,
  clear() { this.cache.forEach(u => URL.revokeObjectURL(u)); this.cache.clear(); this.run++; },
  async hydrate(root) {
    const tok = ++this.run;
    for (const el of $$('[data-thumb]', root)) {
      if (this.run !== tok) return;
      const id = el.dataset.thumb; let url = this.cache.get(id);
      if (!url) {
        const cur = UI.cur; const f = cur && getCls(cur.cid, cur.n)?.files.find(x => x.id === id);
        if (!f || (f.size || 0) > 10485760) continue;
        try { url = URL.createObjectURL(new Blob([await FS.readBuf(f.uri)], { type: f.mime || 'image/jpeg' })); this.cache.set(id, url); } catch (e) { continue; }
      }
      el.style.backgroundImage = `url("${url}")`; el.classList.add('has');
    }
  },
};
function openClassSheet(cid, n, edit = false) {
  if (UI.sheet && UI.stack.includes(UI.sheet)) { const o = UI.sheet; o.onClose = null; o.close(); }
  UI.cur = { cid, n: +n }; UI.cEdit = !!edit; UI.cFilter = 'all';
  UI.sheet = openSheet(classSheetHtml(cid, +n), { full: true, page: true, onClose: () => { Thumbs.clear(); UI.sheet = null; UI.cur = null; UI.cEdit = false; renderView(); } });
  Thumbs.hydrate(UI.sheet.el);
}
const refreshClassSheet = () => {
  if (!(UI.sheet && UI.cur)) return;
  UI.sheet.set(classSheetHtml(UI.cur.cid, UI.cur.n)); Thumbs.hydrate(UI.sheet.el);
};

async function importFiles(files) {
  const { cid, n } = UI.cur || {}; if (!cid || !files.length) return;
  if (!(await ensureRoot())) return;
  const f = findCourse(cid); const dir = [f.term.name, f.course.name, 'Class-' + pad(n)]; let ok = 0;
  for (let i = 0; i < files.length; i++) {
    const file = files[i]; const tag = `${i + 1}/${files.length} · ${file.name.slice(0, 28)}`;
    setProgress(t('Saving') + ' ' + tag, 0);
    let meta; try { meta = await FS.save(file, dir, p => setProgress(t('Saving') + ' ' + tag, p * 0.8)); } catch (e) { console.warn(e); toast(t('Could not save') + ': ' + file.name); continue; }
    const fm = { id: uid(), name: meta.name, uri: meta.uri, rel: meta.rel, mime: meta.mime, size: meta.size, added: Date.now(), chunks: 0 };
    ensureCls(cid, n).files.push(fm); save(); ok++; refreshClassSheet();
    if (Extract.canIndex(file.name)) {
      setProgress(t('Reading text…') + ' ' + tag, 0.85);
      try { const pages = await Extract.run(file.name, await file.arrayBuffer(), p => setProgress(t('Reading text…') + ' ' + tag, 0.8 + p * 0.2));
        fm.chunks = await AI.addFile({ fileId: fm.id, fname: fm.name, termId: f.term.id, courseId: cid, n }, pages); save(); } catch (e) { console.warn('extract', e); }
    }
    refreshClassSheet();
  }
  setProgress(null); if (ok) toast(t('{n} file(s) added', { n: ok }));
}

/* ---------- quiz ---------- */
function startQuiz(questions) {
  const st = { i: 0, score: 0, wrong: [], questions, shown: false };
  const sh = openSheet('', { full: true });
  const draw = () => {
    const q = st.questions[st.i];
    if (!q) { sh.set(`<div class="shead"><h3>🎯 ${t('Quiz result')}</h3><button class="ibtn" data-act="close-top">${svg('x')}</button></div><div class="big center">${st.score}/${st.questions.length}</div><p class="center muted">${st.score === st.questions.length ? t('Perfect! 🎉') : t('Review the ones you missed.')}</p><div class="row center">${st.wrong.length ? `<button class="btn" id="qRetry">${t('Retry missed')}</button>` : ''}<button class="btn ghost" data-act="close-top">${t('Done')}</button></div>`);
      const b = $('#qRetry', sh.el); if (b) b.onclick = () => { sh.close(); startQuiz(st.wrong); }; return; }
    const head = `<div class="shead"><h3>${t('Question')} ${st.i + 1}/${st.questions.length}</h3><button class="ibtn" data-act="close-top">${svg('x')}</button></div><div class="bar sm"><i style="width:${st.i * 100 / st.questions.length}%"></i></div>`;
    const src = `<small class="muted">${fileIcon(q.src.fname)} ${esc(q.src.fname)} · p.${q.src.page}</small>`;
    if (q.type === 'mcq') {
      sh.set(`${head}<p class="qtext">${esc(q.q)}</p><div class="opts">${q.options.map((o, i) => `<button class="opt" data-i="${i}">${esc(o)}</button>`).join('')}</div>${src}<div id="qfb"></div>`);
      $$('.opt', sh.el).forEach(b => b.onclick = () => {
        if (st.shown) return; st.shown = true; const i = +b.dataset.i; const ok = i === q.answer;
        $$('.opt', sh.el).forEach((x, j) => x.classList.add(j === q.answer ? 'ok' : j === i ? 'bad' : 'dim'));
        if (ok) st.score++; else st.wrong.push(q);
        $('#qfb', sh.el).innerHTML = `${q.explain ? `<div class="ans">${esc(q.explain)}</div>` : ''}<button class="btn" id="qNext">${t('Next')}</button>`; $('#qNext', sh.el).onclick = () => { st.i++; st.shown = false; draw(); };
      });
    } else {
      sh.set(`${head}<p class="qtext">${esc(q.type === 'fill' ? q.q : q.q)}</p>${src}<div id="qfb"><button class="btn" id="qShow">${t('Show answer')}</button></div>`);
      $('#qShow', sh.el).onclick = () => {
        $('#qfb', sh.el).innerHTML = `<div class="ans">${esc(q.a)}</div><div class="row"><button class="btn ghost" id="qNo">😕 ${t('Missed')}</button><button class="btn" id="qYes">😎 ${t('Got it')}</button></div>`;
        $('#qYes', sh.el).onclick = () => { st.score++; st.i++; draw(); }; $('#qNo', sh.el).onclick = () => { st.wrong.push(q); st.i++; draw(); };
      };
    }
  };
  draw();
}

/* ---------- settings (grouped pages) ---------- */
const setRow = (ic, title, sub, page) => `<button class="srow" data-act="set-go" data-p="${page}"><span class="sic">${svg(ic, 20)}</span><span class="stx"><b>${t(title)}</b><small>${sub}</small></span>${svg('chev', 18)}</button>`;
const segHtml = (f, cur, opts) => `<div class="segc">${opts.map(o => `<button class="${cur === o[0] ? 'on' : ''}" data-act="pf-seg" data-f="${f}" data-v="${o[0]}">${o[1]}</button>`).join('')}</div>`;
function settingsHtml() {
  const p = S.profile, term = curTerm(), page = UI.setPage || 'main', ai = AI.stats();
  const head = (title, back) => `<div class="phead">${back ? `<button class="ibtn" data-act="set-back" aria-label="back">${svg('back', 22)}</button>` : ''}<div class="pt"><b>${t(title)}</b></div><button class="ibtn" data-act="close-top" aria-label="close">${svg('x', 22)}</button></div>`;
  if (page === 'main') return `${head('Settings', false)}
    <div class="pcard"><div class="av">${esc((p.name || '?').trim().charAt(0).toUpperCase())}</div><div><b>${esc(p.name || t('Your name'))}</b><small>${esc(term?.name || t('Create Level/Term'))}</small></div></div>
    <div class="sgroup">${setRow('user', 'Profile & preferences', `${p.lang === 'bn' ? 'বাংলা' : 'English'} · ${t(p.theme === 'auto' ? 'Auto' : p.theme === 'dark' ? 'Dark' : 'Light')} · ${fmtMin(p.goal)}`, 'profile')}
      ${setRow('cap', 'Level/Term & courses', `${esc(term?.name || '—')} · ${courses().length} ${t('courses')}`, 'terms')}</div>
    <div class="sgroup">${setRow('db', 'Storage & backup', esc(FS.label()), 'storage')}
      ${setRow('zap', 'AI engine', `${ai.files} ${t('files')} · ${ai.chunks} ${t('passages')}`, 'ai')}
      ${setRow('lock', 'Security', p.lock ? t('PIN enabled') : t('No PIN'), 'security')}</div>
    <p class="muted center sm">Study Treaker v1.1</p>`;
  if (page === 'profile') return `${head('Profile & preferences', true)}
    <div class="sgroup pad"><label class="fl">${t('Your name')}<input value="${esc(p.name)}" data-change="pf" data-f="name"></label>
      <div class="fl">${t('Language')}${segHtml('lang', p.lang, [['en', 'English'], ['bn', 'বাংলা']])}</div>
      <div class="fl">${t('Theme')}${segHtml('theme', p.theme, [['auto', t('Auto')], ['light', t('Light')], ['dark', t('Dark')]])}</div>
      <div class="fl">${t('Daily goal (minutes)')}<div class="stepper"><button data-act="goal-step" data-d="-15" aria-label="-">${svg('minus', 18)}</button><b>${fmtMin(p.goal)}</b><button data-act="goal-step" data-d="15" aria-label="+">${svg('plus', 18)}</button></div></div></div>`;
  if (page === 'terms') return `${head('Level/Term & courses', true)}
    <h4 class="sec2">${t('Level/Term')}</h4>
    <div class="sgroup">${S.terms.map(x => `<button class="srow ${x.id === term?.id ? 'sel' : ''}" data-act="term-pick" data-id="${x.id}"><span class="radio ${x.id === term?.id ? 'on' : ''}"></span><span class="stx"><b>${esc(x.name)}</b><small>${x.courses.length} ${t('courses')}</small></span>${x.id === term?.id ? `<span class="badge">${t('Active')}</span>` : ''}</button>`).join('') || `<p class="muted pad">—</p>`}
      <button class="srow add" data-act="term-new"><span class="sic">${svg('plus', 20)}</span><span class="stx"><b>${t('New Level/Term')}</b></span></button></div>
    ${term ? `<h4 class="sec2">${t('Courses')} · ${esc(term.name)}</h4>
    <div class="sgroup">${term.courses.map(c => `<button class="srow" data-act="course-edit" data-id="${c.id}"><span class="cdot" style="background:${COLORS[(c.color || 0) % 8][0]}"></span><span class="stx"><b>${esc(c.name)}</b><small>${c.total} ${t('classes')} · ${doneCount(c)} ${t('Done')}</small></span>${svg('chev', 18)}</button>`).join('')}
      <button class="srow add" data-act="course-new"><span class="sic">${svg('plus', 20)}</span><span class="stx"><b>${t('Add New Course')}</b></span></button></div>
    <button class="btn ghost danger-t full" data-act="term-delete">${svg('trash', 16)} ${t('Delete Term')}</button>` : ''}`;
  if (page === 'course') { const c = UI.ce; return `${head(c.id ? 'Edit course' : 'Add New Course', true)}
    <div class="sgroup pad"><label class="fl">${t('Course name')}<input value="${esc(c.name)}" placeholder="${t('Course name')}" data-input="ce" data-f="name"></label>
      <div class="fl">${t('Number of classes')}<div class="stepper"><button data-act="ce-step" data-d="-1" aria-label="-">${svg('minus', 18)}</button><b>${c.total}</b><button data-act="ce-step" data-d="1" aria-label="+">${svg('plus', 18)}</button></div></div>
      <div class="fl">${t('Color')}<div class="swatches">${COLORS.map((x, j) => `<button class="sw ${(c.color || 0) === j ? 'on' : ''}" style="background:linear-gradient(135deg,${x[0]},${x[1]})" data-act="ce-color" data-c="${j}" aria-label="color ${j + 1}"></button>`).join('')}</div></div></div>
    <button class="btn full" data-act="course-save">💾 ${t('Save')}</button>
    ${c.id ? `<button class="btn ghost danger-t full" data-act="course-del">${svg('trash', 16)} ${t('Remove course')}</button>` : ''}`; }
  if (page === 'storage') return `${head('Storage & backup', true)}
    <div class="sgroup pad"><div class="info">${esc(FS.label())}</div>
      <p class="muted sm">${t('Files are saved as')}: <code>StudyTreaker / ${t('Term')} / ${t('Course')} / Class-01</code></p>
      <button class="btn full" data-act="pick-root">${S.root ? t('Change folder') : t('Choose folder')}</button></div>
    <h4 class="sec2">${t('Backup')}</h4>
    <div class="sgroup pad"><p class="muted sm">${t('The backup holds your classes, notes, links, tasks and file locations (not the API key). The files themselves stay in your folder. Keep this folder to restore on a new phone.')}</p>
      <div class="row wrap"><button class="btn ghost" data-act="backup-now">${t('Backup now')}</button><button class="btn ghost" data-act="backup-restore">${t('Restore backup')}</button></div>
      <p class="muted sm">${S.lastBackup ? t('Last backup') + ': ' + new Date(S.lastBackup).toLocaleString() : t('No backup yet')}</p>
      ${Backup.hasUndo() ? `<button class="btn ghost sm" data-act="undo-restore">↩ ${t('Undo last restore')}</button>` : ''}</div>
    <h4 class="sec2">${t('Files')}</h4>
    <div class="sgroup pad"><p class="muted sm">${t('Checks that every saved file is still in your folder and re-connects the ones that moved.')}</p>
      <button class="btn ghost" data-act="files-verify">${svg('refresh', 16)} ${t('Check & repair file links')}</button></div>`;
  if (page === 'ai') {
    const L = S.llm; let unread = 0; eachFile(x => { if (Extract.canIndex(x.f.name) && !(x.f.chunks > 0)) unread++; });
    const ctxOpt = [[6000, t('Small (fast, small models)')], [14000, t('Medium (recommended)')], [40000, t('Large (long chapters)')]];
    return `${head('AI engine', true)}
    <div class="sgroup pad"><p class="muted sm">${t('Paste a free Gemini key and the AI reads your files, explains topics and solves maths. For scanned or maths PDFs, mention the page: “page 12 – solve”.')}</p>
      <label class="fl">${t('API keys')}<textarea rows="2" data-change="llm" data-f="key" autocomplete="off" autocapitalize="off" placeholder="${t('Paste your key here')}">${esc(L.key)}</textarea></label>
      <p class="muted sm">${t('Free limits are per key. Add more keys (one per line) and the app switches by itself when one is used up.')}</p>
      <button class="btn full" data-act="llm-test">${t('Test connection')}</button><p id="llmRes" class="sm" style="margin-top:8px">${L.enabled ? '✅ ' + t('Connected') : ''}</p>
      <details><summary>${t('How to get a free Gemini key')}</summary><ol class="steps"><li>${t('Open Google AI Studio (aistudio.google.com) and sign in with a Google account.')}</li><li>${t('Tap “Get API key” → “Create API key”.')}</li><li>${t('Copy the key, paste it above, keep provider = Google Gemini, then tap Test connection.')}</li></ol></details>
      <details><summary>${t('Advanced')}</summary>
        <label class="fl">${t('Provider')}<select data-change="llm-provider">${Object.entries(PRESETS).map(([k, v]) => `<option value="${k}" ${L.provider === k ? 'selected' : ''}>${esc(t(v.name))}</option>`).join('')}</select></label>
        <label class="fl">${t('Models (tried in order)')}<input value="${esc(L.model)}" data-change="llm" data-f="model" autocapitalize="off" autocorrect="off"></label>
        <label class="fl">URL<input value="${esc(L.url)}" data-change="llm" data-f="url" autocapitalize="off" autocorrect="off"></label>
        <label class="fl">${t('How much of your files to send')}<select data-change="llm-ctx">${ctxOpt.map(o => `<option value="${o[0]}" ${(+L.ctx || 14000) === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}</select></label>
        <label class="chk"><input type="checkbox" ${L.strict ? 'checked' : ''} data-change="llm" data-f="strict"> ${t('Answer only from my files')}</label>
        <p class="muted sm">${ai.files} ${t('files')} · ${ai.chunks} ${t('passages')}${unread ? ` · ${unread} ${t('files have no readable text')}` : ''}</p>
        <button class="btn ghost full" data-act="reindex">${t('Re-index all files')}</button></details></div>
    <p class="muted sm">${t('Only the passages needed for your question are sent, and only to the provider you choose.')}</p>`;
  }
  return `${head('Security', true)}<div class="sgroup pad"><div class="row wrap"><button class="btn ghost" data-act="pin-set">${p.lock ? t('Change PIN') : t('Set PIN lock')}</button>${p.lock ? `<button class="btn ghost danger-t" data-act="pin-off">${t('Remove PIN')}</button>` : ''}</div></div>`;
}
function openSettings(sec) {
  UI.setPage = sec === 'term' || sec === 'courses' ? 'terms' : ['ai', 'storage', 'profile', 'security'].includes(sec) ? sec : 'main';
  UI.set = openSheet(settingsHtml(), { full: true, onClose: () => { UI.set = null; UI.setPage = 'main'; renderAll(); } });
}
const refreshSettings = () => UI.set && UI.set.set(settingsHtml());

async function reindexAll(auto) {
  if (!auto && !(await confirmBox(t('Re-read all saved files and rebuild the search index? This may take a while.'), 'Start', false))) return;
  await DB.clear('chunks'); AI.chunks = []; AI.build(); let done = 0, failed = 0;
  const jobs = []; eachFile(x => { if (Extract.canIndex(x.f.name)) jobs.push(x); });
  for (const j of jobs) {
    setProgress(`${t('Indexing')} ${++done}/${jobs.length} · ${j.f.name.slice(0, 26)}`, done / jobs.length);
    try {
      const u = await FS.resolve(j); if (!u) throw new Error('missing');
      const pages = await Extract.run(j.f.name, await FS.readBuf(u));
      j.f.chunks = await AI.addFile({ fileId: j.f.id, fname: j.f.name, termId: j.T.id, courseId: j.c.id, n: j.n }, pages);
    } catch (e) { failed++; j.f.chunks = 0; console.warn('reindex', j.f.name, e); }
  }
  save(); setProgress(null); toast(failed ? t('Index rebuilt ({n} files could not be read)', { n: failed }) : t('Index rebuilt')); refreshSettings();
}
/* after a restore: re-connect file locations, then rebuild the search index */
async function afterRestore() {
  try {
    const r = await Backup.verify((i, n) => setProgress(`${t('Checking files…')} ${i}/${n}`, i / n)); setProgress(null);
    toast(r.missing ? t('{n} files are missing from your folder.', { n: r.missing }) : t('Backup restored. All files found.'), 4500);
  } catch (e) { setProgress(null); }
  try { await reindexAll(true); } catch (e) { setProgress(null); }
}
/* find the backup in the chosen folder, show what is inside, restore on confirmation */
async function restoreFlow(onDone) {
  let obj;
  try { obj = await Backup.peek(); }
  catch (e) { toast(t(e.message === 'bad_file' ? 'The backup file is damaged or not from this app.' : 'No backup found in this folder')); return false; }
  const sm = Backup.summary(obj);
  if (!(await confirmBox(t('Backup found: {d} · {c} classes · {f} files. Replace the current data with it?', { d: new Date(sm.at).toLocaleString(), c: sm.classes, f: sm.files }), 'Restore', false))) return false;
  try { await Backup.restore(obj); await AI.load(); } catch (e) { console.warn(e); toast(t('Restore failed')); return false; }
  UI.course = null; onDone && onDone(); renderAll(); afterRestore(); return true;
}

/* ---------- onboarding & lock ---------- */
function showOnboarding() {
  let lang = S.profile.lang;
  const sh = openSheet('', { full: true, onClose: () => { if (!S.profile.onboarded) showOnboarding(); } });
  const draw = () => sh.set(`<div class="onb"><div class="logo big">${svg('cap', 40)}</div><h2>Study Treaker</h2><p class="muted">${t('Your notes, classes and AI study guide — all offline.')}</p>
    <label class="fl">${t('Your name')}<input id="obName" value="${esc(S.profile.name)}"></label>
    <label class="fl">${t('Language')}<select id="obLang"><option value="en" ${lang === 'en' ? 'selected' : ''}>English</option><option value="bn" ${lang === 'bn' ? 'selected' : ''}>বাংলা</option></select></label>
    <label class="fl">${t('Level/Term')}<input id="obTerm" value="Level-1, Term-1"></label>
    <label class="chk"><input type="checkbox" id="obSample" checked> ${t('Add sample courses')}</label>
    <div class="info">📁 ${esc(FS.label())}</div>
    <button class="btn ghost full" id="obPick">${t('Choose storage folder (Internal / SD card)')}</button>
    <button class="btn full" id="obGo">${t('Get started')}</button>
    <div class="orline"><span>${t('or')}</span></div>
    <button class="btn ghost full" id="obRestore">${svg('refresh', 16)} ${t('Restore from backup')}</button></div>`);
  draw();
  sh.el.addEventListener('change', e => { if (e.target.id === 'obLang') { S.profile.lang = e.target.value; lang = e.target.value; S.profile.name = $('#obName', sh.el).value; draw(); } });
  sh.el.addEventListener('click', async e => {
    if (e.target.closest('#obRestore')) {
      try { if (!S.root) await FS.pickRoot(); } catch (x) { return toast(t('No folder selected')); }
      if (await restoreFlow(() => { sh.onClose = null; sh.close(); })) return; const tm = $('#obTerm', sh.el).value; draw(); $('#obTerm', sh.el).value = tm; return;
    }
    if (e.target.closest('#obPick')) {
      S.profile.name = $('#obName', sh.el).value; let picked = false; try { await FS.pickRoot(); picked = true; } catch (x) { toast(t('No folder selected')); }
      if (picked) { let has = false; try { await Backup.peek(); has = true; } catch (x) { } if (has && await restoreFlow(() => { sh.onClose = null; sh.close(); })) return; }
      const tm = $('#obTerm', sh.el).value; draw(); $('#obTerm', sh.el).value = tm;
    }
    if (e.target.closest('#obGo')) {
      S.profile.name = $('#obName', sh.el).value.trim(); const name = $('#obTerm', sh.el).value.trim() || 'Level-1, Term-1';
      const T = { id: uid(), name, courses: [] };
      if ($('#obSample', sh.el).checked) ['Mathematics-1', 'Physics-1', 'English-1'].forEach((n, i) => T.courses.push({ id: uid(), name: n, total: 20, color: i }));
      S.terms.push(T); S.activeTerm = T.id; S.profile.onboarded = true; save(); sh.onClose = null; sh.close(); renderAll();
    }
  });
}
async function showLock() {
  if (!S.profile.lock || $('#lock')) return;
  const d = document.createElement('div'); d.id = 'lock';
  d.innerHTML = `<div class="onb"><div class="logo big">${svg('lock', 36)}</div><h2>${t('Enter PIN')}</h2><input id="lockIn" type="password" inputmode="numeric" maxlength="8" autocomplete="off"><p id="lockErr" class="muted"></p><button class="btn full" id="lockGo">${t('Unlock')}</button></div>`;
  document.body.appendChild(d);
  const go = async () => { if (await sha($('#lockIn').value) === S.profile.lock) d.remove(); else { $('#lockErr').textContent = t('Wrong PIN'); $('#lockIn').value = ''; } };
  $('#lockGo').onclick = go; $('#lockIn').onkeydown = e => { if (e.key === 'Enter') go(); };
}
