'use strict';
const Act = {
  'close-top': () => closeTop(),
  tab(el) { UI.tab = el.dataset.tab; if (UI.tab === 'classes' && !UI.course) UI.course = null; window.scrollTo(0, 0); renderAll(); },
  'goto-timer'() { UI.tab = 'tools'; UI.toolTab = 'timer'; renderAll(); },
  'goto-tools'(el) { UI.tab = 'tools'; UI.toolTab = el.dataset.tt; renderAll(); },
  'open-course'(el) { UI.course = el.dataset.id; UI.tab = 'classes'; UI.filter = 'all'; window.scrollTo(0, 0); renderAll(); },
  'course-back'() { UI.course = null; UI.tab = 'courses'; renderAll(); },
  'lang-toggle'() { S.profile.lang = S.profile.lang === 'bn' ? 'en' : 'bn'; save(); renderAll(); },
  filter(el) { UI.filter = el.dataset.f; renderView(); },
  'open-class'(el) { UI.stack.filter(s => s.el.classList.contains('center')).forEach(s => s.close()); openClassSheet(el.dataset.cid, el.dataset.n); },
  'toggle-done'(el) {
    const n = +el.dataset.n, k = ensureCls(UI.course, n); k.done = !k.done; k.doneAt = k.done ? today() : ''; save(); renderView(); renderTop();
    if (k.done) toast('✅ ' + t('Class {n} completed', { n }));
  },
  'open-settings'(el) { if (UI.set) return; openSettings(el.dataset.sec); },
  'open-courses'() { openSettings('courses'); },
  'lock-now'() { showLock(); },
  /* class sheet */
  'cs-done'() { const k = ensureCls(UI.cur.cid, UI.cur.n); k.done = !k.done; k.doneAt = k.done ? today() : ''; save(); refreshClassSheet(); if (k.done) toast('✅ ' + t('Class {n} completed', { n: UI.cur.n })); },
  'cs-status'(el) { const k = ensureCls(UI.cur.cid, UI.cur.n); k.done = el.dataset.v === '1'; k.doneAt = k.done ? (k.doneAt || today()) : ''; save(); refreshClassSheet(); },
  'cs-edit'() { UI.cEdit = true; refreshClassSheet(); if (UI.sheet) UI.sheet.body.scrollTop = 0; },
  'cs-edit-done'() { UI.cEdit = false; refreshClassSheet(); renderTop(); },
  'cs-filter'(el) { UI.cFilter = el.dataset.f; refreshClassSheet(); },
  'note-more'(el) { const n = $('#ntxt'); if (!n) return; n.classList.toggle('clamp'); el.textContent = t(n.classList.contains('clamp') ? 'Show more' : 'Show less'); },
  'ai-class'() { const { cid, n } = UI.cur; const f = findCourse(cid); UI.aiSc = { courseId: cid, n: +n, fileId: '', label: `${f?.course.name || ''} · #${n}` }; UI.sheet.close(); UI.tab = 'ai'; renderAll(); },
  'ai-file'(el) { const { cid, n } = UI.cur; const x = getCls(cid, n)?.files.find(y => y.id === el.dataset.id); if (!x) return; UI.aiSc = { courseId: cid, n: +n, fileId: x.id, label: x.name }; UI.sheet.close(); UI.tab = 'ai'; renderAll(); },
  'ai-scope-clear'() { UI.aiSc = { courseId: UI.aiSc.courseId, n: 0, fileId: '', label: '' }; renderView(); },
  'ai-prefill'(el) { const i = $('#aiq'); if (!i) return; i.value = el.dataset.p; i.focus(); i.setSelectionRange(i.value.length, i.value.length); },
  'ai-retry'(el) { const i = +el.dataset.i, m = S.chat[i]; if (!m?.q) return; S.chat.splice(S.chat[i - 1]?.role === 'user' ? i - 1 : i, S.chat[i - 1]?.role === 'user' ? 2 : 1); save(); renderView(); aiAsk(m.q); },
  async 'copy-msg'(el) { const m = S.chat[+el.dataset.i]; if (!m) return; const txt = msgPlain(m); try { await navigator.clipboard.writeText(txt); } catch (e) { const a = document.createElement('textarea'); a.value = txt; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); } catch (x) { } a.remove(); } toast(t('Copied')); },
  'cs-star'() { const k = ensureCls(UI.cur.cid, UI.cur.n); k.star = !k.star; save(); refreshClassSheet(); },
  async 'cs-addfiles'() { if (!(await ensureRoot())) return; importFiles(await pickFiles(false)); },
  async 'cs-camera'() { if (!(await ensureRoot())) return; importFiles(await pickFiles(true)); },
  async 'link-edit'(el) {
    const k = getCls(UI.cur.cid, UI.cur.n); const l = k?.links.find(x => x.id === el.dataset.id); if (!l) return;
    const v = await formSheet('Edit link', [{ id: 'url', label: 'URL', value: l.url }, { id: 'title', label: 'Title (optional)', value: l.title || '' }]); if (!v || !v.url) return;
    l.url = /^https?:\/\//i.test(v.url) ? v.url : 'https://' + v.url; l.title = v.title; save(); refreshClassSheet();
  },
  async 'cs-addlink'() {
    const v = await formSheet('Add link', [{ id: 'url', label: 'URL', ph: 'https://…' }, { id: 'title', label: 'Title (optional)' }]); if (!v || !v.url) return;
    const url = /^https?:\/\//i.test(v.url) ? v.url : 'https://' + v.url;
    ensureCls(UI.cur.cid, UI.cur.n).links.push({ id: uid(), url, title: v.title }); save(); refreshClassSheet();
  },
  'link-open'(el) { const l = getCls(UI.cur.cid, UI.cur.n).links.find(x => x.id === el.dataset.id); if (l) window.open(l.url, '_blank'); },
  'link-del'(el) { const k = getCls(UI.cur.cid, UI.cur.n); k.links = k.links.filter(x => x.id !== el.dataset.id); save(); refreshClassSheet(); },
  async 'file-open'(el) {
    const cid = el.dataset.cid || UI.cur?.cid, n = +(el.dataset.n || UI.cur?.n); const loc = findCourse(cid); const k = getCls(cid, n); const f = k?.files.find(x => x.id === el.dataset.id); if (!f || !loc) return;
    try {
      const u = await FS.resolve({ T: loc.term, c: loc.course, n, k, f }); save();
      if (!u) { if (UI.sheet) refreshClassSheet(); return toast(t('Could not open the file. It may have been moved or deleted.')); }
      await FS.open(u, f.mime, f.name);
    } catch (e) { toast(t('Could not open the file. It may have been moved or deleted.')); }
  },
  async 'file-del'(el) {
    if (!(await confirmBox(t('Delete this file from your storage too?')))) return;
    const k = getCls(UI.cur.cid, UI.cur.n); const f = k.files.find(x => x.id === el.dataset.id); if (!f) return;
    await FS.remove(f.uri); await AI.removeFile(f.id); k.files = k.files.filter(x => x.id !== f.id); save(); refreshClassSheet();
  },
  async 'cs-clear'() {
    if (!(await confirmBox(t('Clear this class? Its notes and files will be deleted.')))) return;
    const k = getCls(UI.cur.cid, UI.cur.n); if (k) { for (const f of k.files) { await FS.remove(f.uri); await AI.removeFile(f.id); } delete S.classes[UI.cur.cid][UI.cur.n]; save(); }
    UI.sheet.close();
  },
  /* search / ai */
  'search-scope'(el) { UI.search.all = el.dataset.v === '1'; renderView(); },
  'ai-send'() { const i = $('#aiq'); const q = i.value.trim(); i.value = ''; const lv = $('#aiLive'); if (lv) lv.innerHTML = ''; aiAsk(q); },
  'ai-ask'(el) { aiAsk(el.dataset.q); },
  'ai-clear'() { S.chat = []; save(); renderView(); },
  'ai-quick'(el) {
    if (!AI.stats().chunks) return aiAsk('x');
    const sc = aiScope(); const pool = (sc.fileId || sc.n) ? AI.scopeChunks(sc) : AI.chunks.filter(c => !sc.courseId || c.courseId === sc.courseId);
    if (el.dataset.k === 'quiz') {
      if (AI.llmReady()) return aiAsk('Make 6 quiz questions', t('Quick quiz'));
      const smp = shuffle(pool).slice(0, 8); const qs = AI.makeQuestions(smp, 8); if (!qs.length) return toast(t('Not enough text to make questions.'));
      pushChat({ role: 'ai', questions: qs, sources: AI.dedupeSources(smp.slice(0, 3)) });
    } else {
      if (AI.llmReady()) return aiAsk('Summarize the key points of everything in scope in a clear, well organised way.', t('Summarize course'));
      const sm = AI.summarize(pool.slice(0, 60), 7); pushChat({ role: 'ai', bullets: sm.map(o => o.s), sources: AI.dedupeSources(sm.map(o => o.c)) });
    }
  },
  'quiz-start'(el) { const m = S.chat[+el.dataset.i]; if (m?.questions) startQuiz(m.questions); },
  /* tools */
  'tool-tab'(el) { UI.toolTab = el.dataset.tt; renderView(); },
  'tm-start'() { Timer.start(); renderView(); tickTimer(); },
  'tm-pause'() { Timer.pause(); renderView(); },
  'tm-reset'() { Timer.reset(); renderView(); tickTimer(); },
  'tm-mode'(el) { Timer.pause(); S.timer.mode = el.dataset.m; S.timer.remaining = null; save(); renderView(); },
  'tm-dur'(el) { setDur(+el.dataset.m); },
  async 'tm-log'(el, e) { e.preventDefault(); const v = await formSheet('Add study time', [{ id: 'm', label: 'Minutes', type: 'number', value: '30' }]); if (v && +v.m > 0) { Timer.log(+v.m, S.timer.course); toast(t('Logged {n} min', { n: +v.m })); renderAll(); } },
  'td-add'() { const x = $('#tdText').value.trim(); if (!x) return; S.todos.push({ id: uid(), text: x, done: false, due: $('#tdDue').value, prio: +$('#tdPrio').value }); save(); renderView(); },
  'td-toggle'(el) { const x = S.todos.find(y => y.id === el.dataset.id); x.done = !x.done; save(); renderView(); },
  'td-del'(el) { S.todos = S.todos.filter(y => y.id !== el.dataset.id); save(); renderView(); },
  'td-clear'() { S.todos = S.todos.filter(y => !y.done); save(); renderView(); },
  async 'ex-add'() {
    const v = await formSheet('Add exam / deadline', [{ id: 'title', label: 'Title', ph: 'Mid-term: Mathematics' }, { id: 'date', label: 'Date', type: 'date' }, { id: 'course', label: 'Course', type: 'select', options: [['', t('General')], ...courses().map(c => [c.id, c.name])] }]);
    if (!v || !v.title || !v.date) return; S.exams.push({ id: uid(), ...v }); save(); renderView();
  },
  'ex-del'(el) { S.exams = S.exams.filter(y => y.id !== el.dataset.id); save(); renderView(); },
  /* settings */
  'set-go'(el) { UI.setPage = el.dataset.p; refreshSettings(); },
  'set-back'() { closeTop(); },
  'pf-seg'(el) { S.profile[el.dataset.f] = el.dataset.v; save(); refreshSettings(); renderAll(); },
  'goal-step'(el) { S.profile.goal = Math.max(15, Math.min(900, (S.profile.goal || 120) + +el.dataset.d)); save(); refreshSettings(); },
  'term-pick'(el) { S.activeTerm = el.dataset.id; UI.course = null; save(); refreshSettings(); renderTop(); },
  async 'term-new'() {
    const v = await formSheet('New Level/Term', [{ id: 'name', label: 'Name', ph: 'E.g. Level-1, Term-2' }], 'Create'); if (!v || !v.name) return;
    const T = { id: uid(), name: v.name, courses: [] }; S.terms.push(T); S.activeTerm = T.id; UI.course = null; save(); refreshSettings(); renderTop(); toast(t('Created') + ': ' + v.name);
  },
  async 'term-delete'() {
    const T = curTerm(); if (!T || !(await confirmBox(t('Delete "{x}" and all its notes? Files already saved in your storage folder are NOT deleted.', { x: T.name })))) return;
    for (const c of T.courses) { delete S.classes[c.id]; await AI.removeCourse(c.id); }
    S.terms = S.terms.filter(x => x.id !== T.id); S.activeTerm = S.terms[0]?.id || null; UI.course = null; save(); refreshSettings(); renderTop();
  },
  'course-new'() { UI.ce = { id: null, name: '', total: 20, color: courses().length % 8 }; UI.setPage = 'course'; refreshSettings(); },
  'course-edit'(el) { const c = courses().find(x => x.id === el.dataset.id); if (!c) return; UI.ce = { ...c }; UI.setPage = 'course'; refreshSettings(); },
  'ce-step'(el) { UI.ce.total = Math.max(1, Math.min(200, UI.ce.total + +el.dataset.d)); refreshSettings(); },
  'ce-color'(el) { UI.ce.color = +el.dataset.c; refreshSettings(); },
  'course-save'() {
    const c = UI.ce, T = curTerm(); if (!c.name.trim()) return toast(t('Course name cannot be empty'));
    if (c.id) { const x = T.courses.find(y => y.id === c.id); if (x) Object.assign(x, { name: c.name.trim(), total: c.total, color: c.color }); }
    else T.courses.push({ id: uid(), name: c.name.trim(), total: c.total, color: c.color });
    save(); UI.setPage = 'terms'; refreshSettings(); toast('💾 ' + t('Saved'));
  },
  async 'course-del'() {
    const c = UI.ce; if (!(await confirmBox(t('Remove "{x}" from this term? Its notes will be deleted (saved files stay in storage).', { x: c.name })))) return;
    const T = curTerm(); T.courses = T.courses.filter(x => x.id !== c.id); delete S.classes[c.id]; await AI.removeCourse(c.id);
    if (UI.course === c.id) UI.course = null; save(); UI.setPage = 'terms'; refreshSettings();
  },
  async 'pick-root'() {
    try { await FS.pickRoot(); } catch (e) { return toast(t('No folder selected')); }
    refreshSettings(); toast(t('Storage folder set'));
    try { const r = await Backup.verify(); if (r.total) { refreshSettings(); toast(r.missing ? t('{n} files are missing from your folder.', { n: r.missing }) : t('All files found.'), 3500); } } catch (e) { }
  },
  async 'backup-now'() { if (!S.root) return toast(t('Choose a storage folder first')); try { await Backup.now(); refreshSettings(); toast(t('Backup saved')); } catch (e) { console.warn(e); toast(t('Backup failed') + ': ' + (e.message || e)); } },
  async 'backup-restore'() { if (!S.root) return toast(t('Choose a storage folder first')); await restoreFlow(() => UI.set?.close()); },
  async 'undo-restore'() {
    if (!(await confirmBox(t('Go back to the data you had before the last restore?'), 'Undo', false))) return;
    try { Backup.undo(); await AI.load(); UI.course = null; refreshSettings(); renderAll(); toast(t('Restored the previous data')); reindexAll(true); } catch (e) { toast(t('Nothing to undo')); }
  },
  async 'files-verify'() {
    try { const r = await Backup.verify((i, n) => setProgress(`${t('Checking files…')} ${i}/${n}`, i / n)); setProgress(null); refreshSettings();
      toast(!r.total ? t('No files saved yet.') : r.missing ? t('{n} files are missing from your folder.', { n: r.missing }) : r.relinked ? t('Fixed {n} file links. All files found.', { n: r.relinked }) : t('All files found.'), 4000);
    } catch (e) { setProgress(null); toast(t('Backup failed')); }
  },
  reindex() { reindexAll(); },
  async 'llm-test'() {
    const box = $('#llmRes'); if (box) { box.className = 'sm muted'; box.textContent = t('Testing…'); } const was = S.llm.enabled; S.llm.enabled = true;
    try { const r = await AI.chat([{ role: 'user', content: 'Reply with the single word OK.' }]); save(); const cb = $('[data-f="enabled"]'); if (cb) cb.checked = true; if (box) { box.className = 'sm ok-t'; box.textContent = '✅ ' + t('Connected') + ' — ' + r.slice(0, 40); } }
    catch (e) { S.llm.enabled = was; save(); if (box) { box.className = 'sm late'; box.textContent = '❌ ' + AI.friendlyErr(e); } }
  },
  async 'pin-set'() {
    const v = await formSheet('Set PIN lock', [{ id: 'p', label: 'New PIN (4-8 digits)', type: 'password' }]); if (!v) return;
    if (!/^\d{4,8}$/.test(v.p)) return toast(t('PIN must be 4-8 digits')); S.profile.lock = await sha(v.p); save(); refreshSettings(); toast(t('PIN set'));
  },
  'pin-off'() { S.profile.lock = ''; save(); refreshSettings(); },
};
function setDur(m) { m = Math.max(1, Math.min(240, m || 25)); const T = S.timer; if (T.running) Timer.pause(); T.dur = m; if (T.mode === 'focus') T.remaining = null; save(); renderView(); }
const Chg = {
  'search-course'(el) { UI.search.course = el.value; runSearch(); },
  'ai-course'(el) { UI.aiSc = { courseId: el.value, n: 0, fileId: '', label: '' }; renderView(); },
  'tm-course'(el) { S.timer.course = el.value; save(); },
  'tm-custom'(el) { setDur(+el.value); },
  'cs-field'(el) { const k = ensureCls(UI.cur.cid, UI.cur.n); k[el.dataset.f] = el.value; save(); },
  pf(el) { const f = el.dataset.f; S.profile[f] = f === 'goal' ? Math.max(10, +el.value || 120) : el.value; save(); if (f === 'lang' || f === 'theme') { refreshSettings(); renderAll(); } },
  llm(el) { const f = el.dataset.f; S.llm[f] = el.type === 'checkbox' ? el.checked : el.value.trim(); if (f === 'key') S.llm.enabled = !!S.llm.key; if (f === 'url') S.llm.provider = detectProvider(S.llm.url); save(); if (f === 'url') refreshSettings(); },
  'llm-provider'(el) { const k = el.value, p = PRESETS[k]; S.llm.provider = k; if (p && p.url) { S.llm.url = p.url; S.llm.model = p.model; } save(); refreshSettings(); },
  'dark-toggle'(el) { S.profile.theme = el.checked ? 'dark' : 'light'; save(); renderAll(); },
  'llm-ctx'(el) { S.llm.ctx = +el.value; save(); },
};
const Inp = {
  search(el) { UI.search.q = el.value; clearTimeout(_st); _st = setTimeout(runSearch, 220); },
  'cs-field': Chg['cs-field'],
  ce: el => { UI.ce[el.dataset.f] = el.value; },
  'ai-live': el => aiLive(el.value),
};
document.addEventListener('click', e => { const el = e.target.closest('[data-act]'); if (el && Act[el.dataset.act]) Act[el.dataset.act](el, e); });
document.addEventListener('change', e => { const el = e.target.closest('[data-change]'); if (el && Chg[el.dataset.change]) Chg[el.dataset.change](el, e); });
document.addEventListener('input', e => { const el = e.target.closest('[data-input]'); if (el && Inp[el.dataset.input]) Inp[el.dataset.input](el, e); });
document.addEventListener('keydown', e => { if (e.target.id === 'aiq' && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); Act['ai-send'](); } });

/* ---------- boot ---------- */
(async function boot() {
  await FS.init(); try { await AI.load(); } catch (e) { console.warn(e); }
  if (S.timer.running && Timer.left() <= 0) Timer.finish();
  renderAll();
  if (!S.profile.onboarded && !S.terms.length) showIntro(); 
  if (S.profile.lock) showLock();
  if (window.Native && Native.isNative) {
    Native.App.addListener('backButton', () => {
      if (closeTop()) return;
      if (UI.tab === 'classes' && UI.course) { UI.course = null; return renderView(); }
      if (UI.tab !== 'home') { UI.tab = 'home'; return renderAll(); }
      Native.App.exitApp();
    });
    Native.App.addListener('appStateChange', s => { if (s.isActive) tickTimer(); else saveNow(); });
  }
  if ('serviceWorker' in navigator) { /* no SW: everything is bundled in the APK */ }
})();
